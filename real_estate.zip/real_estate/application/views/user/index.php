<?php require_once 'part/template/estate_header.php'; ?>
<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <header class="main-header">
            <a href="<?php echo base_url('panel'); ?>" class="logo" style="background-color: #8a6d3b">
                <span class="logo-mini font_title" style="font-size: 10px">پنل کاربر</span>
                <span class="logo-lg font_title">پنل کاربر</span>
            </a>
            <nav class="navbar navbar-static-top" role="navigation" style="background-color: #8a6d3b">
                <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">منو</span>
                </a>
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="messages-menu" style="margin-bottom:0px;">
                            <a href="<?php echo base_url('user/logout'); ?>" style="color: red;font-size: 19px;" title="خروج">
                                <i class="fa fa-power-off"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <aside class="main-sidebar">
            <section class="sidebar">
                <ul class="sidebar-menu">
                    <li class="header menu_admin">منو اصلی</li> 
                    <li class="treeview active">
                        <a href="#">
                            <i class="fa fa-envelope"></i>
                            <span>پیغام ها</span>
                        </a>
                    </li>
                </ul>
            </section>
        </aside>
        <div class="content-wrapper">
            <section class="content-header">
                <h1>
                    پنل کاربران  
                </h1>
                <div class="body_admin">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="box">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content" style="margin-top: -80px;" style="margin-bottom: 10px">
                                        <div class="modal-header">
                                            <textarea name="message" id="pm" class="form-control" placeholder="متن پیام"></textarea>
                                            <input style="margin-top: 10px;" class="btn btn-lg btn-success btn-block" name="submit" type="submit" value="ارسال" id="send">
                                        </div>
                                        <div class="modal-body  modal-body1" id="form">
                                            <div class="message_box_show" id="msg">
                                                <?php
                                                if ($rows_message !== null) {
                                                    foreach ($rows_message as $a) {
                                                        if ($a->send == 0) {
                                                            ?>
                                                            <div class="message_box_show_out">
                                                                <span class="date_message"><?php echo $a->date; ?></span><br>
                                                                <?php echo $a->message; ?></div>
                                                        <?php } else { ?>
                                                            <div class="message_box_show_in">
                                                                <span class="date_message"><?php echo $a->date; ?></span><br>
                                                                <?php echo $a->message; ?></div>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
        </div>
    </div>
    <script>
    $(document).ready(function () {
        $.post("<?php echo base_url('panel/noti_message'); ?>");
        refresh();
        function refresh() {
            setTimeout(function () {
                $('#msg').load('<?php echo base_url('user/msg'); ?>');
                refresh();
            }, 5000);
        }
        ;
        var y3 = 0;
        $(document).on('blur', '#pm', function () {
            if ($('#pm').val() == null || $('#pm').val() == "") {
                alert('پیغام را وارد کنید');
                $('#pm').css('border-color', 'red');
                y3 = 0;
                if (y3 == 1) {
                    $('#send').removeClass('disabled');
                } else {
                    $('#send').addClass('disabled');
                }
            } else {
                $('#pm').css('border-color', 'green');
                y3 = 1;
                if (y3 == 1) {
                    $('#send').removeClass('disabled');
                } else {
                    $('#send').addClass('disabled');
                }
            }
        });
        if (y3 == 1) {
            $('#send').removeClass('disabled');
        } else {
            $('#send').addClass('disabled');
        }
        $(document).on('click', '#send', function () {
            var message = $('#pm').val();
            $.post("<?php echo base_url('user/send_pm'); ?>", {q1: message}, function () {
                alert('ارسال شد');
            });
        });

    });</script>
    <?php require_once 'part/template/estate_footer.php'; ?>