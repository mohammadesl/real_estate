<html>
    <head>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.rtl.min.css">
        <title>ورود</title>        
    </head>
    <?php if ($error != '') { ?>
        <script>
            var x = '<?php echo $error; ?>';
            alert(x);
        </script>
    <?php } ?>
    <body class="login">
        <div class="container">
            <div class="row vertical-offset-100">
                <div class="col-md-4 col-md-offset-4" style="margin-top: 50px;">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title login_title" style="color: red;font-size: 20px">ورود</h3>
                        </div>
                        <div class="panel-body">
                            <div class="error_login">
                                <?php echo validation_errors(); ?>
                            </div>
                            <form accept-charset="UTF-8" role="form"  action="<?php echo base_url('site/check_login'); ?>" method="post">
                                <fieldset>
                                    <div class="form-group">
                                        <select class="form-control" id="type" name="type_user">
                                            <option value="0">مشاورین املاک</option>
                                            <option value="1">کاربر عادی</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="نام کاربری" name="user_name" type="text" id="user">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="رمز عبور" name="password" type="password" value="" id="pass">
                                    </div>
                                    <input class="btn btn-lg btn-success btn-block" type="submit" value="ورود" id="login"><br>
                                    <span class="ya col-md-12">یا</span><br>
                                    <a href="<?php echo base_url('site/sign_up'); ?>" class="btn btn-lg btn-danger btn-block a_sign_up">به سایت ما بپیوندید</a>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/TweenMax.min.js"></script>
        <script>
        $(document).ready(function () {
            $(document).mousemove(function (e) {
                TweenLite.to($('body'),
                        .5,
                        {css:
                                    {
                                        backgroundPosition: "" + parseInt(event.pageX / 8) + "px " + parseInt(event.pageY / '12') + "px, " + parseInt(event.pageX / '15') + "px " + parseInt(event.pageY / '15') + "px, " + parseInt(event.pageX / '30') + "px " + parseInt(event.pageY / '30') + "px"
                                    }
                        });
            });
        });
        </script>
    </body> 
</html>
