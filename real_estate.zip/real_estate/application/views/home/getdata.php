<?php

function parseToXML($htmlStr) {
    $xmlStr = str_replace('<', '&lt;', $htmlStr);
    $xmlStr = str_replace('>', '&gt;', $xmlStr);
    $xmlStr = str_replace('"', '&quot;', $xmlStr);
    $xmlStr = str_replace("'", '&#39;', $xmlStr);
    $xmlStr = str_replace("&", '&amp;', $xmlStr);
    return $xmlStr;
}

header("Content-type: text/xml");
echo '<homes>';
foreach ($rows as $r) {
    echo '<homes ';
    echo 'id="' . parseToXML($r->id_home) . '" ';
    echo 'price="' . parseToXML($r->price) . '" ';
    echo 'area="' . parseToXML($r->area) . '" ';
    echo 'tell="' . parseToXML($r->tell) . '" ';
    echo 'phone="' . parseToXML($r->phone) . '" ';
    echo 'real_estate="' . parseToXML($r->name) . '" ';
    echo 'lat="' . $r->lat . '" ';
    echo 'lng="' . $r->lon . '" ';
    echo 'type="' . $r->status_home . '" ';
    echo '/>';
}
echo '</homes>';
?>