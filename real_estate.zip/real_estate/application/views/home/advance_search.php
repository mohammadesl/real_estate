<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title><?php echo $title; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" />
        <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?libraries=places&sensor=false"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.rtl.min.css" />
        <script type="text/javascript">

        </script> 
    </head>
    <body>
        <div class="container">
            <div class="page-header title">جستجوی پیشرفته
            </div>
            <div class="container">
                <div class="row">
                    <div class="well">
                        <div class="col-sm-12">
                            <div class="col-sm-2">          
                                <input type="text" class="form-control" name="tell" id="price_down" placeholder="قیمت از :">
                            </div>
                            <div class="col-sm-2">          
                                <input type="text" class="form-control" name="tell" id="price_up" placeholder="قیمت تا :">
                            </div>
                            <div class="col-sm-2">          
                                <input type="text" class="form-control" name="tell" id="bedroom" placeholder="تداد اتاق خواب :">
                            </div>
                            <div class="col-sm-2">          
                                <input type="text" class="form-control" name="tell" id="build" placeholder="سال ساخت :">
                            </div>
                            <div class="col-sm-2">          
                                <input type="text" class="form-control" name="tell" id="city" placeholder="شهر :">
                            </div>
                            <div class="col-sm-2">          
                                <select class="form-control" id="type">
                                    <option value="0">نوع</option>
                                    <option value="1">فروش</option>
                                    <option value="2">رهن</option>
                                    <option value="3">اجاره</option>
                                </select>
                            </div>
                            <div class="checkbox" style="float: right;margin: 10px;margin-top: 30px">
                                <label><input type="checkbox" id="parking">پارکینگ</label>
                            </div>
                            <div class="checkbox" style="float: right;margin: 10px;margin-top: 30px"">
                                <label><input type="checkbox" id="elevator">اسانسور</label>
                            </div>
                            <div class="checkbox" style="float: right;margin: 10px;margin-top: 30px"">
                                <label><input type="checkbox" id="storehouse">انبار</label>
                            </div>
                            <div class="col-sm-1" style="float: right;margin: 10px;margin-top: 30px;">          
                                <input type="submit" class="btn-large btn-success btn_search" id="submit_search" onclick="my.initialize()" value="بگرد">
                            </div>
                        </div>
                        <br><br><br><br><br>
                    </div>
                    <div id="map_canvas" style="height:800px;"></div> 
                </div>
            </div>
        </div>
        <script src="<?php echo base_url(); ?>assets/js/jQuery-2.1.4.min.js"></script>
        <script>
        var my = {};
        var q1,q2,q3 ,q4 ,q5,q6,q7,q8,q9;
        var map;
        var geocoder = new google.maps.Geocoder();
        var customIcons = {
            1: {
                icon: 'http://localhost/root/real_estate/assets/img/sale.png'
            },
            2: {
                icon: 'http://localhost/root/real_estate/assets/img/m.png'
            },
            3: {
                icon: 'http://localhost/root/real_estate/assets/img/rent.png'
            }
        };

        my.initialize = function () {
            map = new google.maps.Map(document.getElementById("map_canvas"), {
                center: new google.maps.LatLng(36.53860527391006, 52.67738342285156),
                zoom: 8,
                mapTypeId: 'roadmap'
            });
            var infoWindow = new google.maps.InfoWindow;
            q1 = $("#price_down").val();
            q2 = $("#price_up").val();
            q3 = $("#bedroom").val();
            q4 = $("#build").val();
            q5 = $("#city").val();
            q6 = $("#type").val();
            q7 = $("#parking:checked").val();
            q8 = $("#elevator:checked").val();
            q9 = $("#storehouse:checked").val();
            if (q1 == '') {
                q1 = 0;
            }
            if (q2 == '') {
                q2 = 1000000000000;
            }
            if (q3 == '') {
                q3 = 0;
            }
            if (q4 == '') {
                q4 = 0;
            }
            if (q5 == '') {
                q5 = 0;
            }
            if (q6 == '') {
                q6 = 0;
            }
            if (q7 == 'on') {
                q7 = 1;
            } else {
                q7 = 0;
            }
            if (q8 == 'on') {
                q8 = 1;
            } else {
                q8 = 0;
            }
            if (q9 == 'on') {
                q9 = 1;
            } else {
                q9 = 0;
            }
            // Change this depending on the name of your PHP file
            downloadUrl("<?php echo base_url('site/senddata_search'); ?>?q1="+q1+"&q2="+q2+"&q3="+q3+"&q4="+q4+"&q6="+q6+"&q7="+q7+"&q8="+q8+"&q9="+q9, function (data) {
                var xml = data.responseXML;
                var markers = xml.documentElement.getElementsByTagName("homes");
                for (var i = 0; i < markers.length; i++) {
                    var name = markers[i].getAttribute("price");
                    var area = markers[i].getAttribute("area");
                    var tell = markers[i].getAttribute("tell");
                    var x = markers[i].getAttribute("id");
                    var phone = markers[i].getAttribute("phone");
                    var realestate = markers[i].getAttribute("real_estate");
                    var type = markers[i].getAttribute("type");
                    var point = new google.maps.LatLng(
                            parseFloat(markers[i].getAttribute("lat")),
                            parseFloat(markers[i].getAttribute("lng")));
                    var html = "<br/><b> قیمت :" + name + "</b><br/><b> متراژ :" + area + "</b><br/><b> نام املاک :" + realestate + "</b><br/><b>همراه : " + phone + "</b><br/><b>ثابت : " + tell + "</b>" + "</b><br/><a href='<?php echo base_url('site/home_page'); ?>?x=" + x + "'><b style='color:red'>بیشتر </b></a>";
                    var icon = customIcons[type] || {};
                    var marker = new google.maps.Marker({
                        map: map,
                        position: point,
                        animation: google.maps.Animation.DROP,
                        icon: icon.icon
                    });
                    bindInfoWindow(marker, map, infoWindow, html);
                }
            });
            
            var address = $('#city').val();
                geocoder.geocode({'address': address}, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK)
                    {
                        map.setCenter(results[0].geometry.location);
                        var marker = new google.maps.Marker({
                            map: map
                        });
                    }
                    
                });
        }

        function bindInfoWindow(marker, map, infoWindow, html) {
            google.maps.event.addListener(marker, 'click', function () {
                infoWindow.setContent(html);
                infoWindow.open(map, marker);
            });
        }

        function downloadUrl(url, callback) {
            var request = window.ActiveXObject ?
                    new ActiveXObject('Microsoft.XMLHTTP') :
                    new XMLHttpRequest;

            request.onreadystatechange = function () {
                if (request.readyState == 4) {
                    request.onreadystatechange = doNothing;
                    callback(request, request.status);
                }
            };

            request.open('GET', url, true);
            request.send(null);
        }

        function doNothing() {
        }
        </script>
    </body>
</html>
