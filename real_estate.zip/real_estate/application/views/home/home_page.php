<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>اطلاعات ملک</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.rtl.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/_all-skins.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    </head>
    <body>
        <div class="container">
            <div class="page-header title">اطلاعات ملک
            </div>
            <div class="row">
                <div class="home_page_body">
                    <?php foreach ($rows as $r) { ?>
                        <div class="col-lg-6 home_page_body_rigth">
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">قیمت : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->price; ?> تومان</span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">متراژ : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->area; ?> متر</span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">نوع ملک : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->type; ?></span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">آسانسور : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->type1; ?></span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">اتاق خواب : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->bedroom; ?></span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">تلفن ثابت مشاور املاک : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->tell; ?></span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">تلفن همراه مشاور املاک : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->phone; ?></span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">آدرس مشاور املاک : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->address; ?></span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">انبار : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->type_storehouse; ?></span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">پارکینگ : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->type_parking; ?></span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">سال ساخت : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->build; ?></span>
                            </div>
                            <div class="home_page_span">
                                <span class="col-lg-5 home_page_text1">توضیحات : </span>
                                <span class="col-lg-7 home_page_text"><?php echo $r->description; ?></span>
                            </div>
                        </div>
                        <div class="col-lg-6 home_page_body_left">


                            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                                <!-- Indicators -->
                                <ol class="carousel-indicators">
                                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                    <li data-target="#myCarousel" data-slide-to="1"></li>
                                    <li data-target="#myCarousel" data-slide-to="2"></li>
                                </ol>

                                <!-- Wrapper for slides -->
                                <div class="carousel-inner" role="listbox">
                                    <div class="item active">
                                        <img style="width: 600px;height: 400px" src="<?php echo base_url(); ?>assets/upload/<?php echo $r->img1; ?>">
                                    </div>
                                    <div class="item">
                                        <img style="width: 600px;height: 400px" src="<?php echo base_url(); ?>assets/upload/<?php echo $r->img2; ?>">
                                    </div>
                                    <div class="item">
                                        <img style="width: 600px;height: 400px" src="<?php echo base_url(); ?>assets/upload/<?php echo $r->img3; ?>">
                                    </div>
                                </div>

                                <!-- Left and right controls -->
                                <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                                    <span class="fa fa-chevron-right" style="line-height: 400px" aria-hidden="true"></span>
                                    <span class="sr-only">قبلی</span>
                                </a>
                                <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                                    <span class="fa fa-chevron-left" style="line-height: 400px" aria-hidden="true"></span>
                                    <span class="sr-only">بعدی</span>
                                </a>
                            </div>
                        </div>
                    <a class="back_home_page" href="<?php echo base_url(); ?>">بازگشت</a>
                    <img class="home_page_body_left_img img-responsive" src="http://maps.googleapis.com/maps/api/staticmap?center=<?php echo $r->lat; ?>,<?php echo $r->lon; ?>&zoom=13&size=560x200&maptype=roadmap&markers=color:red|<?php echo $r->lat; ?>,<?php echo $r->lon; ?>&sensor=false">
                    <?php } ?>
                </div>
            </div>
        </div>
    </body>
</html>