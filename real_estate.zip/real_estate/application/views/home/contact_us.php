<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title><?php echo $title; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.rtl.min.css" />
        <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css"/>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jQuery-2.1.4.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="page-header title">ارتباط با ما
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="well well-sm">
                            <form class="form-horizontal" method="post" name="form1" id="form1">
                                <fieldset>
                                    <span></span><br>
                                    <div class="form-group">
                                        <span class="col-md-1 col-md-offset-1 text-center text_center1"><i class="fa fa-user bigicon"></i></span>
                                        <div class="col-md-8">
                                            <input id="name" name="name" type="text" placeholder="نام :" class="form-control">
                                        </div>
                                        <div class="col-md-2 text-center" id="name_msg" style="margin-top: 10px;"></div>
                                    </div>
                                    <div class="form-group">
                                        <span class="col-md-1 col-md-offset-1 text-center text_center1"><i class="fa fa-envelope-o bigicon"></i></span>
                                        <div class="col-md-8">
                                            <input id="email" name="email" type="text" placeholder="ایمیل :" class="form-control">
                                        </div>
                                        <div class="col-md-2 text-center" id="email_msg" style="margin-top: 10px;"></div>
                                    </div>
                                    <div class="form-group">
                                        <span class="col-md-1 col-md-offset-1 text-center text_center1"><i class="fa fa-phone-square bigicon"></i></span>
                                        <div class="col-md-8">
                                            <input id="phone" name="phone" type="text" maxlength="11" placeholder="شماره تماس : " class="form-control">
                                        </div>
                                        <div class="col-md-2 text-center" id="phone_msg" style="margin-top: 10px;"></div>
                                    </div>
                                    <div class="form-group">
                                        <span class="col-md-1 col-md-offset-1 text-center text_center1"><i class="fa fa-pencil-square-o bigicon"></i></span>
                                        <div class="col-md-8">
                                            <textarea class="form-control" id="message" name="message" placeholder="پیغام خود را وارد کنید ." rows="7"></textarea>
                                        </div>
                                        <div class="col-md-2 text-center" id="message_msg" style="margin-top: 10px;"></div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-md-12 text-center">
                                            <button type="submit" class="col-md-8 col-md-offset-2  btn btn-primary btn-lg" id="add_member">ارسال</button>
                                        </div>
                                        <div class="col-md-12 text-center" style="margin-top: 10px;">
                                            <a href="<?php echo base_url(); ?>" class="col-md-8 col-md-offset-2  btn btn-danger btn-lg">برگشت</a>
                                        </div>
                                        <div class="col-md-2 text-center" style="margin-top: 10px;"></div>
                                        <div class="col-md-8 text-center text_contact_us" style="margin-top: 10px;">
                                            کاربر گرامی شما بعد از ثبت نظر عضو وبسایت ما می گردید و میتوانید پاسخ خود را از طریق ورود به حساب کاربری خود دریافت نمایید  <span class="color">.نام کاربری شما برابر است با ایمیل شما و رمز عبور شما شماره تماس شماست</span>. از شما بخاطر همکاری با ما نهایت سپاس را داریم
                                        </div>
                                    </div>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<script>
    $(document).ready(function () {
        var y1, y2, y3, y4;
        y1 = 0;
        y2 = 0;
        y3 = 0;
        y4 = 0;
        $(document).on('blur', '#name', function () {
            if ($('#name').val() == null || $('#name').val() == "") {
                $('#name').css('border-color', 'red');
                $("#name_msg").html('لطفا نام را وارد کنید .');
                $("#name_msg").css('color', 'red');
                y1 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                $('#name').css('border-color', 'green');
                $("#name_msg").html('قابل قبول.');
                $("#name_msg").css('color', 'green');
                y1 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#email', function () {
            var usercheck = $("#email").val();
            var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if ($('#email').val() == null || $('#email').val() == "") {
                $("#email_msg").html('لطفا ایمیل را وارد کنید .');
                $("#email_msg").css('color', 'red');
                $('#email').css('border-color', 'red');
                y2 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                if (re.test($('#email').val())) {
                    $.post("<?php echo base_url('site/check_user2'); ?>", {user_name: usercheck}, function (data)
                    {
                        if (data != '' || data != undefined || data != null)
                        {
                            if (data == '<span id="user_id_span" class="add_estate1">قابل قبول</span>') {
                                $('#email').css('border-color', 'green');
                                $("#email_msg").html('قابل قبول.');
                                $("#email_msg").css('color', 'green');
                                y2 = 1;
                                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                                    $('#add_member').removeClass('disabled');
                                } else {
                                    $('#add_member').addClass('disabled');
                                }
                            } else {
                                $('#email').css('border-color', 'red');
                                $("#email_msg").html('ایمیل دردسترس نیست.');
                                alert('اگر قبلا پیغامی فرستاده اید شما عضو سایت هستید و برای دریافت پاسخ به حساب کاربری خود بروید و پیغام تازه بگذارید');
                                $("#email_msg").css('color', 'red');
                                y2 = 0;
                                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                                    $('#add_member').removeClass('disabled');
                                } else {
                                    $('#add_member').addClass('disabled');
                                }
                            }
                        }
                    });
                } else {
                    $('#email').css('border-color', 'red');
                    $("#email_msg").html('فرمت ایمیل صحیح نیست.');
                    $("#email_msg").css('color', 'red');
                    y2 = 0;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                        $('#add_member').removeClass('disabled');
                    } else {
                        $('#add_member').addClass('disabled');
                    }
                }
            }
        });
        $(document).on('blur', '#message', function () {
            if ($('#message').val() == null || $('#message').val() == "") {
                $('#message').css('border-color', 'red');
                $("#message_msg").html('لطفا پیغام را وارد کنید.');
                $("#message_msg").css('color', 'red');
                y3 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                $('#message').css('border-color', 'green');
                $("#message_msg").html('قابل قبول.');
                $("#message_msg").css('color', 'green');
                y3 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#phone', function () {
            if ($('#phone').val() == null || $('#phone').val() == "") {
                $('#phone').css('border-color', 'red');
                $("#phone_msg").html('لطفا شماره تماس را وارد کنید.');
                $("#phone_msg").css('color', 'red');
                y4 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                if ($("#phone").val().length == 11) {
                    $("#phone_msg").html('قابل قبول.');
                    $("#phone_msg").css('color', 'green');
                    $('#phone').css('border-color', 'green');
                    y4 = 1;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                        $('#add_member').removeClass('disabled');
                    } else {
                        $('#add_member').addClass('disabled');
                    }
                } else {
                    $('#phone').css('border-color', 'red');
                    $("#phone_msg").html('تعداد کاراکتر 11 تا باید باشد.');
                    $("#phone_msg").css('color', 'red');
                    y4 = 0;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                        $('#add_member').removeClass('disabled');
                    } else {
                        $('#add_member').addClass('disabled');
                    }
                }
            }
        });
        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
            $('#add_member').removeClass('disabled');
        } else {
            $('#add_member').addClass('disabled');
        }

        $('#form1').submit(function (e) {

            e.preventDefault();
            var name = $('#name').val();
            var mail = $('#email').val();
            var phone = $('#phone').val();
            var message = $('#message').val();
            if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1) {
                $.post("<?php echo base_url('site/contact_message'); ?>", {q1: name, q2: mail, q3: phone, q4: message}, function (data) {
                    alert(data + '     کاربر گرامی شما بعد از ثبت نظر عضو وبسایت ما می گردید و میتوانید پاسخ خود را از طریق ورود به حساب کاربری خود دریافت نمایید .نام کاربری شما برابر است با ایمیل شما و رمز عبور شما شماره تماس شماست. از شما بخاطر همکاری با ما نهایت سپاس را داریم');
                });
            } else {
                alert('پرکردن تمامی فیلد ها اجباری است.');
            }
        });
    });</script>