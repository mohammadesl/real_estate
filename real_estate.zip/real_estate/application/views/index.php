<?php
// 
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html> 
    <head> 
        <meta name="viewport" content="initial-scale=1.0, user-scalable=no" /> 
        <title>مشاوران املاک</title>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style1.css">
        <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?libraries=places&sensor=false"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.rtl.min.css">
        <script src = "https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" ></script>
        <script type="text/javascript">
            var up206b = {};
            var map;
            var geocoder = new google.maps.Geocoder();
            var customIcons = {
                1: {
                    icon: 'http://localhost/root/real_estate/assets/img/sale.png'
                },
                2: {
                    icon: 'http://localhost/root/real_estate/assets/img/m.png'
                },
                3: {
                    icon: 'http://localhost/root/real_estate/assets/img/rent.png'
                }
            };

            up206b.initialize = function () {
                map = new google.maps.Map(document.getElementById("map_canvas"), {
                    center: new google.maps.LatLng(36.53860527391006, 52.67738342285156),
                    zoom: 8,
                    mapTypeId: 'roadmap'
                });
                var infoWindow = new google.maps.InfoWindow;

                // Change this depending on the name of your PHP file
                downloadUrl("<?php echo base_url('site/getdata'); ?>", function (data) {
                    var xml = data.responseXML;
                    var markers = xml.documentElement.getElementsByTagName("homes");
                    for (var i = 0; i < markers.length; i++) {
                        var name = markers[i].getAttribute("price");
                        var area = markers[i].getAttribute("area");
                        var tell = markers[i].getAttribute("tell");
                        var x = markers[i].getAttribute("id");
                        var phone = markers[i].getAttribute("phone");
                        var realestate = markers[i].getAttribute("real_estate");
                        var type = markers[i].getAttribute("type");
                        var point = new google.maps.LatLng(
                                parseFloat(markers[i].getAttribute("lat")),
                                parseFloat(markers[i].getAttribute("lng")));
                        var html = "<br/><b> قیمت :" + name + "</b><br/><b> متراژ :" + area + "</b><br/><b> نام املاک :" + realestate + "</b><br/><b>همراه : " + phone + "</b><br/><b>ثابت : " + tell + "</b>" + "</b><br/><a href='<?php echo base_url('site/home_page'); ?>?x=" + x + "'><b style='color:red'>بیشتر </b></a>";
                        var icon = customIcons[type] || {};
                        var marker = new google.maps.Marker({
                            map: map,
                            position: point,
                            animation: google.maps.Animation.DROP,
                            icon: icon.icon
                        });
                        bindInfoWindow(marker, map, infoWindow, html);
                    }
                });
            };

            function bindInfoWindow(marker, map, infoWindow, html) {
                google.maps.event.addListener(marker, 'click', function () {
                    infoWindow.setContent(html);
                    infoWindow.open(map, marker);
                });
            }

            function downloadUrl(url, callback) {
                var request = window.ActiveXObject ?
                        new ActiveXObject('Microsoft.XMLHTTP') :
                        new XMLHttpRequest;

                request.onreadystatechange = function () {
                    if (request.readyState == 4) {
                        request.onreadystatechange = doNothing;
                        callback(request, request.status);
                    }
                };

                request.open('GET', url, true);
                request.send(null);
            }

            function doNothing() {
            }
            up206b.geocode = function ()
            {
                var address = $('#address').val();
                geocoder.geocode({'address': address}, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK)
                    {
                        map.setCenter(results[0].geometry.location);
                        var marker = new google.maps.Marker({
                            map: map
                        });
                    }
                    else
                    {
                        alert("Geocode was not successful for the following reason: " + status);
                    }
                });
            }
            $('#address').keypress(function (e) {
                if (e.which == 13) {
                    up206b.geocode();
                }
            });
        </script> 
    </head>
    <body dir="rtl" onload="up206b.initialize()">
        <!-- side panel div container --> 
        <div class="menu_right"> 
            <div id="container">
                <div id="body">
                    <a class="btn btn-large btn-primary btn_index_1" style="margin: 10px;padding-right: 60px;padding-left: 60px" href="<?php echo base_url('site/log_in') ?>">ورود</a>
                    <a class="btn btn-large btn-danger" style="margin: 10px;padding-right: 60px;padding-left: 60px" href="<?php echo base_url('site/sign_up') ?>">ثبت نام</a><br>
                    <a class="btn btn-large btn-default btn_index_1" style="margin: 10px;padding-right: 39px;padding-left: 40px" href="<?php echo base_url('site/advance_search') ?>">جستجو پیشرفته</a>
                    <a class="btn btn-large btn-default" style="margin: 10px;padding-right: 49px;padding-left: 50px" href="<?php echo base_url('site/contact_us') ?>">ارتباط با ما</a><br>
                </div>
                <div style="padding:10px;">
                    <input class="index"  type="text" id="address">
                    <input class="btn btn-small btn-success" type="button" value="بگرد" onClick="up206b.geocode()">
                </div>
                <div class="search_home"></div>
                <div class="sambol">
                    <img src="<?php echo base_url(); ?>assets/img/m.png"><span class="sambol1">رهن</span>
                    <img src="<?php echo base_url(); ?>assets/img/rent.png"><span class="sambol1">اجاره</span>
                    <img src="<?php echo base_url(); ?>assets/img/sale.png"><span class="sambol1">فروش</span>
                </div>
            </div>
        </div> 
        <!-- map div container --> 
        <div id="map_canvas" style="height:100%; "></div> 
    </body>  
    <script>
        $(document).ready(function () {
            $(document).on('keyup', '#address', function () {
                var usercheck = $('#address').val();
                if (usercheck != '') {
                    $.post("<?php echo base_url('site/search_home'); ?>", {q: usercheck}, function (data)
                    {
                        if (data != '' || data != undefined || data != null)
                        {
                            if (data != 'موردی یافت نشد') {
                                $.post("<?php echo base_url('site/search_home_show'); ?>", {q: data}, function (data1)
                                {
                                    if (data1 != '' || data1 != undefined || data1 != null)
                                    {
                                        $('.search_home').html(data1);
                                    }
                                });
                            } else {
                                $('.search_home').html(data);
                            }
                        }
                    });
                }
            });
        })
    </script>
</html>

