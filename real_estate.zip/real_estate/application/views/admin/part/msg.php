<?php
foreach ($rows as $a) {
    if ($a->send == 1) {
        ?>
        <div class="message_box_show_out">
            <span class="date_message"><?php echo $a->date; ?></span><br>
            <?php echo $a->message; ?></div>
    <?php } else { ?>
        <div class="message_box_show_in">
            <span class="date_message"><?php echo $a->date; ?></span><br>
            <?php echo $a->message; ?></div>
        <?php
    }
}
?>