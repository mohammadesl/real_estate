<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {
        var y1, y2;
        y1 = 0;
        y2 = 0;
        $(document).on('blur', '#username', function () {
            var usercheck = $("#username").val();
            if ($('#username').val() == null || $('#username').val() == "") {
                $("#msg_username").html('نام کاربری را وارد کنید');
                $('#username').css('border-color', 'red');
                $("#msg_username").css('color', 'red');
                y1 = 0;
                if (y1 == 1 & y2 == 1) {
                    $('#add_message').removeClass('disabled');
                } else {
                    $('#add_message').addClass('disabled');
                }
            } else {
                $.post("<?php echo base_url('site/check_user_message'); ?>", {user_name: usercheck}, function (data)
                {
                    if (data != '' || data != undefined || data != null)
                    {
                        $('#msg_username').html(data);
                        $("#msg_username").css('color', 'red');
                        if (data == '<span id="user_id_span" class="add_estate1">قابل قبول</span>') {
                            $('#username').css('border-color', 'green');
                            $("#msg_username").css('color', 'green');
                            y1 = 1;
                            if (y1 == 1 & y2 == 1) {
                                $('#add_message').removeClass('disabled');
                            } else {
                                $('#add_message').addClass('disabled');
                            }
                        } else {
                            $('#username').css('border-color', 'red');
                            y1 = 0;
                            if (y1 == 1 & y2 == 1) {
                                $('#add_message').removeClass('disabled');
                            } else {
                                $('#add_message').addClass('disabled');
                            }
                        }
                    }
                });
            }
        });
        $(document).on('blur', '#message', function () {
            if ($('#message').val() == null || $('#message').val() == "") {
                $("#msg_message").html('پیغام را وارد کنید');
                $('#message').css('border-color', 'red');
                $("#msg_message").css('color', 'red');
                y2 = 0;
                if (y1 == 1 & y2 == 1) {
                    $('#add_message').removeClass('disabled');
                } else {
                    $('#add_message').addClass('disabled');
                }
            } else {
                $('#message').css('border-color', 'green');
                $("#msg_message").html('');
                y2 = 1;
                if (y1 == 1 & y2 == 1) {
                    $('#add_message').removeClass('disabled');
                } else {
                    $('#add_message').addClass('disabled');
                }
            }
        });
        if (y1 == 1 & y2 == 1) {
            $('#add_message').removeClass('disabled');
        } else {
            $('#add_message').addClass('disabled');
        }

        $(document).on('click', '#add_message', function () {
            var user = $('#username').val();
            var message = $('#message').val();
            $.post('<?php echo base_url('site/send_message'); ?>', {q1: user, q2: message}, function () {
                alert('ارسال شد');
            });
        });
        setInterval(function () {
            $('.message_box_show');
        }, 1000);
    });
</script>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box">
            <div class="btn btn-info add" data-toggle="modal" data-target="#myModal">
                پیام جدید <i class="fa fa-plus"></i>
            </div>
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content" style="margin-top: -80px;">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title font_title" id="myModalLabel">پیام جدید</h4>
                        </div>

                        <div class="modal-body  modal-body1" id="form">
                            <div class="form-group form-group1">
                                <label class="control-label col-sm-2 size_font" for="username">نام کاربری:</label>
                                <div class="col-sm-7">          
                                    <input type="text" class="form-control" name="username" id="username">
                                </div>
                                <div class="col-sm-3 add_estate" id="msg_username"></div>
                            </div>
                            <div class="form-group form-group1">
                                <label class="control-label col-sm-2 size_font" for="message">متن پیام :</label>
                                <div class="col-sm-7">          
                                    <textarea class="form-control" name="message" id="message"></textarea>
                                </div>
                                <div class="col-sm-3 add_estate" id="msg_message"></div>
                            </div>
                        </div>
                        <div class="modal-body modal-body1" id="resend_add"></div>
                        <div class="modal-footer">
                            <button type="button" id="close_form" class="btn btn-default font_title" data-dismiss="modal">بستن</button>
                            <input name="submit" type="submit" id="add_message" class="btn btn-primary font_title" value="ارسال">
                        </div>

                    </div>
                </div>
            </div> 
            <ul class="row" style="margin-top: 55px;">
                <?php
                        foreach ($rows as $record) {
                    ?>
                    <li class="col-lg-2 col-md-2 col-sm-3 col-xs-4 message_box" id="message<?php echo $record->id_message; ?>" data-toggle="modal" data-target="#myModal_message<?php echo $record->username_estate; ?>">
                        <span><?php echo $record->username_estate; ?></span><br>
                        <?php if ($record->seen_admin == 0) { ?>
                            <i class="fa fa-bell bell_style" ></i>
                        <?php } ?>
                    </li>
                    <div class="modal fade" id="myModal_message<?php echo $record->username_estate; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content" style="margin-top: -80px;">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <textarea name="message" id="pm<?php echo $record->id_message; ?>" class="form-control" placeholder="متن پیام"></textarea>
                                    <input style="margin-top: 10px;" class="btn btn-lg btn-success btn-block" name="submit" type="submit" value="ارسال" id="send<?php echo $record->id_message; ?>">
                                </div>
                                <div class="modal-body  modal-body1" id="form">
                                    <div class="message_box_show" id="msg<?php echo $record->id_message; ?>">
                                        <?php
                                        $mysqli = mysqli_connect("localhost", "root", "", "real_estate");
                                        $query1 = 'SELECT  * FROM message WHERE username_estate = "' . $record->username_estate . '"order by id_message DESC';
                                        $result1 = mysqli_query($mysqli,$query1);
                                        while ($record1 = mysqli_fetch_assoc($result1)) {
                                            if ($record1['send'] == 1) {
                                                ?>
                                                <div class="message_box_show_out">
                                                    <span class="date_message"><?php echo $record1['date']; ?></span><br>
                                                    <?php echo $record1['message']; ?></div>
                                            <?php } else { ?>
                                                <div class="message_box_show_in">
                                                    <span class="date_message"><?php echo $record1['date']; ?></span><br>
                                                    <?php echo $record1['message']; ?></div>
                                                    <?php
                                                }
                                            }
                                            ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                <?php } ?>
            </ul>

        </div>
    </div>
</div>
<script>
<?php
$mysqli = mysqli_connect("localhost", "root", "", "real_estate");
$query = 'SELECT  * FROM message a WHERE a.id_message = (SELECT  MAX(id_message) id_message FROM message b WHERE   a.username_estate = b.username_estate ) order by id_message DESC ';
$result = mysqli_query($mysqli,$query);
while ($record = mysqli_fetch_assoc($result)) {
    ?>
        $(document).ready(function () {
            refresh();
            function refresh() {
                setTimeout(function () {
                    $('#msg<?php echo $record['id_message']; ?>').load('<?php echo base_url('site/msg'); ?>?x=<?php echo $record['id_message']; ?>');
                    refresh();
                }, 5000);
            };
            var y3 = 0;
            $(document).on('blur', '#pm<?php echo $record['id_message']; ?>', function () {
                if ($('#pm<?php echo $record['id_message']; ?>').val() == null || $('#pm<?php echo $record['id_message']; ?>').val() == "") {
                    alert('پیغام را وارد کنید');
                    $('#pm<?php echo $record['id_message']; ?>').css('border-color', 'red');
                    y3 = 0;
                    if (y3 == 1) {
                        $('#send<?php echo $record['id_message']; ?>').removeClass('disabled');
                    } else {
                        $('#send<?php echo $record['id_message']; ?>').addClass('disabled');
                    }
                } else {
                    $('#pm<?php echo $record['id_message']; ?>').css('border-color', 'green');
                    y3 = 1;
                    if (y3 == 1) {
                        $('#send<?php echo $record['id_message']; ?>').removeClass('disabled');
                    } else {
                        $('#send<?php echo $record['id_message']; ?>').addClass('disabled');
                    }
                }
            });
            if (y3 == 1) {
                $('#send<?php echo $record['id_message']; ?>').removeClass('disabled');
            } else {
                $('#send<?php echo $record['id_message']; ?>').addClass('disabled');
            }
            $(document).on('click', '#message<?php echo $record['id_message']; ?>', function () {
                var id = <?php echo $record['id_message']; ?>;
                $.post("<?php echo base_url('site/noti_message'); ?>", {q: id});
            });
            $(document).on('click', '#send<?php echo $record['id_message']; ?>', function () {
                var message = $('#pm<?php echo $record['id_message']; ?>').val();
                var id = <?php echo $record['id_message']; ?>;
                $.post("<?php echo base_url('site/send_pm'); ?>", {q1: message, q2: id}, function () {
                    alert('ارسال شد');
                });
            });

        });
<?php } ?>

</script>