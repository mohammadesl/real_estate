<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {
        $('#show_search').hide();
        $(document).on('keyup', '#search_pending', function () {
            var usercheck = $('#search_pending').val();
            var value_category = $('.search_category').val();
            if (usercheck != '') {
                if (value_category != 'بر اساس') {
                    $.post("<?php echo base_url('site/search_real_estate_pending'); ?>", {q: usercheck, p: value_category}, function (data)
                    {
                        if (data != '' || data != undefined || data != null)
                        {
                            if (data != 'موردی یافت نشد') {
                                $.post("<?php echo base_url('site/search_real_estate_show_pending'); ?>", {q: data, p: value_category}, function (data1)
                                {
                                    if (data != '' || data != undefined || data != null)
                                    {
                                        $('#show_search').show();
                                        $('#show_search').html(data1);
                                    }
                                });
                            } else {
                                $('#show_search').show();
                                $('#show_search').html(data);
                            }
                        }
                    });
                } else {
                    $('#show_search').show();
                    $('#show_search').html('نوع بر اساس را انتخاب کنید');
                }
            } else {
                $('#show_search').hide();
            }
        });
        $(document).on('change', '.search_category', function () {
            var usercheck = $('#search_pending').val();
            var value_category = $('.search_category').val();
            if (usercheck != '') {
                if (value_category != 'بر اساس') {
                    $.post("<?php echo base_url('site/search_real_estate_pending'); ?>", {q: usercheck, p: value_category}, function (data)
                    {
                        if (data != '' || data != undefined || data != null)
                        {
                            if (data != 'موردی یافت نشد') {
                                $.post("<?php echo base_url('site/search_real_estate_show_pending'); ?>", {q: data, p: value_category}, function (data1)
                                {
                                    if (data != '' || data != undefined || data != null)
                                    {
                                        $('#show_search').show();
                                        $('#show_search').html(data1);
                                    }
                                });
                            } else {
                                $('#show_search').show();
                                $('#show_search').html(data);
                            }
                        }
                    });
                }
            } else {
                $('#show_search').hide();
            }
        });


    });
</script>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box">
            <div>
                <div class="col-lg-6 search_real_estate">
                    <div class="input-group">
                        <input type="text" id="search_pending" class="form-control" placeholder="جستجو" aria-label="...">
                        <div class="input-group-btn">
                            <select class="search_category">
                                <option style="display: none;">بر اساس</option>
                                <option>نام کاربری</option>
                                <option>آدرس</option>
                                <option>مدیر</option>
                                <option>شماره ثبت</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-10" id="show_search">

                </div>
            </div>
            <div class="box-body table-responsive no-padding ajax_show_estate">
                <table id="printTable" class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>کد</th>
                        <th>وضعیت</th>
                        <th>نام املاک</th>
                        <th>روز ثبت</th>
                        <th>مدیر</th>
                        <th>شماره ثبت</th>
                        <th>آدرس</th>
                        <th>شماره همراه</th>
                        <th>شماره ثابت</th>
                        <th>نام کاربری</th>
                        <th>مدرک</th>
                    </tr>
                    <?php
                    $x = 0;
                    if ($rows != null) {
                        foreach ($rows as $a) {
                            ?>
                            <tr class="table_real_estate">
                                <td><?php echo $a->id1; ?></td>
                                <td>
                                    <div class="btn-group"> 
                                        <select id="status_estate_pending<?php echo $a->id1; ?>" class="status_estate" style="color:white;
                                                <?php if ($a->type == 'تایید شده') { ?>background-color: #00a157;<?php
                                                } elseif ($a->type == 'در حال بررسی') {
                                                    ?>background-color: #E67E22;<?php
                                                } elseif ($a->type == 'لغو شده') {
                                                    ?>background-color: #c9302c;<?php }
                                                ?>">
                                            <option style="display: none;"><?php echo $a->type; ?></option>
                                            <option style="display: none;"></option>
                                            <option class="select_real_estate" value="2">تایید شده</option>
                                            <option class="select_real_estate"value="1">در حال بررسی</option>
                                            <option class="select_real_estate"value="3">لغو شده</option>
                                        </select>
                                        <div class="status<?php echo $a->id1; ?>"></div>
                                    </div>
                                </td>
                                <td><?php echo $a->name; ?></td>
                                <td><?php echo $a->date_ragister; ?></td>
                                <td><?php echo $a->manager; ?></td>
                                <td><?php echo $a->register_num; ?></td>
                                <td><?php echo $a->address; ?></td>
                                <td><?php echo $a->tell; ?></td>
                                <td><?php echo $a->phone; ?></td>
                                <td><?php echo $a->username; ?></td>
                                <td><img data-toggle="modal" data-target="#myModalimg<?php echo $a->id1; ?>" width="50px" height="50px;" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->evidence; ?>">
                                </td>
                            </tr>
                            <?php
                            $x++;
                        }
                    } else if ($rows == null) {
                        echo '<div style="color:red">موجود نیست</div>';
                    }
                    ?>
                </table>
                <div class="page">
                    <div class="page_in" id="ajax_pagingsearc">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
            </div>
            <?php foreach ($rows1 as $a) { ?>
                <div class="modal fade" id="myModalimg<?php echo $a->id1; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document" style="margin-top: -40px;margin-right: 250px">
                        <div class="modal-content">
                            <img style="width: 900px;height: 550px;" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->evidence; ?>">
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<script>
<?php foreach ($rows as $et): ?>
        $(document).ready(function () {
            $(document).on('change', '#status_estate_pending<?php echo $et->id1; ?>', function () {
                var val = $("#status_estate_pending<?php echo $et->id1; ?>").val();
                var id = <?php echo $et->id1; ?>;
                $.post("<?php echo base_url('site/status_satate'); ?>", {q: val, p: id}, function (data)
                {
                    if (data == 'تایید شده') {
                        $('#status_estate_pending<?php echo $et->id1; ?>').css('background-color', '#00a157');
                    } else if (data == 'در حال بررسی') {
                        $('#status_estate_pending<?php echo $et->id1; ?>').css('background-color', '#E67E22');
                    } else if (data == 'لغو شده') {
                        $('#status_estate_pending<?php echo $et->id1; ?>').css('background-color', '#c9302c');
                    }
                });
            });
        });
<?php endforeach; ?>
</script>
<script type="text/javascript">
    $(document).ready(function () {
        applyPagination();

        function applyPagination() {
            $("#ajax_pagingsearc a").click(function () {
                var url = $(this).attr("href");
                $.ajax({
                    type: "POST",
                    data: "ajax=1",
                    url: url,
                    success: function (msg) {
                        $(".ajax_show_estate").html(msg);
                        applyPagination();
                    }
                });
                return false;
            });
        }
    });
</script>