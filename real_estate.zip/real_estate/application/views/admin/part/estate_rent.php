<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {
        $('#show_search').hide();
        $(document).on('keyup', '#search_home', function () {
            var usercheck = $('#search_home').val();
            var value_category = $('.search_category').val();
            if (usercheck != '') {
                if (value_category != 'بر اساس') {
                    $.post("<?php echo base_url('site/search_home_rent'); ?>", {q: usercheck, p: value_category}, function (data)
                    {
                        if (data != '' || data != undefined || data != null)
                        {
                            if (data != 'موردی یافت نشد') {
                                $.post("<?php echo base_url('site/search_home_rent_show'); ?>", {q: data, p: value_category}, function (data1)
                                {
                                    if (data != '' || data != undefined || data != null)
                                    {
                                        $('#ajax_show_estate').hide();
                                        $('#show_search').show();
                                        $('#show_search').html(data1);
                                    }
                                });
                            } else {
                                $('#ajax_show_estate').hide();
                                $('#show_search').show();
                                $('#show_search').html(data);
                            }
                        }
                    });
                } else {
                    $('#ajax_show_estate').hide();
                    $('#show_search').show();
                    $('#show_search').html('نوع بر اساس را انتخاب کنید');
                }
            } else {
                $('#ajax_show_estate').show();
                $('#show_search').hide();
            }
        });
        $(document).on('change', '.search_category', function () {
            var usercheck = $('#search_home').val();
            var value_category = $('.search_category').val();
            if (usercheck != '') {
                if (value_category != 'بر اساس') {
                    $.post("<?php echo base_url('site/search_home_rent'); ?>", {q: usercheck, p: value_category}, function (data)
                    {
                        if (data != '' || data != undefined || data != null)
                        {
                            if (data != 'موردی یافت نشد') {
                                $.post("<?php echo base_url('site/search_home_rent_show'); ?>", {q: data, p: value_category}, function (data1)
                                {
                                    if (data != '' || data != undefined || data != null)
                                    {
                                        $('#ajax_show_estate').hide();
                                        $('#show_search').show();
                                        $('#show_search').html(data1);
                                    }
                                });
                            } else {
                                $('#ajax_show_estate').hide();
                                $('#show_search').show();
                                $('#show_search').html(data);
                            }
                        }
                    });
                }
            } else {
                 $('#ajax_show_estate').show();
                $('#show_search').hide();
            }
        });
    });
</script>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box">
            <div>
                <div class="col-lg-6 search_real_estate">
                    <div class="input-group">
                        <input type="text" id="search_home" class="form-control" placeholder="جستجو" aria-label="...">
                        <div class="input-group-btn">
                            <select class="search_category">
                                <option style="display: none;">بر اساس</option>
                                <option>قیمت</option>
                                <option>آدرس</option>
                                <option>اتاق خواب</option>
                                <option>متراژ</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <a href="<?php echo base_url('site/printpage_rent'); ?>">
            <div class="btn btn-info add">
                پرینت <i class="fa fa-print"></i>
            </div></a>
            <div class="box-body table-responsive no-padding ajax_show_estate" id="show_search">

            </div>
            <div class="box-body table-responsive no-padding ajax_show_estate" id="ajax_show_estate">
                <table class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>کد</th>
                        <th>نام کاربری</th>
                        <th>تاریخ ثبت</th>
                        <th>وضعیت</th>
                        <th>شماره تماس</th>
                        <th>شماره همراه</th>
                        <th>آدرس</th>
                        <th>قیمت</th>
                        <th>اتاق خواب</th>
                        <th>اسانسور</th>
                        <th>متراژ</th>
                        <th>پارکینگ</th>
                        <th>انبار</th>
                        <th>سال ساخت</th>
                        <th>توضیحات</th>
                        <th>عکس</th>
                    </tr>
                    <?php
                    $x = 0;
                    if ($rows != null) {
                        foreach ($rows as $a) {
                            ?>
                            <tr class="table_real_estate">
                                <td><?php echo $a->id_real_estate; ?></td>
                                <td><?php echo $a->username; ?></td>
                                <td><?php echo $a->register_date; ?></td>
                                <td>
                                    <div class="btn-group"> 
                                        <select id="status_estate" class="status_estate" style="color:white;
                                                <?php if ($a->type_rent == 'در حال اجاره') { ?>background-color: #00a157;<?php
                                                } elseif ($a->type_rent == 'اجاره داده شده') {
                                                    ?>background-color: #c9302c;<?php }
                                                ?>">
                                            <option style="display: none;"><?php echo $a->type_rent; ?></option>
                                        </select>
                                    </div>
                                </td>
                                <td><?php echo $a->tell_home; ?></td>
                                <td><?php echo $a->phone_home; ?></td>
                                <td><?php echo $a->address_home; ?></td>
                                <td><?php echo $a->price; ?></td>
                                <td><?php echo $a->bedroom; ?></td>
                                <td><?php echo $a->type1; ?></td>
                                <td><?php echo $a->area; ?></td>
                                <td><?php echo $a->type_parking; ?></td>
                                <td><?php echo $a->type_storehouse; ?></td>
                                <td><?php echo $a->build; ?></td>
                                <td><?php echo $a->description; ?></td>
                                <td style="cursor: pointer"><span data-toggle="modal" data-target="#myModalimg<?php echo $a->id_home;?>">گالری عکس</span>
                                </td>
                            </tr>

                            <?php
                            $x++;
                        }
                    } else if ($rows == null) {
                        echo '<div style="color:red">موجود نیست</div>';
                    }
                    ?>
                </table>
                <div class="page">
                    <div class="page_in" id="ajax_pagingsearc">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
            </div>
            <?php foreach ($rows1 as $a) { ?>
                <div class="modal fade" id="myModalimg<?php echo $a->id_home; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document" style="margin-right: 250px">
                        <div class="modal-content" style="width: 900px;">
                            <img class="img_home" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img1; ?>">
                            <img class="img_home" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img2; ?>">
                            <img class="img_home" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img3; ?>">
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        applyPagination();

        function applyPagination() {
            $("#ajax_pagingsearc a").click(function () {
                var url = $(this).attr("href");
                $.ajax({
                    type: "POST",
                    data: "ajax=1",
                    url: url,
                    success: function (msg) {
                        $(".ajax_show_estate").html(msg);
                        applyPagination();
                    }
                });
                return false;
            });
        }
    });
</script>