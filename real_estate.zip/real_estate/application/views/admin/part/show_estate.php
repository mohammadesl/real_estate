

<table id="printTable" class="table table-hover">
    <tr class="table_real_estate_title">
        <th>کد</th>
        <th>وضعیت</th>
        <th>نام املاک</th>
        <th>روز ثبت</th>
        <th>مدیر</th>
        <th>شماره ثبت</th>
        <th>آدرس</th>
        <th>شماره همراه</th>
        <th>شماره ثابت</th>
        <th>نام کاربری</th>
        <th>مدرک</th>
    </tr>
    <?php
    $x = 0;
    if ($rows != null) {
        foreach ($rows as $a) {
            ?>
            <tr class="table_real_estate">
                <td><?php echo $a->id1; ?></td>
                <td>
                    <div class="btn-group">
                        <select id="status_estate<?php echo $a->id1; ?>" class="status_estate" style="color:white;
                                <?php if ($a->type == 'تایید شده') { ?>background-color: #00a157;<?php
                                } elseif ($a->type == 'در حال بررسی') {
                                    ?>background-color: #E67E22;<?php
                                } elseif ($a->type == 'لغو شده') {
                                    ?>background-color: #c9302c;<?php }
                                ?>">
                            <option style="display: none;"><?php echo $a->type; ?></option>
                            <option style="display: none;"></option>
                            <option class="select_real_estate" value="2">تایید شده</option>
                            <option class="select_real_estate"value="1">در حال بررسی</option>
                            <option class="select_real_estate"value="3">لغو شده</option>
                        </select>
                        <div class="status<?php echo $a->id1; ?>"></div>
                    </div>
                </td>
                <td><?php echo $a->name; ?></td>
                <td><?php echo $a->date_ragister; ?></td>
                <td><?php echo $a->manager; ?></td>
                <td><?php echo $a->register_num; ?></td>
                <td><?php echo $a->address; ?></td>
                <td><?php echo $a->tell; ?></td>
                <td><?php echo $a->phone; ?></td>
                <td><?php echo $a->username; ?></td>
                <td><img data-toggle="modal" data-target="#myModalimg<?php echo $a->id1; ?>" width="50px" height="50px;" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->evidence; ?>">
                </td>
            </tr>
            <?php
            $x++;
        }
    } else if ($rows == null) {
        echo '<div style="color:red">موجود نیست</div>';
    }
    ?>
</table>
<div class="page">
    <div class="page_in" id="ajax_pagingsearc">
        <?php echo $this->pagination->create_links(); ?>
    </div>
</div>
<script>
<?php foreach ($rows as $et): ?>
        $(document).ready(function () {
            $(document).on('change', '#status_estate<?php echo $et->id1; ?>', function () {
                var val = $("#status_estate<?php echo $et->id1; ?>").val();
                var id = <?php echo $et->id1; ?>;
                $.post("<?php echo base_url('site/status_satate'); ?>", {q: val, p: id}, function (data)
                {
                    if (data == 'تایید شده') {
                        $('#status_estate<?php echo $et->id1; ?>').css('background-color', '#00a157');
                    } else if (data == 'در حال بررسی') {
                        $('#status_estate<?php echo $et->id1; ?>').css('background-color', '#E67E22');
                    } else if (data == 'لغو شده') {
                        $('#status_estate<?php echo $et->id1; ?>').css('background-color', '#c9302c');
                    }
                });
            });
        });
<?php endforeach; ?>
</script>