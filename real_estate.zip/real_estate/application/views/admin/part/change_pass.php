<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <h1 style="font-family: BYekan">تغییر رمز عبور</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6 col-sm-offset-3">
            <input type="password" class="input-lg form-control" name="password1" id="password1" placeholder="رمز عبور جدید" autocomplete="off">
            <div class="row">
                <div class="col-sm-6">
                    <span id="8char" class="fa fa-times" style="color:#FF0004;"></span> بیشتر از 8 حرف<br>
                    <span id="ucase" class="fa fa-times" style="color:#FF0004;"></span> یک حرف بزرگ
                </div>
                <div class="col-sm-6">
                    <span id="lcase" class="fa fa-times" style="color:#FF0004;"></span> یک حرف کوچک<br>
                    <span id="num" class="fa fa-times" style="color:#FF0004;"></span> یک کاراکتر عدد
                </div>
            </div>
            <input type="password" class="input-lg form-control" name="password2" id="password2" placeholder="تکرار رمز عبور" autocomplete="off">
            <div class="row">
                <div class="col-sm-12">
                    <span id="pwmatch" class="fa fa-times" style="color:#FF0004;"></span> برابری رمز عبور
                </div>
            </div>
            <input type="submit" class="col-xs-12 btn btn-primary btn-load btn-lg" data-loading-text="در حال تغییر..." value="تغییر" id="change_submit">
        </div><!--/col-sm-6-->
    </div><!--/row-->
</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {
        var x1 = 0, x2 = 0, x3 = 0, x4 = 0, x5 = 0;
        $("input[type=password]").keyup(function () {
            var ucase = new RegExp("[A-Z]+");
            var lcase = new RegExp("[a-z]+");
            var num = new RegExp("[0-9]+");
            if ($("#password1").val().length >= 8) {
                $("#8char").removeClass("fa fa-times");
                $("#8char").addClass("fa fa-check");
                $("#8char").css("color", "#00A41E");
                x1 = 1;
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
                    $('#change_submit').removeClass('disabled');
                } else {
                    $('#change_submit').addClass('disabled');
                }
            } else {
                $("#8char").removeClass("fa fa-check");
                $("#8char").addClass("fa fa-times");
                $("#8char").css("color", "#FF0004");
                x1 = 0;
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
                    $('#change_submit').removeClass('disabled');
                } else {
                    $('#change_submit').addClass('disabled');
                }
            }

            if (ucase.test($("#password1").val())) {
                $("#ucase").removeClass("fa fa-times");
                $("#ucase").addClass("fa fa-check");
                $("#ucase").css("color", "#00A41E");
                x2 = 1;
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
                    $('#change_submit').removeClass('disabled');
                } else {
                    $('#change_submit').addClass('disabled');
                }
            } else {
                $("#ucase").removeClass("fa fa-check");
                $("#ucase").addClass("fa fa-times");
                $("#ucase").css("color", "#FF0004");
                x2 = 0;
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
                    $('#change_submit').removeClass('disabled');
                } else {
                    $('#change_submit').addClass('disabled');
                }
            }

            if (lcase.test($("#password1").val())) {
                $("#lcase").removeClass("fa fa-times");
                $("#lcase").addClass("fa fa-check");
                $("#lcase").css("color", "#00A41E");
                x3 = 1;
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
                    $('#change_submit').removeClass('disabled');
                } else {
                    $('#change_submit').addClass('disabled');
                }
            } else {
                $("#lcase").removeClass("fa fa-check");
                $("#lcase").addClass("fa fa-times");
                $("#lcase").css("color", "#FF0004");
                x3 = 0;
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
                    $('#change_submit').removeClass('disabled');
                } else {
                    $('#change_submit').addClass('disabled');
                }
            }

            if (num.test($("#password1").val())) {
                $("#num").removeClass("fa fa-times");
                $("#num").addClass("fa fa-check");
                $("#num").css("color", "#00A41E");
                x4 = 1;
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
                    $('#change_submit').removeClass('disabled');
                } else {
                    $('#change_submit').addClass('disabled');
                }
            } else {
                $("#num").removeClass("fa fa-check");
                $("#num").addClass("fa fa-times");
                $("#num").css("color", "#FF0004");
                x4 = 0;
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
                    $('#change_submit').removeClass('disabled');
                } else {
                    $('#change_submit').addClass('disabled');
                }
            }

            if ($("#password1").val() == $("#password2").val()) {
                $("#pwmatch").removeClass("fa fa-times");
                $("#pwmatch").addClass("fa fa-check");
                $("#pwmatch").css("color", "#00A41E");
                x5 = 1;
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
                    $('#change_submit').removeClass('disabled');
                } else {
                    $('#change_submit').addClass('disabled');
                }
            } else {
                $("#pwmatch").removeClass("fa fa-check");
                $("#pwmatch").addClass("fa fa-times");
                $("#pwmatch").css("color", "#FF0004");
                x5 = 0;
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
                    $('#change_submit').removeClass('disabled');
                } else {
                    $('#change_submit').addClass('disabled');
                }
            }
        });
        if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1 & x5 == 1) {
            $('#change_submit').removeClass('disabled');
        } else {
            $('#change_submit').addClass('disabled');
        }

        $(document).on('click', '#change_submit', function () {
            var pass = $('#password1').val();
            $.post('<?php echo base_url('site/pass'); ?>', {q1: pass}, function (data) {
                alert(data);
            });
        });
    });
</script>