<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.2/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<div  class="row">
    <ul class="ul_gallery">
        <?php foreach ($rows as $a) { ?>
            <span class="item">
                <?php if ($a->img1 != 'no.png') { ?>
                    <li class="img_gallery"> 
                        <span data-toggle="modal" data-target="#myModalimg<?php echo $a->id_home; ?>1">
                            <span style="color: red;">حذف</span>
                            <img class="img-responsive" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img1; ?>">
                            <span><?php echo $a->username; ?></span>
                        </span>
                    </li>
                <?php } ?>
                <?php if ($a->img2 != 'no.png') { ?>
                    <li class="img_gallery" >
                        <span data-toggle="modal" data-target="#myModalimg<?php echo $a->id_home; ?>2">
                            <span style="color: red;">حذف</span>
                            <img class="img-responsive" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img2; ?>">
                            <span><?php echo $a->username; ?></span>
                        </span>
                    </li>
                <?php } ?>
                <?php if ($a->img3 != 'no.png') { ?>
                    <li class="img_gallery"> 
                        <span data-toggle="modal" data-target="#myModalimg<?php echo $a->id_home; ?>3">
                            <span style="color: red;">حذف</span>
                            <img class="img-responsive" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img3; ?>">
                            <span><?php echo $a->username; ?></span>
                        </span>
                    </li>
                <?php } ?>
            </span>
        <?php } ?>

    </ul><br>
    <div class="page">
        <div class="page_in" id="ajax_pagingsearc">
            <?php echo $this->pagination->create_links(); ?>
        </div>
    </div>
    <?php foreach ($rows as $a) { ?>
        <div class="modal fade" id="myModalimg<?php echo $a->id_home; ?>1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="margin-top: -100px;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title font_title" id="myModalLabel">حذف</h4>
                    </div>
                    <div class="modal-body" id="form">
                        آیا مطمئن هستید که می خواهید این عکس را حذف کنید؟
                    </div>
                    <div class="modal-body modal-body1" id="resend_add"></div>
                    <div class="modal-footer" >
                        <button type="button" id="close_form" class="btn btn-default font_title" data-dismiss="modal">خیر</button>
                        <input name="submit" type="submit" id="remove_home<?php echo $a->id_home; ?>1" class="btn btn-danger font_title" value="بله">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="myModalimg<?php echo $a->id_home; ?>2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="margin-top: -100px;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title font_title" id="myModalLabel">حذف</h4>
                    </div>
                    <div class="modal-body" id="form">
                        آیا مطمئن هستید که می خواهید این عکس را حذف کنید؟
                    </div>
                    <div class="modal-body modal-body1" id="resend_add"></div>
                    <div class="modal-footer" >
                        <button type="button" id="close_form" class="btn btn-default font_title" data-dismiss="modal">خیر</button>
                        <input name="submit" type="submit" id="remove_home<?php echo $a->id_home; ?>2" class="btn btn-danger font_title" value="بله">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="myModalimg<?php echo $a->id_home; ?>3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="margin-top: -100px;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title font_title" id="myModalLabel">حذف</h4>
                    </div>
                    <div class="modal-body" id="form">
                        آیا مطمئن هستید که می خواهید این عکس را حذف کنید؟
                    </div>
                    <div class="modal-body modal-body1" id="resend_add"></div>
                    <div class="modal-footer" >
                        <button type="button" id="close_form" class="btn btn-default font_title" data-dismiss="modal">خیر</button>
                        <input name="submit" type="submit" id="remove_home<?php echo $a->id_home; ?>3" class="btn btn-danger font_title" value="بله">
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        applyPagination();

        function applyPagination() {
            $("#ajax_pagingsearc a").click(function () {
                var url = $(this).attr("href");
                $.ajax({
                    type: "POST",
                    data: "ajax=1",
                    url: url,
                    success: function (msg) {
                        $(".row").html(msg);
                        applyPagination();
                    }
                });
                return false;
            });
        }
    });
<?php foreach ($rows as $b) { ?>
        $(document).ready(function () {
            $(document).on('click', '#remove_home<?php echo $b->id_home; ?>1', function () {
                var id = <?php echo $b->id_home; ?>;
                $.post('<?php echo base_url('site/remove_img'); ?>', {q1: id, q2: 1}, function (data) {
                    alert(data);
                });
            });
            $(document).on('click', '#remove_home<?php echo $b->id_home; ?>2', function () {
                var id = <?php echo $b->id_home; ?>;
                $.post('<?php echo base_url('site/remove_img'); ?>', {q1: id, q2: 2}, function (data) {
                    alert(data);
                });
            });
            $(document).on('click', '#remove_home<?php echo $b->id_home; ?>3', function () {
                var id = <?php echo $b->id_home; ?>;
                $.post('<?php echo base_url('site/remove_img'); ?>', {q1: id, q2: 3}, function (data) {
                    alert(data);
                });
            });
        });
<?php } ?>
</script>