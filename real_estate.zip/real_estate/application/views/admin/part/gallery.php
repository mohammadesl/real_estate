<ul class="ul_gallery">
    <?php foreach ($rows as $a) { ?>
        <span class="item">
            <?php if ($a->img1 != 'no.png') { ?>
                <li class="img_gallery" >
                    <span style="color: red;">حذف</span>
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img1; ?>">
                    <span><?php echo $a->username; ?></span>
                </li>
            <?php } ?>
            <?php if ($a->img2 != 'no.png') { ?>
                <li class="img_gallery">
                    <span style="color: red;">حذف</span>
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img2; ?>">
                    <span><?php echo $a->username; ?></span>
                </li>
            <?php } ?>
            <?php if ($a->img3 != 'no.png') { ?>
                <li class="img_gallery">
                    <span style="color: red;">حذف</span>
                    <img class="img-responsive" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img3; ?>">
                    <span><?php echo $a->username; ?></span>
                </li>
            <?php } ?>
        </span>
    <?php } ?>

</ul>
<div class="page">
    <div class="page_in" id="ajax_pagingsearc">
        <?php echo $this->pagination->create_links(); ?>
    </div>
</div>