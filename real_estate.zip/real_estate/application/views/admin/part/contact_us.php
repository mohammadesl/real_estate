<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<div class="box"> 
    <ul class="row" style="margin-top: 55px;">
        <?php
        $x = 0;
        foreach($rows as $record) {
            ?>
            <li class="col-lg-5 col-md-4 col-sm-5 col-xs-5 message_box" id="message<?php echo $record->id; ?>" data-toggle="modal" data-target="#myModal_message<?php echo $x; ?>">
                <span><?php echo $record->email; ?></span><br>
                <?php if ($record->seen_admin == 0) { ?>
                    <i class="fa fa-bell bell_style" ></i>
    <?php } ?>
            </li>
            <div class="modal fade" id="myModal_message<?php echo $x; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content" style="margin-top: -80px;">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <textarea name="message" id="pm<?php echo $record->id; ?>" class="form-control" placeholder="متن پیام"></textarea>
                            <input style="margin-top: 10px;" class="btn btn-lg btn-success btn-block" name="submit" type="submit" value="ارسال" id="send<?php echo $record->id; ?>">
                        </div>
                        <div class="modal-body  modal-body1" id="form">
                            <div class="message_box_show" id="msg<?php echo $record['id']; ?>">
                                <?php
                                $mysqli = mysqli_connect("localhost", "root", "", "real_estate");
                                $query1 = 'SELECT  * FROM contact_us WHERE email = "' . $record->email . '"order by id DESC';
                                $result1 = mysqli_query($mysqli,$query1);
                                while ($record1 = mysqli_fetch_assoc($result1)) {
                                    if ($record1['send'] == 1) {
                                        ?>
                                        <div class="message_box_show_out">
                                            <span class="date_message"><?php echo $record1['date']; ?></span><br>
                                        <?php echo $record1['message']; ?></div>
        <?php } else { ?>
                                        <div class="message_box_show_in">
                                            <span class="date_message"><?php echo $record1['date']; ?></span><br>
                                            <?php echo $record1['message']; ?></div>
                                            <?php
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
    <?php $x++;
} ?>
    </ul>
</div>
<script>
<?php
$mysqli = mysqli_connect("localhost", "root", "", "real_estate");
$query = 'SELECT  * FROM contact_us a WHERE a.id = (SELECT  MAX(id) id FROM contact_us b WHERE   a.email = b.email ) order by id DESC ';
$result = mysqli_query($mysqli,$query);
$y = 0;
while ($record = mysqli_fetch_assoc($result)) {
    ?>
        $(document).ready(function () {
            refresh();
            function refresh() {
                setTimeout(function () {
                    $('#msg<?php echo $record['id']; ?>').load('<?php echo base_url('site/msg2'); ?>?x=<?php echo $record['id']; ?>');
                                    refresh();
                                }, 5000);
                            }
                            ;
                            var y3 = 0;
                            $(document).on('blur', '#pm<?php echo $record['id']; ?>', function () {
                                if ($('#pm<?php echo $record['id']; ?>').val() == null || $('#pm<?php echo $record['id']; ?>').val() == "") {
                                    alert('پیغام را وارد کنید');
                                    $('#pm<?php echo $record['id']; ?>').css('border-color', 'red');
                                    y3 = 0;
                                    if (y3 == 1) {
                                        $('#send<?php echo $record['id']; ?>').removeClass('disabled');
                                    } else {
                                        $('#send<?php echo $record['id']; ?>').addClass('disabled');
                                    }
                                } else {
                                    $('#pm<?php echo $record['id']; ?>').css('border-color', 'green');
                                    y3 = 1;
                                    if (y3 == 1) {
                                        $('#send<?php echo $record['id']; ?>').removeClass('disabled');
                                    } else {
                                        $('#send<?php echo $record['id']; ?>').addClass('disabled');
                                    }
                                }
                            });
                            if (y3 == 1) {
                                $('#send<?php echo $record['id']; ?>').removeClass('disabled');
                            } else {
                                $('#send<?php echo $record['id']; ?>').addClass('disabled');
                            }
                            $(document).on('click', '#message<?php echo $record['id']; ?>', function () {
                                var id = <?php echo $record['id']; ?>;
                                $.post("<?php echo base_url('site/noti_message2'); ?>", {q: id});
                            });
                            $(document).on('click', '#send<?php echo $record['id']; ?>', function () {
                                var message = $('#pm<?php echo $record['id']; ?>').val();
                                var id = <?php echo $record['id']; ?>;
                                $.post("<?php echo base_url('site/send_pm2'); ?>", {q1: message, q2: id}, function () {
                                    alert('ارسال شد');
                                });
                            });

                        });
<?php } ?>

</script>