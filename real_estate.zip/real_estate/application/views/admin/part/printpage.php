<?php require_once 'template/admin_header.php'; ?>
<div class="box-body table-responsive no-padding">
    <table id="printTable" class="table table-hover">
        <tr class="table_real_estate_title">
            <th>کد</th>
            <th>نام املاک</th>
            <th>روز ثبت</th>
            <th>وضعیت</th>
            <th>مدیر</th>
            <th>شماره ثبت</th>
            <th>آدرس</th>
            <th>شماره همراه</th>
            <th>شماره ثابت</th>
            <th>نام کاربری</th>
        </tr>
        <?php
        if ($rows != null) {
            foreach ($rows as $a) {
                ?>
                <tr class="table_real_estate">
                    <td><?php echo $a->id; ?></td>
                    <td><?php echo $a->name; ?></td>
                    <td><?php echo $a->date_ragister; ?></td>
                    <td>
                        <div class="btn-group"> 
                            <button type="button" class="btn <?php if ($a->status == 1) { ?> btn-warning <?php } elseif ($a->status == 2) { ?> btn-success <?php } elseif ($a->status == 3) { ?> btn-danger <?php } ?> dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo $a->type; ?> <span class="caret"></span>
                            </button>
                        </div>
                    </td>
                    <td><?php echo $a->manager; ?></td>
                    <td><?php echo $a->register_num; ?></td>
                    <td><?php echo $a->address; ?></td>
                    <td><?php echo $a->tell; ?></td>
                    <td><?php echo $a->phone; ?></td>
                    <td><?php echo $a->username; ?></td>
                </tr>
                <?php
            }
        } else if ($rows == null) {
            echo '<div style="color:red">موجود نیست</div>';
        }
        ?>

    </table>
</div>
<script>
    
        window.print();
    
</script>