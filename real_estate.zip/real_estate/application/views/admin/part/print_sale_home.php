<?php require_once 'template/admin_header.php'; ?>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box">
            <div class="box-body table-responsive no-padding ajax_show_estate">
                <table class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>کد</th>
                        <th>نام املاک</th>
                        <th>تاریخ ثبت</th>
                        <th>وضعیت</th>
                        <th>شماره تماس</th>
                        <th>شماره همراه</th>
                        <th>آدرس</th>
                        <th>قیمت</th>
                        <th>اتاق خواب</th>
                        <th>اسانسور</th>
                        <th>متراژ</th>
                        <th>پارکينگ</th>
                        <th>انبار</th>
                        <th>سال ساخت</th>
                        <th>توضیحات</th>
                    </tr>
                    <?php
                    $x = 0;
                    if ($rows != null) {
                        foreach ($rows as $a) {
                            ?>
                            <tr class="table_real_estate">
                                <td><?php echo $a->id_real_estate; ?></td>
                                <td><?php echo $a->name; ?></td>
                                <td><?php echo $a->register_date; ?></td>
                                <td>
                                    <div class="btn-group"> 
                                        <select id="status_estate" class="status_estate">
                                            <option style="display: none;"><?php echo $a->type_sale; ?></option>
                                        </select>
                                    </div>
                                </td>
                                <td><?php echo $a->tell_home; ?></td>
                                <td><?php echo $a->phone_home; ?></td>
                                <td><?php echo $a->address_home; ?></td>
                                <td><?php echo $a->price; ?></td>
                                <td><?php echo $a->bedroom; ?></td>
                                <td><?php echo $a->type1; ?></td>
                                <td><?php echo $a->area; ?></td>
                                <td><?php echo $a->type_parking; ?></td>
                                <td><?php echo $a->type_storehouse; ?></td>
                                <td><?php echo $a->build; ?></td>
                                <td><?php echo $a->description; ?></td>
                            </tr>

                            <?php
                            $x++;
                        }
                    } else if ($rows == null) {
                        echo '<div style="color:red">موجود نیست</div>';
                    }
                    ?>
                </table>
            </div>
        </div>
    </div>
</div>
<script>

    window.print();

</script>