<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"></script>
<script>
    $.widget.bridge('uibutton', $.ui.button);
</script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/app.js"></script>
</body>
</html>