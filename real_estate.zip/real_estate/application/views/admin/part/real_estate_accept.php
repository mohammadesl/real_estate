<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {
        $('#show_search').hide();
        $('#resend_add').hide();
        var y1, y2, y3, y4, y5, y6, y7, y8, y9;
        y1 = 0;
        y2 = 0;
        y3 = 0;
        y4 = 0;
        y5 = 0;
        y6 = 0;
        y7 = 0;
        y8 = 0;
        y9 = 0;
        var x1 = 0, x2 = 0, x3 = 0, x4 = 0;
        var z = 0;
        $("input[type=password]").keyup(function () {
            var ucase = new RegExp("[A-Z]+");
            var lcase = new RegExp("[a-z]+");
            var num = new RegExp("[0-9]+");
            if ($("#pass").val().length >= 8) {
                $("#8char").removeClass("fa fa-times");
                $("#8char").addClass("fa fa-check");
                $("#8char").css("color", "#00A41E");
                x1 = 1;
            } else {
                $("#8char").removeClass("fa fa-check");
                $("#8char").addClass("fa fa-times");
                $("#8char").css("color", "#FF0004");
                x1 = 0;
            }

            if (ucase.test($("#pass").val())) {
                $("#ucase").removeClass("fa fa-times");
                $("#ucase").addClass("fa fa-check");
                $("#ucase").css("color", "#00A41E");
                x2 = 1;
            } else {
                $("#ucase").removeClass("fa fa-check");
                $("#ucase").addClass("fa fa-times");
                $("#ucase").css("color", "#FF0004");
                x2 = 0;
            }

            if (lcase.test($("#pass").val())) {
                $("#lcase").removeClass("fa fa-times");
                $("#lcase").addClass("fa fa-check");
                $("#lcase").css("color", "#00A41E");
                x3 = 1;
            } else {
                $("#lcase").removeClass("fa fa-check");
                $("#lcase").addClass("fa fa-times");
                $("#lcase").css("color", "#FF0004");
                x3 = 0;
            }

            if (num.test($("#pass").val())) {
                $("#num").removeClass("fa fa-times");
                $("#num").addClass("fa fa-check");
                $("#num").css("color", "#00A41E");
                x4 = 1;
            } else {
                $("#num").removeClass("fa fa-check");
                $("#num").addClass("fa fa-times");
                $("#num").css("color", "#FF0004");
                x4 = 0;
            }
        });
        $(document).on('blur', '#name', function () {
            if ($('#name').val() == null || $('#name').val() == "") {
                $("#msg_name").html('لطفا نام املاک را وارد کنید');
                $('#name').css('border-color', 'red');
                $("#msg_name").css('color', 'red');
                y1 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                $('#name').css('border-color', 'green');
                $("#msg_name").html('قابل قبول');
                $("#msg_name").css('color', 'green');
                y1 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#img', function () {
            if ($('#img').val() == null || $('#img').val() == "") {
                $("#msg_img").html('گواهی را ارسال کنید');
                $('#img').css('border-color', 'red');
                $("#msg_img").css('color', 'red');
                y2 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                $('#img').css('border-color', 'green');
                $("#msg_img").html('قابل قبول');
                $("#msg_img").css('color', 'green');
                y2 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#manager', function () {
            if ($('#manager').val() == null || $('#manager').val() == "") {
                $("#msg_manager").html('نام مدیر را وارد کنید');
                $('#manager').css('border-color', 'red');
                $("#msg_manager").css('color', 'red');
                y3 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                $('#manager').css('border-color', 'green');
                $("#msg_manager").html('قابل قبول');
                $("#msg_manager").css('color', 'green');
                y3 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#register', function () {
            if ($('#register').val() == null || $('#register').val() == "") {
                $("#msg_reg").html('شماره ثبت را وارد کنید');
                $('#register').css('border-color', 'red');
                $("#msg_reg").css('color', 'red');
                y4 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                $('#register').css('border-color', 'green');
                $("#msg_reg").html('قابل قبول');
                $("#msg_reg").css('color', 'green');
                y4 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#phone', function () {
            if ($('#phone').val() == null || $('#phone').val() == "") {
                $("#msg_phone").html('تلفن همراه را ارسال کنید');
                $('#phone').css('border-color', 'red');
                $("#msg_phone").css('color', 'red');
                y5 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                if ($("#phone").val().length == 11) {
                    $('#phone').css('border-color', 'green');
                    $("#msg_phone").html('قابل قبول');
                    $("#msg_phone").css('color', 'green');
                    y5 = 1;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                        $('#add_member').removeClass('disabled');
                    } else {
                        $('#add_member').addClass('disabled');
                    }
                } else {
                    $("#msg_phone").html('تعداد ارقام باید 11 باشد .');
                    $('#phone').css('border-color', 'red');
                    $("#msg_phone").css('color', 'red');
                    y5 = 0;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                        $('#add_member').removeClass('disabled');
                    } else {
                        $('#add_member').addClass('disabled');
                    }
                }
            }
        });
        $(document).on('blur', '#tell', function () {
            if ($('#tell').val() == null || $('#tell').val() == "") {
                $("#msg_tell").html('تلفن ثابت را وارد کنید');
                $('#tell').css('border-color', 'red');
                $("#msg_tell").css('color', 'red');
                y6 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                if ($("#tell").val().length == 11) {
                    $('#tell').css('border-color', 'green');
                    $("#msg_tell").html('قابل قبول');
                    $("#msg_tell").css('color', 'green');
                    y6 = 1;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                        $('#add_member').removeClass('disabled');
                    } else {
                        $('#add_member').addClass('disabled');
                    }
                } else {
                    $("#msg_tell").html('تعداد ارقام باید 11 باشد .');
                    $('#tell').css('border-color', 'red');
                    $("#msg_tell").css('color', 'red');
                    y6 = 0;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                        $('#add_member').removeClass('disabled');
                    } else {
                        $('#add_member').addClass('disabled');
                    }
                }
            }
        });
        $(document).on('blur', '#address', function () {
            if ($('#address').val() == null || $('#address').val() == "") {
                $("#msg_address").html('آدرس را وارد کنید');
                $('#address').css('border-color', 'red');
                $("#msg_address").css('color', 'red');
                y7 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                $('#address').css('border-color', 'green');
                $("#msg_address").html('قابل قبول');
                $("#msg_address").css('color', 'green');
                y7 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#username', function () {
            var usercheck = $("#username").val();
            if ($('#username').val() == null || $('#username').val() == "") {
                $("#msg_user").html('نام کاربری را وارد کنید');
                $('#username').css('border-color', 'red');
                $("#msg_user").css('color', 'red');
                y8 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                $.post("<?php echo base_url('site/check_user'); ?>", {user_name: usercheck}, function (data)
                {
                    if (data != '' || data != undefined || data != null)
                    {
                        $('#msg_user').html(data);
                        $("#msg_user").css('color', 'red');
                        if (data == '<span id="user_id_span" class="add_estate1">قابل قبول</span>') {
                            $('#username').css('border-color', 'green');
                            $("#msg_user").css('color', 'green');
                            y8 = 1;
                            if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                                $('#add_member').removeClass('disabled');
                            } else {
                                $('#add_member').addClass('disabled');
                            }
                        } else {
                            $('#username').css('border-color', 'red');
                            y8 = 0;
                            if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                                $('#add_member').removeClass('disabled');
                            } else {
                                $('#add_member').addClass('disabled');
                            }
                        }
                    }
                });
            }
        });
        $(document).on('blur', '#pass', function () {
            if ($('#pass').val() == null || $('#pass').val() == "") {
                $("#msg_pass").html('رمز عبور را وارد کنید');
                $('#pass').css('border-color', 'red');
                $("#msg_pass").css('color', 'red');
                y9 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }
            } else {
                if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1) {
                    $('#pass').css('border-color', 'green');
                    $("#msg_pass").html('قابل قبول');
                    $("#msg_pass").css('color', 'green');
                    y9 = 1;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                        $('#add_member').removeClass('disabled');
                    } else {
                        $('#add_member').addClass('disabled');
                    }
                } else {
                    $("#msg_pass").html('غیر قابل قبول');
                    $('#pass').css('border-color', 'red');
                    $("#msg_pass").css('color', 'red');
                    y9 = 0;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                        $('#add_member').removeClass('disabled');
                    } else {
                        $('#add_member').addClass('disabled');
                    }
                }
            }
        });
        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
            $('#add_member').removeClass('disabled');
        } else {
            $('#add_member').addClass('disabled');
        }
        $(document).on('keyup', '#search_estate', function () {
            var usercheck = $('#search_estate').val();
            var value_category = $('.search_category').val();
            if (usercheck != '') {
                if (value_category != 'بر اساس') {
                    $.post("<?php echo base_url('site/search_real_estate'); ?>", {q: usercheck, p: value_category}, function (data)
                    {
                        if (data != '' || data != undefined || data != null)
                        {
                            if (data != 'موردی یافت نشد') {
                                $.post("<?php echo base_url('site/search_real_estate_show'); ?>", {q: data, p: value_category}, function (data1)
                                {
                                    if (data != '' || data != undefined || data != null)
                                    {
                                        $('#ajax_show_estate').hide();
                                        $('#show_search').show();
                                        $('#show_search').html(data1);
                                    }
                                });
                            } else {
                                $('#ajax_show_estate').hide();
                                $('#show_search').show();
                                $('#show_search').html(data);
                            }
                        }
                    });
                } else {
                    $('#ajax_show_estate').hide();
                    $('#show_search').show();
                    $('#show_search').html('نوع بر اساس را انتخاب کنید');
                }
            } else {
                $('#ajax_show_estate').show();
                $('#show_search').hide();
            }
        });
        $(document).on('change', '.search_category', function () {
            if ($('.search_category').val() == 'وضعیت') {
                alert('برای جستجو بر اساس وضیت برای سهولت شما بر اساس جدول زیر جستجو کنید.\n\ 1 = در حال بررسی\n\ 2 = تایید شده\n\ 3 = لغو شده');
            }
            var usercheck = $('#search_estate').val();
            var value_category = $('.search_category').val();
            if (usercheck != '') {
                if (value_category != 'بر اساس') {
                    $.post("<?php echo base_url('site/search_real_estate'); ?>", {q: usercheck, p: value_category}, function (data)
                    {
                        if (data != '' || data != undefined || data != null)
                        {
                            if (data != 'موردی یافت نشد') {
                                $.post("<?php echo base_url('site/search_real_estate_show'); ?>", {q: data, p: value_category}, function (data1)
                                {
                                    if (data != '' || data != undefined || data != null)
                                    {
                                        $('#ajax_show_estate').hide();
                                        $('#show_search').show();
                                        $('#show_search').html(data1);
                                    }
                                });
                            } else {
                                $('#ajax_show_estate').hide();
                                $('#show_search').show();
                                $('#show_search').html(data);
                            }
                        }
                    });
                }
            } else {
                $('#ajax_show_estate').show();
                $('#show_search').hide();
            }
        });
        $('#form1').submit(function (e) {

            e.preventDefault();
            var formData = new FormData($("#form1")[0]);
            if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                $.ajax({
                    url: '<?php echo base_url('site/form'); ?>',
                    type: "POST",
                    data: formData,
                    fileElementId: 'image',
                    async: false,
                    success: function (data)
                    {
                        $('#add_member').hide();
                        $('#form').hide();
                        $('#resend_add').show();
                        $('#resend_add').html(data);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                });
                return false;
            } else {
                alert('پرکردن تمامی فیلد ها اجباری است.');
            }
        });

        $(document).on('click', '#close_form', function () {
            $('#add_member').show();
            $('#form').show('');
            $('#resend_add').hide();
        });
    });

</script>

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box">
            <div>
                <div class="col-lg-6 search_real_estate">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="جستجو" aria-label="..." id="search_estate">
                        <div class="input-group-btn">
                            <select class="search_category">
                                <option style="display: none;">بر اساس</option>
                                <option>نام کاربری</option>
                                <option>آدرس</option>
                                <option>مدیر</option>
                                <option>شماره ثبت</option>
                                <option>وضعیت</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="btn btn-info add" data-toggle="modal" data-target="#myModal">
                افزودن <i class="fa fa-plus"></i>
            </div>
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">

                    <div class="modal-content" style="margin-top: -80px;">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title font_title" id="myModalLabel">افزودن</h4>
                        </div>
                        <form action="" method="post" name="form1" id="form1">
                            <div class="modal-body  modal-body1" id="form">
                                <div class="form-group form-group1">
                                    <label class="control-label col-sm-2 size_font" for="name">نام املاک:</label>
                                    <div class="col-sm-7">          
                                        <input type="text" class="form-control" name="name" id="name">
                                    </div>
                                    <div class="col-sm-3 add_estate" id="msg_name"></div>
                                </div>
                                <div class="form-group form-group1">
                                    <label class="control-label col-sm-2 size_font" for="manager">مدیر :</label>
                                    <div class="col-sm-7">          
                                        <input type="text" class="form-control" name="manager" id="manager">
                                    </div>
                                    <div class="col-sm-3 add_estate" id="msg_manager"></div>
                                </div>
                                <div class="form-group form-group1">
                                    <label class="control-label col-sm-2 size_font" for="register">شماره ثبت :</label>
                                    <div class="col-sm-7">          
                                        <input type="text" class="form-control" name="register" maxlength="11" id="register" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                                    </div>
                                    <div class="col-sm-3 add_estate" id="msg_reg"></div>
                                </div>
                                <div class="form-group form-group1">
                                    <label class="control-label col-sm-2 size_font" for="phone">شماره همراه :</label>
                                    <div class="col-sm-7">          
                                        <input type="text" class="form-control" name="phone" id="phone" maxlength="11" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                                    </div>
                                    <div class="col-sm-3 add_estate" id="msg_phone"></div>
                                </div>
                                <div class="form-group form-group1">
                                    <label class="control-label col-sm-2 size_font" for="tell">شماره ثابت :</label>
                                    <div class="col-sm-7">          
                                        <input type="text" class="form-control" name="tell" id="tell" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                                    </div>
                                    <div class="col-sm-3 add_estate" id="msg_tell"></div>
                                </div>
                                <div class="form-group form-group1">
                                    <label class="control-label col-sm-2 size_font" for="address">ادرس  :</label>
                                    <div class="col-sm-7">          
                                        <input type="text" class="form-control" name="address" id="address">
                                    </div>
                                    <div class="col-sm-3 add_estate" id="msg_address"></div>
                                </div>
                                <div class="form-group form-group1">
                                    <label class="control-label col-sm-2 size_font" for="img">مدرک املاک :</label>
                                    <div class="col-sm-7">          
                                        <input type="file" class="form-control" name="img" id="img">
                                    </div>
                                    <div class="col-sm-3 add_estate" id="msg_img"></div>
                                </div>
                                <div class="form-group form-group1">
                                    <label class="control-label col-sm-2 size_font" for="user">نام کاربری :</label>
                                    <div class="col-sm-7">          
                                        <input type="text" class="form-control" name="user" id="username">
                                    </div>
                                    <div class="col-sm-3 add_estate" id="msg_user"></div>
                                    <div class="col-sm-3" id="msg_user2">
                                    </div>
                                </div>
                                <div class="form-group form-group1">
                                    <label class="control-label col-sm-2 size_font" for="pass">رمز عبور :</label>
                                    <div class="col-sm-7">          
                                        <input type="password" class="form-control" name="pass" id="pass">
                                    </div>
                                    <div class="col-sm-3 add_estate" id="msg_pass"></div>
                                </div>
                                <div class="form-group form-group1 size_font">
                                    <label class="control-label col-sm-2 size_font" for="pass"></label>
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <span id="8char" class="fa fa-times" style="color:#FF0004;"></span> بیشتر از 8 حرف<br>
                                            <span id="ucase" class="fa fa-times" style="color:#FF0004;"></span> یک حرف بزرگ
                                        </div>
                                        <div class="col-sm-4">
                                            <span id="lcase" class="fa fa-times" style="color:#FF0004;"></span> یک حرف کوچک<br>
                                            <span id="num" class="fa fa-times" style="color:#FF0004;"></span> یک کاراکتر عدد
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="modal-body modal-body1" id="resend_add" style="margin-top: -20px"></div>
                            <div class="modal-footer" style="margin-top: -20px">
                                <button type="button" id="close_form" class="btn btn-default font_title" data-dismiss="modal">بستن</button>
                                <input name="submit" type="submit" id="add_member" class="btn btn-primary font_title" value="افزودن">
                            </div>
                        </form>
                    </div>

                </div>

            </div> 

            <a href="<?php echo base_url('site/printpage'); ?>"><div class="btn btn-info add">
                    پرینت <i class="fa fa-print"></i>
                </div></a>
            <div class="box-body table-responsive no-padding ajax_show_estate" id="show_search">

            </div>
            <div class="box-body table-responsive no-padding ajax_show_estate"  id="ajax_show_estate">
                <table id="printTable" class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>کد</th>
                        <th>وضعیت</th>
                        <th>نام املاک</th>
                        <th>روز ثبت نام</th>
                        <th>مدیر</th>
                        <th>شماره ثبت</th>
                        <th>آدرس</th>
                        <th>شماره همراه</th>
                        <th>شماره ثابت</th>
                        <th>نام کاربری</th>
                        <th>مدرک</th>
                        <th>ویرایش</th>
                    </tr>
                    <?php
                    $x = 0;
                    if ($rows != null) {
                        foreach ($rows as $a) {
                            ?>
                            <tr class="table_real_estate">
                                <td><?php echo $a->id1; ?></td>
                                <td>
                                    <div class="btn-group"> 
                                        <select id="status_estate<?php echo $a->id1; ?>" class="status_estate" style="color:white;
                                                <?php if ($a->type == 'تایید شده') { ?>background-color: #00a157;<?php
                                                } elseif ($a->type == 'در حال بررسی') {
                                                    ?>background-color: #E67E22;<?php
                                                } elseif ($a->type == 'لغو شده') {
                                                    ?>background-color: #c9302c;<?php }
                                                ?>">
                                            <option style="display: none;"><?php echo $a->type; ?></option>
                                            <option style="display: none;"></option>
                                            <option class="select_real_estate" value="2">تایید شده</option>
                                            <option class="select_real_estate"value="1">در حال بررسی</option>
                                            <option class="select_real_estate"value="3">لغو شده</option>
                                        </select>
                                        <div class="status<?php echo $a->id1; ?>"></div>
                                    </div>
                                </td>
                                <td><?php echo $a->name; ?></td>
                                <td><?php echo $a->date_ragister; ?></td>
                                <td><?php echo $a->manager; ?></td>
                                <td><?php echo $a->register_num; ?></td>
                                <td><?php echo $a->address; ?></td>
                                <td><?php echo $a->tell; ?></td>
                                <td><?php echo $a->phone; ?></td>
                                <td><?php echo $a->username; ?></td>
                                <td><img data-toggle="modal" data-target="#myModalimg<?php echo $a->id1; ?>" width="50px" height="50px;" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->evidence; ?>">
                                </td>
                                <td style="text-align: center"><i class="fa fa-pencil-square-o edit" data-toggle="modal" data-target="#myModaledit<?php echo $a->id1; ?>"></i></td>
                            </tr>
                            <?php
                            $x++;
                        }
                    } else if ($rows == null) {
                        echo '<div style="color:red">موجود نیست</div>';
                    }
                    ?>
                </table>
                <div class="page">
                    <div class="page_in" id="ajax_pagingsearc">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
            </div>
            <?php foreach ($rows1 as $r) { ?>
                <div class="modal fade" id="myModalimg<?php echo $r->id1; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document" style="margin-top: -40px;margin-right: 250px">
                        <div class="modal-content">
                            <img style="width: 900px;height: 550px;" src="<?php echo base_url(); ?>assets/upload/<?php echo $r->evidence; ?>">
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="myModaledit<?php echo $r->id1; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document" style="margin-top: -40px">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title font_title" id="myModalLabel">ویرایش</h4>
                            </div>
                            <form action="" method="post" name="form2<?php echo $r->id1; ?>" id="form2<?php echo $r->id1; ?>">
                                <div class="modal-body  modal-body1" id="form">
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="name">نام املاک:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" value="<?php echo $r->name; ?>" name="name" id="name<?php echo $r->id1; ?>">
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_name"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="manager">مدیر :</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" value="<?php echo $r->manager; ?>"  name="manager" id="manager<?php echo $r->id1; ?>">
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_manager"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="register">شماره ثبت :</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="register" value="<?php echo $r->register_num; ?>"  id="register" disabled>
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_reg"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="phone">شماره همراه :</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" value="<?php echo $r->phone; ?>"  name="phone" maxlength="11" id="phone<?php echo $r->id1; ?>" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_phone"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="tell">شماره ثابت :</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="tell" value="<?php echo $r->tell; ?>"  maxlength="11" id="tell<?php echo $r->id1; ?>" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_tell"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="address">ادرس  :</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="address" value="<?php echo $r->address; ?>"  id="address<?php echo $r->id1; ?>">
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_address"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="user">نام کاربری :</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" value="<?php echo $r->username; ?>"  name="user" id="username" disabled>
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_user"></div>
                                        <div class="col-sm-3" id="msg_user2">
                                        </div>
                                        <br>
                                    </div>

                                    <input class="btn btn-lg btn-success btn-block" name="submit" type="submit" value="ویرایش" id="edit_member<?php echo $r->id1; ?>">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        applyPagination();

        function applyPagination() {
            $("#ajax_pagingsearc a").click(function () {
                var url = $(this).attr("href");
                $.ajax({
                    type: "POST",
                    data: "ajax=1",
                    url: url,
                    success: function (msg) {
                        $(".ajax_show_estate").html(msg);
                        applyPagination();
                    }
                });
                return false;
            });
        }
    });
</script>
<script>
<?php foreach ($rows as $et): ?>
        $(document).ready(function () {
            $(document).on('change', '#status_estate<?php echo $et->id1; ?>', function () {
                var val = $("#status_estate<?php echo $et->id1; ?>").val();
                var id = <?php echo $et->id1; ?>;
                $.post("<?php echo base_url('site/status_satate'); ?>", {q: val, p: id}, function (data)
                {
                    if (data == 'تایید شده') {
                        $('#status_estate<?php echo $et->id1; ?>').css('background-color', '#00a157');
                    } else if (data == 'در حال بررسی') {
                        $('#status_estate<?php echo $et->id1; ?>').css('background-color', '#E67E22');
                    } else if (data == 'لغو شده') {
                        $('#status_estate<?php echo $et->id1; ?>').css('background-color', '#c9302c');
                    }
                });
            });

            $(document).ready(function () {
                $('#form2<?php echo $et->id1; ?>').submit(function (e) {
                    e.preventDefault();
                    var id = <?php echo $et->id1; ?>;
                    var name = $('#name<?php echo $et->id1; ?>').val();
                    var manager = $('#manager<?php echo $et->id1; ?>').val();
                    var phone = $('#phone<?php echo $et->id1; ?>').val();
                    var tell = $('#tell<?php echo $et->id1; ?>').val();
                    var address = $('#address<?php echo $et->id1; ?>').val();
                    if ($('#name<?php echo $et->id1; ?>').val()) {
                        if ($('#manager<?php echo $et->id1; ?>').val()) {
                            if ($('#phone<?php echo $et->id1; ?>').val()) {
                                if ($('#tell<?php echo $et->id1; ?>').val()) {
                                    if ($('#address<?php echo $et->id1; ?>').val()) {
                                        $.post("<?php echo base_url('site/edit_member'); ?>", {q1: name, q2: manager, q3: phone, q4: tell, q5: address, id: id}, function (data)
                                        {
                                            alert(data);
                                        });
                                    } else {
                                        alert('پرکردن تمامی فیلد ها اجباری است.');
                                    }
                                } else {
                                    alert('پرکردن تمامی فیلد ها اجباری است.');
                                }
                            } else {
                                alert('پرکردن تمامی فیلد ها اجباری است.');
                            }
                        } else {
                            alert('پرکردن تمامی فیلد ها اجباری است.');
                        }
                    } else {
                        alert('پرکردن تمامی فیلد ها اجباری است.');
                    }
                });
            });
        });
<?php endforeach; ?>
</script>