<?php require_once 'part/template/admin_header.php'; ?>
<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {
        refresh();
        function refresh() {
            setTimeout(function () {
                $('#pending_estate_count').load('<?php echo base_url('site/pending_estate_count'); ?> #pending_estate_count');
                $('#new_msg_count').load('<?php echo base_url('site/new_msg_count'); ?> #new_msg_count');
                $('#new_msg_count2').load('<?php echo base_url('site/new_msg_count2'); ?> #new_msg_count2');
                refresh();
            }, 1000);
        }
        ;
    });
</script>

<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <header class="main-header">
            <a href="<?php echo base_url('site/admin'); ?>" class="logo">
                <span class="logo-mini font_title1" style="font-size: 10px">مشاوران املاک</span>
                <span class="logo-lg font_title">مشاوران املاک</span>
            </a>
            <nav class="navbar navbar-static-top" role="navigation">
                <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">منو</span>
                </a>
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="messages-menu" style="margin-bottom:0px;">
                            <a href="<?php echo base_url('site/logout'); ?>" style="color: red;font-size: 19px;" title="خروج">
                                <span class="fa fa-power-off"></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <aside class="main-sidebar">
            <section class="sidebar">
                <ul class="sidebar-menu">
                    <li class="header">منو اصلی</li> 
                    <li class="treeview <?php if ($page == 1 || $page == 2) { ?>active<?php } ?>">
                        <a href="#">
                            <i class="fa fa-building-o"></i>
                            <span>مشاورین املاک</span>
                            <span id="pending_estate_count"> 
                                <span class="label label-danger pull-right" ><?php echo $count_rows; ?></span>
                            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li class="<?php if ($page == 1) { ?>active<?php } ?>"><a href="<?php echo base_url('site/real_estate_accept'); ?>"><i class="fa fa-check-square-o"></i> مشاورین املاک</a></li>
                            <li class="<?php if ($page == 2) { ?>active<?php } ?>"><a href="<?php echo base_url('site/real_estate_pending'); ?>"><i class="fa fa-check-square-o"></i> مشاورین املاک درحال بررسی</a>
                        </ul>
                    </li>
                    <li class="treeview <?php if ($page == 3 || $page == 4 || $page == 5) { ?>active<?php } ?>">
                        <a href="#">
                            <i class="fa fa-home"></i>
                            <span>املاک</span>
                            <span class="fa fa-angle-left pull-right"></span>
                        </a>
                        <ul class="treeview-menu">
                            <li class="<?php if ($page == 3) { ?>active<?php } ?>"><a href="<?php echo base_url('site/estate_sale'); ?>"><i class="fa fa-check-square-o"></i> فروش</a></li>
                            <li class="<?php if ($page == 4) { ?>active<?php } ?>"><a href="<?php echo base_url('site/estate_mortgage'); ?>"><i class="fa fa-check-square-o"></i> رهن</a>
                            <li class="<?php if ($page == 5) { ?>active<?php } ?>"><a href="<?php echo base_url('site/estate_rent'); ?>"><i class="fa fa-check-square-o"></i> اجاره</a> 
                        </ul>
                    </li>
                    <li class="treeview <?php if ($page == 6 || $page == 7 || $page == 8) { ?>active<?php } ?>">
                        <a href="#">
                            <i class="fa fa-picture-o"></i>
                            <span>گالری</span>
                            <span class="fa fa-angle-left pull-right"></span>
                        </a>
                        <ul class="treeview-menu">
                            <li class="<?php if ($page == 6) { ?>active<?php } ?>"><a href="<?php echo base_url('site/gallery_sale'); ?>"><i class="fa fa-check-square-o"></i> فروش</a></li>
                            <li class="<?php if ($page == 7) { ?>active<?php } ?>"><a href="<?php echo base_url('site/gallery_mortgage'); ?>"><i class="fa fa-check-square-o"></i> رهن</a>
                            <li class="<?php if ($page == 8) { ?>active<?php } ?>"><a href="<?php echo base_url('site/gallery_rent'); ?>"><i class="fa fa-check-square-o"></i> اجاره</a> 
                        </ul>
                    </li>
                    <li class="treeview <?php if ($page == 10) { ?>active<?php } ?>">
                        <a href="<?php echo base_url('site/message'); ?>">
                            <i class="fa fa-commenting"></i>
                            <span>پیام</span>
                            <span id="new_msg_count"> 
                                <span class="label label-danger pull-right" ><?php echo $new_msg_count; ?></span>
                            </span>
                        </a>
                    </li>
                    <li class="treeview <?php if ($page == 11) { ?>active<?php } ?>">
                        <a href="<?php echo base_url('site/contactUs'); ?>">
                            <i class="fa fa-commenting"></i>
                            <span>ارتباط با ما</span>
                            <span id="new_msg_count2"> 
                                <span class="label label-danger pull-right" ><?php echo $new_msg_count2; ?></span>
                            </span>
                        </a>
                    </li>
                    <li class="treeview <?php if ($page == 9) { ?>active<?php } ?>">
                        <a href="#">
                            <i class="fa fa-lock"></i>
                            <span>امنیت</span>
                            <span class="fa fa-angle-left pull-right"></span>
                        </a>
                        <ul class="treeview-menu">
                            <li class="<?php if ($page == 9) { ?>active<?php } ?>"><a href="<?php echo base_url('site/change_pass'); ?>"><i class="fa fa-check-square-o"></i>تغییر پسورد</a></li>
                        </ul>
                    </li>
                </ul>
            </section>
        </aside>
        <div class="content-wrapper">
            <section class="content-header">
                <h1>
                    پنل مدیریت
                </h1>
                <div class="body_admin">
                    <?php
                    if ($page == 1) {
                        require_once 'part/real_estate_accept.php';
                    } elseif ($page == 2) {
                        require_once 'part/real_estate_pending.php';
                    } elseif ($page == 3) {
                        require_once 'part/estate_sale.php';
                    } elseif ($page == 4) {
                        require_once 'part/estate_mortgage.php';
                    } elseif ($page == 5) {
                        require_once 'part/estate_rent.php';
                    } elseif ($page == 6) {
                        require_once 'part/gallery_sale.php';
                    } elseif ($page == 7) {
                        require_once 'part/gallery_mortgage.php';
                    } elseif ($page == 8) {
                        require_once 'part/gallery_rent.php';
                    } elseif ($page == 10) {
                        require_once 'part/message.php';
                    } elseif ($page == 9) {
                        require_once 'part/change_pass.php';
                    } elseif ($page == 11) {
                        require_once 'part/contact_us.php';
                    } else {
                        ?><span class="user_accept">
                            مدیر گرامی به پنل مدیریت خوش امدید<br>
                            برای مدیریت از منو سمت راست استفاده نمایید
                        </span><?php }
                    ?>
                </div>
            </section>
        </div>
    </div>
    <?php require_once 'part/template/admin_footer.php'; ?>