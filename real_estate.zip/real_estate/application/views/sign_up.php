<html>
    <head>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.rtl.min.css">
        <script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
        <title>ثبت نام</title>
    </head>
    <body class="login">
        <script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                $('#show_search').hide();
                $('#resend_add').hide();
                var y1, y2, y3, y4, y5, y6, y7, y8, y9;
                y1 = 0;
                y2 = 0;
                y3 = 0;
                y4 = 0;
                y5 = 0;
                y6 = 0;
                y7 = 0;
                y8 = 0;
                y9 = 0;
                var x1 = 0, x2 = 0, x3 = 0, x4 = 0;
                var z = 0;
                $("input[type=password]").keyup(function () {
                    var ucase = new RegExp("[A-Z]+");
                    var lcase = new RegExp("[a-z]+");
                    var num = new RegExp("[0-9]+");
                    if ($("#pass").val().length >= 8) {
                        $("#8char").removeClass("fa fa-times");
                        $("#8char").addClass("fa fa-check");
                        $("#8char").css("color", "#00A41E");
                        x1 = 1;
                    } else {
                        $("#8char").removeClass("fa fa-check");
                        $("#8char").addClass("fa fa-times");
                        $("#8char").css("color", "#FF0004");
                        x1 = 0;
                    }

                    if (ucase.test($("#pass").val())) {
                        $("#ucase").removeClass("fa fa-times");
                        $("#ucase").addClass("fa fa-check");
                        $("#ucase").css("color", "#00A41E");
                        x2 = 1;
                    } else {
                        $("#ucase").removeClass("fa fa-check");
                        $("#ucase").addClass("fa fa-times");
                        $("#ucase").css("color", "#FF0004");
                        x2 = 0;
                    }

                    if (lcase.test($("#pass").val())) {
                        $("#lcase").removeClass("fa fa-times");
                        $("#lcase").addClass("fa fa-check");
                        $("#lcase").css("color", "#00A41E");
                        x3 = 1;
                    } else {
                        $("#lcase").removeClass("fa fa-check");
                        $("#lcase").addClass("fa fa-times");
                        $("#lcase").css("color", "#FF0004");
                        x3 = 0;
                    }

                    if (num.test($("#pass").val())) {
                        $("#num").removeClass("fa fa-times");
                        $("#num").addClass("fa fa-check");
                        $("#num").css("color", "#00A41E");
                        x4 = 1;
                    } else {
                        $("#num").removeClass("fa fa-check");
                        $("#num").addClass("fa fa-times");
                        $("#num").css("color", "#FF0004");
                        x4 = 0;
                    }
                });
                $(document).on('blur', '#name', function () {
                    if ($('#name').val() == null || $('#name').val() == "") {
                        $("#msg_name").html('لطفا نام املاک را وارد کنید');
                        $('#name').css('border-color', 'red');
                        $("#msg_name").css('color', 'red');
                        y1 = 0;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    } else {
                        $('#name').css('border-color', 'green');
                        $("#msg_name").html('قابل قبول');
                        $("#msg_name").css('color', 'green');
                        y1 = 1;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    }
                });
                $(document).on('blur', '#img', function () {
                    if ($('#img').val() == null || $('#img').val() == "") {
                        $("#msg_img").html('گواهی را ارسال کنید');
                        $('#img').css('border-color', 'red');
                        $("#msg_img").css('color', 'red');
                        y2 = 0;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    } else {
                        $('#img').css('border-color', 'green');
                        $("#msg_img").html('قابل قبول');
                        $("#msg_img").css('color', 'green');
                        y2 = 1;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    }
                });
                $(document).on('blur', '#manager', function () {
                    if ($('#manager').val() == null || $('#manager').val() == "") {
                        $("#msg_manager").html('نام مدیر را وارد کنید');
                        $('#manager').css('border-color', 'red');
                        $("#msg_manager").css('color', 'red');
                        y3 = 0;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    } else {
                        $('#manager').css('border-color', 'green');
                        $("#msg_manager").html('قابل قبول');
                        $("#msg_manager").css('color', 'green');
                        y3 = 1;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    }
                });
                $(document).on('blur', '#register', function () {
                    if ($('#register').val() == null || $('#register').val() == "") {
                        $("#msg_reg").html('شماره ثبت را وارد کنید');
                        $('#register').css('border-color', 'red');
                        $("#msg_reg").css('color', 'red');
                        y4 = 0;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    } else {
                        $('#register').css('border-color', 'green');
                        $("#msg_reg").html('قابل قبول');
                        $("#msg_reg").css('color', 'green');
                        y4 = 1;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    }
                });
                $(document).on('blur', '#phone', function () {
                    if ($('#phone').val() == null || $('#phone').val() == "") {
                        $("#msg_phone").html('تلفن همراه را ارسال کنید');
                        $('#phone').css('border-color', 'red');
                        $("#msg_phone").css('color', 'red');
                        y5 = 0;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    } else {
                        if ($("#phone").val().length == 11) {
                            $('#phone').css('border-color', 'green');
                            $("#msg_phone").html('قابل قبول');
                            $("#msg_phone").css('color', 'green');
                            y5 = 1;
                            if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                                $('#add_member').removeClass('disabled');
                            } else {
                                $('#add_member').addClass('disabled');
                            }
                        } else {
                            $("#msg_phone").html('تعداد ارقام باید 11 باشد .');
                            $('#phone').css('border-color', 'red');
                            $("#msg_phone").css('color', 'red');
                            y5 = 0;
                            if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                                $('#add_member').removeClass('disabled');
                            } else {
                                $('#add_member').addClass('disabled');
                            }
                        }
                    }
                });
                $(document).on('blur', '#tell', function () {
                    if ($('#tell').val() == null || $('#tell').val() == "") {
                        $("#msg_tell").html('تلفن ثابت را وارد کنید');
                        $('#tell').css('border-color', 'red');
                        $("#msg_tell").css('color', 'red');
                        y6 = 0;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    } else {
                        if ($("#tell").val().length == 11) {
                            $('#tell').css('border-color', 'green');
                            $("#msg_tell").html('قابل قبول');
                            $("#msg_tell").css('color', 'green');
                            y6 = 1;
                            if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                                $('#add_member').removeClass('disabled');
                            } else {
                                $('#add_member').addClass('disabled');
                            }
                        } else {
                            $("#msg_tell").html('تعداد ارقام باید 11 باشد .');
                            $('#tell').css('border-color', 'red');
                            $("#msg_tell").css('color', 'red');
                            y6 = 0;
                            if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                                $('#add_member').removeClass('disabled');
                            } else {
                                $('#add_member').addClass('disabled');
                            }
                        }
                    }
                });
                $(document).on('blur', '#address', function () {
                    if ($('#address').val() == null || $('#address').val() == "") {
                        $("#msg_address").html('آدرس را وارد کنید');
                        $('#address').css('border-color', 'red');
                        $("#msg_address").css('color', 'red');
                        y7 = 0;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    } else {
                        $('#address').css('border-color', 'green');
                        $("#msg_address").html('قابل قبول');
                        $("#msg_address").css('color', 'green');
                        y7 = 1;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    }
                });
                $(document).on('blur', '#username', function () {
                    var usercheck = $("#username").val();
                    if ($('#username').val() == null || $('#username').val() == "") {
                        $("#msg_user").html('نام کاربری را وارد کنید');
                        $('#username').css('border-color', 'red');
                        $("#msg_user").css('color', 'red');
                        y8 = 0;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    } else {
                        $.post("<?php echo base_url('site/check_user'); ?>", {user_name: usercheck}, function (data)
                        {
                            if (data != '' || data != undefined || data != null)
                            {
                                $('#msg_user').html(data);
                                $("#msg_user").css('color', 'red');
                                if (data == '<span id="user_id_span" class="add_estate1">قابل قبول</span>') {
                                    $('#username').css('border-color', 'green');
                                    $("#msg_user").css('color', 'green');
                                    y8 = 1;
                                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                                        $('#add_member').removeClass('disabled');
                                    } else {
                                        $('#add_member').addClass('disabled');
                                    }
                                } else {
                                    $('#username').css('border-color', 'red');
                                    y8 = 0;
                                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                                        $('#add_member').removeClass('disabled');
                                    } else {
                                        $('#add_member').addClass('disabled');
                                    }
                                }
                            }
                        });
                    }
                });
                $(document).on('blur', '#pass', function () {
                    if ($('#pass').val() == null || $('#pass').val() == "") {
                        $("#msg_pass").html('رمز عبور را وارد کنید');
                        $('#pass').css('border-color', 'red');
                        $("#msg_pass").css('color', 'red');
                        y9 = 0;
                        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                            $('#add_member').removeClass('disabled');
                        } else {
                            $('#add_member').addClass('disabled');
                        }
                    } else {
                        if (x1 == 1 & x2 == 1 & x3 == 1 & x4 == 1) {
                            $('#pass').css('border-color', 'green');
                            $("#msg_pass").html('قابل قبول');
                            $("#msg_pass").css('color', 'green');
                            y9 = 1;
                            if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                                $('#add_member').removeClass('disabled');
                            } else {
                                $('#add_member').addClass('disabled');
                            }
                        } else {
                            $("#msg_pass").html('غیر قابل قبول');
                            $('#pass').css('border-color', 'red');
                            $("#msg_pass").css('color', 'red');
                            y9 = 0;
                            if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                                $('#add_member').removeClass('disabled');
                            } else {
                                $('#add_member').addClass('disabled');
                            }
                        }
                    }
                });
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                    $('#add_member').removeClass('disabled');
                } else {
                    $('#add_member').addClass('disabled');
                }

                $(document).on('click', '#close_form', function () {
                    $('#add_member').show();
                    $('#form').show('');
                    $('#resend_add').hide();
                });

                $('#form1').submit(function (e) {

                    e.preventDefault();
                    var formData = new FormData($("#form1")[0]);
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1) {
                        $.ajax({
                            url: '<?php echo base_url('site/form_user'); ?>',
                            type: "POST",
                            data: formData,
                            fileElementId: 'image',
                            async: false,
                            success: function (data)
                            {
                                $('#add_member').hide();
                                $('#form').hide();
                                $('#resend_add').show();
                                $('#resend_add').html(data);
                            },
                            cache: false,
                            contentType: false,
                            processData: false
                        });
                        return false;
                    } else {
                        alert('پرکردن تمامی فیلد ها اجباری است.');
                    }
                });
            });</script>

        <div class="container">
            <div class="row vertical-offset-80">
                <div class="col-md-6 col-md-offset-3" style="margin-top: 40px;">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title login_title" style="color: red;font-size: 20px">ثبت نام</h3>
                        </div>
                        <div class="panel-body">
                            <form action="" method="post" name="form1" id="form1">
                                <div class="modal-body  modal-body1" id="form">
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="name">نام املاک:</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="name" id="name">
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_name"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="manager">مدیر :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="manager" id="manager">
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_manager"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="register">شماره ثبت :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="register" id="register" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_reg"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="phone">شماره همراه :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="phone" maxlength="11" id="phone" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_phone"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="tell">شماره ثابت :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="tell" maxlength="11" id="tell" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_tell"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="address">ادرس  :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="address" id="address">
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_address"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="img">مدرک املاک :</label>
                                        <div class="col-sm-7">          
                                            <input type="file" class="form-control" name="img" id="img">
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_img"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="user">نام کاربری :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="user" id="username">
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_user"></div>
                                        <div class="col-sm-3" id="msg_user2">
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="pass">رمز عبور :</label>
                                        <div class="col-sm-7">          
                                            <input type="password" class="form-control" name="pass" id="pass">
                                        </div>
                                        <div class="col-sm-3 add_estate" id="msg_pass"></div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="pass"></label>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <span id="8char" class="fa fa-times" style="color:#FF0004;"></span> بیشتر از 8 حرف<br>
                                                <span id="ucase" class="fa fa-times" style="color:#FF0004;"></span> یک حرف بزرگ
                                            </div>
                                            <div class="col-sm-4">
                                                <span id="lcase" class="fa fa-times" style="color:#FF0004;"></span> یک حرف کوچک<br>
                                                <span id="num" class="fa fa-times" style="color:#FF0004;"></span> یک کاراکتر عدد
                                            </div>
                                        </div>
                                    </div>
                                    <input class="btn btn-lg btn-success btn-block" name="submit" type="submit" value="افزودن" id="add_member">

                                </div>
                            </form>
                            <div class="modal-body modal-body1" id="resend_add"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/TweenMax.min.js"></script>
        <script>
                                                $(document).ready(function () {
                                                    $(document).mousemove(function (e) {
                                                        TweenLite.to($('body'),
                                                                .5,
                                                                {css:
                                                                            {
                                                                                backgroundPosition: "" + parseInt(event.pageX / 8) + "px " + parseInt(event.pageY / '12') + "px, " + parseInt(event.pageX / '15') + "px " + parseInt(event.pageY / '15') + "px, " + parseInt(event.pageX / '30') + "px " + parseInt(event.pageY / '30') + "px"
                                                                            }
                                                                });
                                                    });
                                                });

        </script>

    </body> 
</html>
