<?php foreach ($rows as $r) { ?>
    <div class="panel-body">
        <form action="" method="post" name="form1" id="form1">
            <div class="modal-body  modal-body1" id="form">
                <div class="form-group form-group1">
                    <label class="control-label col-sm-2 size_font" for="name">نام املاک:</label>
                    <div class="col-sm-7">          
                        <input type="text" class="form-control" value="<?php echo $r->name; ?>" name="name" id="name">
                    </div>
                    <div class="col-sm-3 add_estate" id="msg_name"></div>
                </div>
                <div class="form-group form-group1">
                    <label class="control-label col-sm-2 size_font" for="manager">مدیر :</label>
                    <div class="col-sm-7">          
                        <input type="text" class="form-control" value="<?php echo $r->manager; ?>"  name="manager" id="manager">
                    </div>
                    <div class="col-sm-3 add_estate" id="msg_manager"></div>
                </div>
                <div class="form-group form-group1">
                    <label class="control-label col-sm-2 size_font" for="register">شماره ثبت :</label>
                    <div class="col-sm-7">          
                        <input type="text" class="form-control" name="register" value="<?php echo $r->register_num; ?>"  id="register" disabled>
                    </div>
                    <div class="col-sm-3 add_estate" id="msg_reg"></div>
                </div>
                <div class="form-group form-group1">
                    <label class="control-label col-sm-2 size_font" for="phone">شماره همراه :</label>
                    <div class="col-sm-7">          
                        <input type="text" class="form-control" value="<?php echo $r->phone; ?>"  name="phone" maxlength="11" id="phone" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                    </div>
                    <div class="col-sm-3 add_estate" id="msg_phone"></div>
                </div>
                <div class="form-group form-group1">
                    <label class="control-label col-sm-2 size_font" for="tell">شماره ثابت :</label>
                    <div class="col-sm-7">          
                        <input type="text" class="form-control" name="tell" value="<?php echo $r->tell; ?>"  maxlength="11" id="tell" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
                    </div>
                    <div class="col-sm-3 add_estate" id="msg_tell"></div>
                </div>
                <div class="form-group form-group1">
                    <label class="control-label col-sm-2 size_font" for="address">ادرس  :</label>
                    <div class="col-sm-7">          
                        <input type="text" class="form-control" name="address" value="<?php echo $r->address; ?>"  id="address">
                    </div>
                    <div class="col-sm-3 add_estate" id="msg_address"></div>
                </div>
                <div class="form-group form-group1">
                    <label class="control-label col-sm-2 size_font" for="user">نام کاربری :</label>
                    <div class="col-sm-7">          
                        <input type="text" class="form-control" value="<?php echo $r->username; ?>"  name="user" id="username" disabled>
                    </div>
                    <div class="col-sm-3 add_estate" id="msg_user"></div>
                    <div class="col-sm-3" id="msg_user2">
                    </div>
                    <br>
                </div>

                <input class="btn btn-lg btn-success btn-block" name="submit" type="submit" value="ویرایش" id="add_member">
            </div>
        </form>
    </div>
<?php } ?>
<script>
    $(document).ready(function () {
        $('#form1').submit(function (e) {
            e.preventDefault();
            var formData = new FormData($("#form1")[0]);
            if ($('#name').val()) {
                if ($('#manager').val()) {
                    if ($('#phone').val()) {
                        if ($('#tell').val()) {
                            if ($('#address').val()) {
                                $.ajax({
                                    url: '<?php echo base_url('panel/edit_member'); ?>',
                                    type: "POST",
                                    data: formData,
                                    async: false,
                                    success: function (data)
                                    {
                                        alert(data);
                                    },
                                    cache: false,
                                    contentType: false,
                                    processData: false
                                });
                                return false;
                            } else {
                                alert('پرکردن تمامی فیلد ها اجباری است.');
                            }
                        } else {
                            alert('پرکردن تمامی فیلد ها اجباری است.');
                        }
                    } else {
                        alert('پرکردن تمامی فیلد ها اجباری است.');
                    }
                } else {
                    alert('پرکردن تمامی فیلد ها اجباری است.');
                }
            } else {
                alert('پرکردن تمامی فیلد ها اجباری است.');
            }
        });
    });</script>