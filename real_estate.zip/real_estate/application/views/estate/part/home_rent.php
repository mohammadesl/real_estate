<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?libraries=places,drawing&sensor=false"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="http://www.yohman.com/scripts/arcgislink.js"></script>
<link rel="stylesheet" type="text/css" href="http://www.yohman.com/students/yoh/bootstrap/css/bootstrap.min.css" />
<script src="http://www.yohman.com/students/yoh/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript">
    var up206b = {};
    var map;
    var geocoder = new google.maps.Geocoder();
    var drawingManager;
    function trace(message)
    {
        if (typeof console != 'undefined')
        {
            console.log(message);
        }
    }
    up206b.initialize = function ()
    {
        var latlng = new google.maps.LatLng(36.53860527391006, 52.67738342285156);
        var myOptions = {
            zoom: 12,
            center: latlng,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            mapTypeControl: false //disable the map type control
        };
        map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
        drawingManager = new google.maps.drawing.DrawingManager({
            drawingMode: google.maps.drawing.OverlayType.MARKER,
            drawingControl: true,
            drawingControlOptions: {
                position: google.maps.ControlPosition.TOP_CENTER,
                drawingModes: [google.maps.drawing.OverlayType.MARKER]
            },
            markerOptions: {
                draggable: true
            }
        });
        drawingManager.setMap(map);
        google.maps.event.addListener(drawingManager, 'overlaycomplete', function (point)
        {
            $('#s2').show();
            $('#s1').hide();
            var form = $(".add_home").clone().show();
            var infowindow_content = form[0];
            var infowindow = new google.maps.InfoWindow({
                content: infowindow_content
            });
            google.maps.event.addListener(point.overlay, 'click', function () {
                infowindow.open(map, point.overlay);
            });
            infowindow.open(map, point.overlay);
            form.submit({point: point}, function (event) {
                event.preventDefault();
                document.getElementById("lat").value = event.data.point.overlay.getPosition().lat();
                document.getElementById("lon").value = event.data.point.overlay.getPosition().lng();
                var formData = new FormData($("#form1")[0]);
                $.ajax({
                    url: '<?php echo base_url('panel/add_home_rent'); ?>',
                    type: "POST",
                    data: formData,
                    fileElementId: 'image',
                    async: false,
                    success: function ()
                    {
                        $('#s2').hide();
                        $('#s1').show();
                        $('#s1').html('ملک شما با موفقیت ثبت شده است');
                        document.getElementById("myForm").reset();
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                });
            });
        });
    };
    up206b.saveStopResponse = function (data) {
        if (typeof data.error != "undefined")
        {
            alert(data.error);
        }
        else
        {
            alert(data.message);
        }
    }

    up206b.geocode = function ()
    {

        var address = $('#address').val();
        geocoder.geocode({'address': address}, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK)
            {
                map.setCenter(results[0].geometry.location);
                var marker = new google.maps.Marker({
                    map: map
                });
            }
            else
            {
                alert("Geocode was not successful for the following reason: " + status);
            }
        });
    }
    $('#address').keypress(function (e) {
        if (e.which == 13) {
            up206b.geocode();
        }
    });
</script>
<div  class="search_add_home">
    <div style="padding:10px;">
        <div class="col-md-11">
            <input id="address" name="email" type="text" placeholder="نام شهر :" class="form-control">
        </div>
        <input class="btn btn-large btn-success" type="button" value="بگرد" onClick="up206b.geocode()">
    </div>
</div>
<div id="map_canvas"></div>
<div class="add_home" style="display: none;overflow: auto;overflow-x: hidden;">
    <h4 class="modal-title font_title" id="myModalLabel">افزودن</h4>
    <form id="form1">
        <div id="s1"></div>
        <div id="s2">
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="price">قيمت:</label>
                <div class="col-sm-7">          
                    <input type="text" class="form-control" name="price" id="price">
                </div>
                <div class="col-sm-3 add_estate" id="msg_price"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="area">متراژ :</label>
                <div class="col-sm-7">          
                    <input type="text" class="form-control" name="area" id="area">
                </div>
                <div class="col-sm-3 add_estate" id="msg_area"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="elevator">آسانسور:</label>
                <div class="col-sm-7">          
                    <select class="form-control" name="elevator"  id="elevator">
                        <option>انتخاب...</option>
                        <option value="1">بله</option>
                        <option value="2">خير</option>
                    </select>
                </div>
                <div class="col-sm-3 add_estate" id="msg_elevator"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="bedroom">اتاق خواب :</label>
                <div class="col-sm-7">          
                    <input type="text" class="form-control" name="bedroom" id="bedroom">
                </div>
                <div class="col-sm-3 add_estate" id="msg_bedroom"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="tell">شماره ثابت :</label>
                <div class="col-sm-7">          
                    <input type="text" class="form-control" name="tell" maxlength="11" id="tell">
                </div>
                <div class="col-sm-3 add_estate" id="msg_tell"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="phone">تلفن همراه :</label>
                <div class="col-sm-7">          
                    <input type="text" class="form-control" name="phone" maxlength="11" id="phone">
                </div>
                <div class="col-sm-3 add_estate" id="msg_phone"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="description">توضيحات :</label>
                <div class="col-sm-7">          
                    <input type="text" class="form-control" name="description" id="description">
                </div>
                <div class="col-sm-3 add_estate" id="msg_description"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="address1">آدرس :</label>
                <div class="col-sm-7">          
                    <input type="text" class="form-control" name="address1" id="address1">
                </div>
                <div class="col-sm-3 add_estate" id="msg_address1"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="storehouse">انبار :</label>
                <div class="col-sm-7"> 
                    <select class="form-control" name="storehouse" id="storehouse">
                        <option>انتخاب...</option>
                        <option value="1">بله</option>
                        <option value="2">خير</option>
                    </select>
                </div>
                <div class="col-sm-3 add_estate" id="msg_storehouse"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="parking">پارکينگ :</label>
                <div class="col-sm-7"> 
                    <select class="form-control" name="parking" id="parking">
                        <option>انتخاب...</option>
                        <option value="2">بله</option>
                        <option value="1">خير</option>
                    </select>
                </div>
                <div class="col-sm-3 add_estate" id="msg_parking"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="build">سال ساخت :</label>
                <div class="col-sm-7">          
                    <input type="text" class="form-control" name="build" id="build">
                </div> 
                <div class="col-sm-3 add_estate" id="msg_build"></div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="img1">عکس 1 :</label>
                <div class="col-sm-7">
                    <input type="file" class="img"  name="img11[]" id="img1">
                </div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="img2">عکس 2 :</label>
                <div class="col-sm-7">
                    <input type="file" class="img" name="img11[]" id="img2">
                </div>
            </div>
            <br>
            <div class="form-group form-group1">
                <label class="control-label col-sm-2 size_font" for="img3">عکس 3 :</label>
                <div class="col-sm-7">
                    <input type="file" class="img" name="img11[]" id="img3">
                </div>
            </div>
            <br>
            <input type="text" style="display: none" name="lat" id="lat">
            <input type="text" style="display: none" name="lon" id="lon">
            <input name="submit" type="submit" id="add_home1" class="btn btn-primary font_title" value="افزودن">
        </div>
    </form>
</div>
<script>
    $(document).ready(function () {
        var y1, y2, y3, y4, y5, y6, y7, y8, y9, y10, y14;
        y1 = 0;
        y2 = 0;
        y3 = 0;
        y4 = 0;
        y5 = 0;
        y6 = 0;
        y7 = 0;
        y8 = 0;
        y9 = 0;
        y10 = 0;
        y14 = 0;
        $(document).on('blur', '#price', function () {
            if ($('#price').val() == null || $('#price').val() == "") {
                $("#msg_price").html('لطفا قیمت املاک را وارد کنید');
                $('#price').css('border-color', 'red');
                $("#msg_price").css('color', 'red');
                y1 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                $('#price').css('border-color', 'green');
                $("#msg_price").html('قابل قبول');
                $("#msg_price").css('color', 'green');
                y1 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#elevator', function () {
            if ($('#elevator').val() == null || $('#elevator').val() == "" || $('#elevator').val() == "انتخاب...") {
                $("#msg_elevator").html('اسانسور را انتخاب کنید');
                $('#elevator').css('border-color', 'red');
                $("#msg_elevator").css('color', 'red');
                y3 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                $('#elevator').css('border-color', 'green');
                $("#msg_elevator").html('قابل قبول');
                $("#msg_elevator").css('color', 'green');
                y3 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#area', function () {
            if ($('#area').val() == null || $('#area').val() == "") {
                $("#msg_area").html('متراژ را وارد کنید');
                $('#area').css('border-color', 'red');
                $("#msg_area").css('color', 'red');
                y2 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                $('#area').css('border-color', 'green');
                $("#msg_area").html('قابل قبول');
                $("#msg_area").css('color', 'green');
                y2 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#bedroom', function () {
            if ($('#bedroom').val() == null || $('#bedroom').val() == "") {
                $("#msg_bedroom").html('تعداد اتاق خواب را وارد کنید');
                $('#bedroom').css('border-color', 'red');
                $("#msg_bedroom").css('color', 'red');
                y4 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                $('#bedroom').css('border-color', 'green');
                $("#msg_bedroom").html('قابل قبول');
                $("#msg_bedroom").css('color', 'green');
                y4 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#phone', function () {
            if ($('#phone').val() == null || $('#phone').val() == "") {
                $("#msg_phone").html('تلفن همراه را ارسال کنید');
                $('#phone').css('border-color', 'red');
                $("#msg_phone").css('color', 'red');
                y5 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                if ($("#phone").val().length == 11) {
                    $('#phone').css('border-color', 'green');
                    $("#msg_phone").html('قابل قبول');
                    $("#msg_phone").css('color', 'green');
                    y5 = 1;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                        $('#add_home1').removeClass('disabled');
                    } else {
                        $('#add_home1').addClass('disabled');
                    }
                } else {
                    $("#msg_phone").html('تعداد ارقام باید 11 باشد .');
                    $('#phone').css('border-color', 'red');
                    $("#msg_phone").css('color', 'red');
                    y5 = 0;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                        $('#add_home1').removeClass('disabled');
                    } else {
                        $('#add_home1').addClass('disabled');
                    }
                }
            }
        });
        $(document).on('blur', '#tell', function () {
            if ($('#tell').val() == null || $('#tell').val() == "") {
                $("#msg_tell").html('تلفن ثابت را وارد کنید');
                $('#tell').css('border-color', 'red');
                $("#msg_tell").css('color', 'red');
                y6 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                if ($("#tell").val().length == 11) {
                    $('#tell').css('border-color', 'green');
                    $("#msg_tell").html('قابل قبول');
                    $("#msg_tell").css('color', 'green');
                    y6 = 1;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                        $('#add_home1').removeClass('disabled');
                    } else {
                        $('#add_home1').addClass('disabled');
                    }
                } else {
                    $("#msg_tell").html('تعداد ارقام باید 11 باشد');
                    $('#tell').css('border-color', 'red');
                    $("#msg_tell").css('color', 'red');
                    y6 = 0;
                    if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                        $('#add_home1').removeClass('disabled');
                    } else {
                        $('#add_home1').addClass('disabled');
                    }
                }
            }
        });
        $(document).on('blur', '#address1', function () {
            if ($('#address1').val() == null || $('#address1').val() == "") {
                $("#msg_address1").html('آدرس را وارد کنید');
                $('#address1').css('border-color', 'red');
                $("#msg_address1").css('color', 'red');
                y7 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                $('#address1').css('border-color', 'green');
                $("#msg_address1").html('قابل قبول');
                $("#msg_address1").css('color', 'green');
                y7 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#storehouse', function () {
            if ($('#storehouse').val() == null || $('#storehouse').val() == "" || $('#storehouse').val() == "انتخاب...") {
                $("#msg_storehouse").html('انبار را انتخاب کنید');
                $('#storehouse').css('border-color', 'red');
                $("#msg_storehouse").css('color', 'red');
                y8 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                $('#storehouse').css('border-color', 'green');
                $("#msg_storehouse").html('قابل قبول');
                $("#msg_storehouse").css('color', 'green');
                y8 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#parking', function () {
            if ($('#parking').val() == null || $('#parking').val() == "" || $('#parking').val() == "انتخاب...") {
                $("#msg_parking").html('پارکینگ را انتخاب کنید');
                $('#parking').css('border-color', 'red');
                $("#msg_parking").css('color', 'red');
                y9 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                $('#parking').css('border-color', 'green');
                $("#msg_parking").html('قابل قبول');
                $("#msg_parking").css('color', 'green');
                y9 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#build', function () {
            if ($('#build').val() == null || $('#build').val() == "") {
                $("#msg_build").html('سال ساخت را وارد کنید');
                $('#build').css('border-color', 'red');
                $("#msg_build").css('color', 'red');
                y10 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                $('#build').css('border-color', 'green');
                $("#msg_build").html('قابل قبول');
                $("#msg_build").css('color', 'green');
                y10 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            }
        });
        $(document).on('blur', '#description', function () {
            if ($('#description').val() == null || $('#description').val() == "") {
                $("#msg_description").html('توضیحات را وارد کنید');
                $('#description').css('border-color', 'red');
                $("#msg_description").css('color', 'red');
                y14 = 0;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            } else {
                $('#description').css('border-color', 'green');
                $("#msg_description").html('قابل قبول');
                $("#msg_description").css('color', 'green');
                y14 = 1;
                if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
                    $('#add_home1').removeClass('disabled');
                } else {
                    $('#add_home1').addClass('disabled');
                }
            }
        });

        if (y1 == 1 & y2 == 1 & y3 == 1 & y4 == 1 & y5 == 1 & y6 == 1 & y7 == 1 & y8 == 1 & y9 == 1 & y10 == 1 & y14 == 1) {
            $('#add_home1').removeClass('disabled');
        } else {
            $('#add_home1').addClass('disabled');
        }


    });
</script>