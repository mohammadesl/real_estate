<table class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>کد</th>
                        <th>نام املاک</th>
                        <th>تاریخ ثبت</th>
                        <th>وضعیت</th>
                        <th>شماره تماس</th>
                        <th>شماره همراه</th>
                        <th>آدرس</th>
                        <th>قیمت</th>
                        <th>اتاق خواب</th>
                        <th>اسانسور</th>
                        <th>متراژ</th>
                        <th>پارکينگ</th>
                        <th>انبار</th>
                        <th>سال ساخت</th>
                        <th>توضیحات</th>
                        <th>عکس</th>
                        <th>تنظیمات</th>
                    </tr>
                    <?php
                    $x = 0;
                    if ($rows != null) {
                        foreach ($rows as $a) {
                            ?>
                            <tr class="table_real_estate">
                                <td><?php echo $a->id_real_estate; ?></td>
                                <td><?php echo $a->name; ?></td>
                                <td><?php echo $a->register_date; ?></td>
                                <td>
                                    <div class="btn-group"> 
                                        <select id="status_estate<?php echo $a->id1; ?>" class="status_estate" style="color:white;
                                                <?php if ($a->type_sale == 'در حال فروش') { ?>background-color: #00a157;<?php
                                                } elseif ($a->type_sale == 'فروخته شده') {
                                                    ?>background-color: #c9302c;<?php }
                                                ?>">
                                            <option style="display: none;"><?php echo $a->type_sale; ?></option>
                                        </select>
                                    </div>
                                </td>
                                <td><?php echo $a->tell_home; ?></td>
                                <td><?php echo $a->phone_home; ?></td>
                                <td><?php echo $a->address_home; ?></td>
                                <td><?php echo $a->price; ?></td>
                                <td><?php echo $a->bedroom; ?></td>
                                <td><?php echo $a->type1; ?></td>
                                <td><?php echo $a->area; ?></td>
                                <td><?php echo $a->type_parking; ?></td>
                                <td><?php echo $a->type_storehouse; ?></td>
                                <td><?php echo $a->build; ?></td>
                                <td><?php echo $a->description; ?></td>
                               <td style="cursor: pointer"><span data-toggle="modal" data-target="#myModalimg<?php echo $a->id_home;?>">گالری عکس</span>
                                </td>
                                <td>
                                    <i class="fa fa-pencil-square-o edit" data-toggle="modal" data-target="#myModaledit<?php echo $a->id_home; ?>"></i>
                                    <i class="fa fa-times remove" data-toggle="modal" data-target="#myModalremove<?php echo $a->id_home; ?>"></i>
                                </td>
                            </tr>

                            <?php
                            $x++;
                        }
                    } else if ($rows == null) {
                        echo '<div style="color:red">موجود نیست</div>';
                    }
                    ?>
                </table>
                <div class="page">
                    <div class="page_in" id="ajax_pagingsearc">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>