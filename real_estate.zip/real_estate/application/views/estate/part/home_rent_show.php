<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function () {
        $('#show_search').hide();
        $(document).on('keyup', '#search_home', function () {
            var usercheck = $('#search_home').val();
            var value_category = $('.search_category').val();
            if (usercheck != '') {
                if (value_category != 'بر اساس') {
                    $.post("<?php echo base_url('panel/search_home_rent'); ?>", {q: usercheck, p: value_category}, function (data)
                    {
                        if (data != '' || data != undefined || data != null)
                        {
                            if (data != 'موردی یافت نشد') {
                                $.post("<?php echo base_url('panel/search_home_sale_rent'); ?>", {q: data, p: value_category}, function (data1)
                                {
                                    if (data != '' || data != undefined || data != null)
                                    {
                                        $('#ajax_show_estate').hide();
                                        $('#show_search').show();
                                        $('#show_search').html(data1);
                                    }
                                });
                            } else {
                                $('#ajax_show_estate').hide();
                                $('#show_search').show();
                                $('#show_search').html(data);
                            }
                        }
                    });
                } else {
                    $('#ajax_show_estate').hide();
                    $('#show_search').show();
                    $('#show_search').html('نوع بر اساس را انتخاب کنید');
                }
            } else {
                $('#ajax_show_estate').show();
                $('#show_search').hide();
            }
        });
        $(document).on('change', '.search_category', function () {
            var usercheck = $('#search_home').val();
            var value_category = $('.search_category').val();
            if (usercheck != '') {
                if (value_category != 'بر اساس') {
                    $.post("<?php echo base_url('panel/search_home_rent'); ?>", {q: usercheck, p: value_category}, function (data)
                    {
                        if (data != '' || data != undefined || data != null)
                        {
                            if (data != 'موردی یافت نشد') {
                                $.post("<?php echo base_url('panel/search_home_rent_show'); ?>", {q: data, p: value_category}, function (data1)
                                {
                                    if (data != '' || data != undefined || data != null)
                                    {
                                        $('#ajax_show_estate').hide();
                                        $('#show_search').show();
                                        $('#show_search').html(data1);
                                    }
                                });
                            } else {
                                $('#ajax_show_estate').hide();
                                $('#show_search').show();
                                $('#show_search').html(data);
                            }
                        }
                    });
                }
            } else {
                $('#ajax_show_estate').show();
                $('#show_search').hide();
            }
        });

    });
</script>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box">
            <div>
                <div class="col-lg-6 search_real_estate">
                    <div class="input-group">
                        <input type="text" id="search_home" class="form-control" placeholder="جستجو" aria-label="...">
                        <div class="input-group-btn">
                            <select class="search_category">
                                <option style="display: none;">بر اساس</option>
                                <option>قيمت</option>
                                <option>آدرس</option>
                                <option>اتاق خواب</option>
                                <option>متراژ</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <a href="<?php echo base_url('panel/printpage_rent'); ?>">
                <div class="btn btn-info add">
                    پرينت <i class="fa fa-print"></i>
                </div></a>
            <div class="box-body table-responsive no-padding ajax_show_estate" id="show_search">

            </div>
            <div class="box-body table-responsive no-padding ajax_show_estate"  id="ajax_show_estate">
                <table class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>تاريخ ثبت</th>
                        <th>وضعيت</th>
                        <th>شماره تماس</th>
                        <th>شماره همراه</th>
                        <th>آدرس</th>
                        <th>قيمت</th>
                        <th>اتاق خواب</th>
                        <th>اسانسور</th>
                        <th>متراژ</th>
                        <th>پارکينگ</th>
                        <th>انبار</th>
                        <th>سال ساخت</th>
                        <th>توضيحات</th>
                        <th>عکس</th>
                        <th>تنظيمات</th>
                    </tr>
                    <?php
                    $x = 0;
                    if ($rows2 != null) {
                        foreach ($rows2 as $a) {
                            ?>
                            <tr class="table_real_estate">
                                <td><?php echo $a->register_date; ?></td>
                                <td>
                                    <div class="btn-group"> 
                                        <select id="status_home<?php echo $a->id_home; ?>" class="status_estate" style="color:white;
                                                <?php if ($a->type_rent == 'در حال اجاره') { ?>background-color: #00a157;<?php
                                                } elseif ($a->type_rent == 'اجاره داده شده') {
                                                    ?>background-color: #c9302c;<?php }
                                                ?>">
                                            <option style="display: none;"><?php echo $a->type_rent; ?></option>
                                            <option class="select_real_estate" value="1">در حال اجاره</option>
                                            <option class="select_real_estate"value="2">اجاره داده شده</option>
                                        </select>
                                    </div>
                                </td>
                                <td><?php echo $a->tell_home; ?></td>
                                <td><?php echo $a->phone_home; ?></td>
                                <td><?php echo $a->address_home; ?></td>
                                <td><?php echo $a->price; ?></td>
                                <td><?php echo $a->bedroom; ?></td>
                                <td><?php echo $a->type1; ?></td>
                                <td><?php echo $a->area; ?></td>
                                <td><?php echo $a->type_parking; ?></td>
                                <td><?php echo $a->type_storehouse; ?></td>
                                <td><?php echo $a->build; ?></td>
                                <td><?php echo $a->description; ?></td>
                                <td style="cursor: pointer"><span data-toggle="modal" data-target="#myModalimg<?php echo $a->id_home; ?>">گالري عکس</span>
                                </td>
                                <td>
                                    <i class="fa fa-pencil-square-o edit" data-toggle="modal" data-target="#myModaledit<?php echo $a->id_home; ?>"></i>
                                    <i class="fa fa-times remove" data-toggle="modal" data-target="#myModalremove<?php echo $a->id_home; ?>"></i>
                                </td>
                            </tr>

                            <?php
                            $x++;
                        }
                    } else if ($rows2 == null) {
                        echo '<div style="color:red">موجود نيست</div>';
                    }
                    ?>
                </table>
                <div class="page">
                    <div class="page_in" id="ajax_pagingsearc">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
            </div>
            <?php if ($rows2 != null) {
                foreach ($rows1 as $a) {
                    ?>
                    <div class="modal fade" id="myModalimg<?php echo $a->id_home; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document" style="margin-right: 250px">
                            <div class="modal-content" style="width: 900px;">
                                <img class="img_home" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img1; ?>">
                                <img class="img_home" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img2; ?>">
                                <img class="img_home" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img3; ?>">
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="myModaledit<?php echo $a->id_home; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">

                            <div class="modal-content" style="margin-top: -100px;">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title font_title" id="myModalLabel">ويرايش</h4>
                                </div>

                                <div class="modal-body" id="form">
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="price">قيمت:</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" value="<?php echo $a->price; ?>" name="price" id="price<?php echo $a->id_home; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="area">متراژ :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" value="<?php echo $a->area; ?>" name="area" id="area<?php echo $a->id_home; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="elevator">آسانسور:</label>
                                        <div class="col-sm-7">          
                                            <select class="form-control" name="elevator"  id="elevator<?php echo $a->id_home; ?>">
                                                <option value="<?php echo $a->elevator; ?>" style="display: none"><?php echo $a->type1; ?></option>
                                                <option value="1">بله</option>
                                                <option value="2">خير</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="bedroom">اتاق خواب :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="bedroom" value="<?php echo $a->bedroom; ?>" id="bedroom<?php echo $a->id_home; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="tell">شماره ثابت :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="tell" id="tell<?php echo $a->id_home; ?>" value="<?php echo $a->tell_home; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="phone">تلفن همراه :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="phone" value="<?php echo $a->phone_home; ?>" id="phone<?php echo $a->id_home; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="description">توضيحات :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="description" value="<?php echo $a->description; ?>" id="description<?php echo $a->id_home; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="address">آدرس :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" value="<?php echo $a->address; ?>" name="address" id="address<?php echo $a->id_home; ?>">
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="storehouse">انبار :</label>
                                        <div class="col-sm-7"> 
                                            <select class="form-control" name="storehouse" id="storehouse<?php echo $a->id_home; ?>">
                                                <option value="<?php echo $a->storehouse ?>" style="display: none"><?php echo $a->type_storehouse; ?></option>
                                                <option value="1">بله</option>
                                                <option value="2">خير</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="parking">پارکينگ :</label>
                                        <div class="col-sm-7"> 
                                            <select class="form-control" name="parking" id="parking<?php echo $a->id_home; ?>">
                                                <option value="<?php echo $a->parking; ?>" style="display: none"><?php echo $a->type_parking; ?></option>
                                                <option value="2">بله</option>
                                                <option value="1">خير</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group form-group1">
                                        <label class="control-label col-sm-2 size_font" for="build">سال ساخت :</label>
                                        <div class="col-sm-7">          
                                            <input type="text" class="form-control" name="build" value="<?php echo $a->build; ?>" id="build<?php echo $a->id_home; ?>">
                                        </div>
                                    </div>
                                    <form action="" method="post" id="form1">
                                        <div class="form-group form-group1">
                                            <label class="control-label col-sm-2 size_font" for="img1">عکس 1 :</label>
                                            <div class="col-sm-7">
                                                <img width="70" height="50" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img1; ?>" id="img1_sh<?php echo $a->id_home; ?>">
                                                <i class="fa fa-times" style="color: red" id="img1_i<?php echo $a->id_home; ?>"></i>
                                                <input type="file" class="form-control" name="img1" value="<?php echo $a->img1; ?>" id="img1<?php echo $a->id_home; ?>">
                                                <input type="type" style="display: none" name="id" value="<?php echo $a->id_home; ?>" id="id<?php echo $a->id_home; ?>">
                                            </div>
                                        </div>
                                    </form>
                                    <br>
                                    <form action="" method="post" id="form2">
                                        <div class="form-group form-group1">
                                            <label class="control-label col-sm-2 size_font" for="img2">عکس 2 :</label>
                                            <div class="col-sm-7">          
                                                <img width="70" height="50" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img2; ?>" id="img2_sh<?php echo $a->id_home; ?>">
                                                <i class="fa fa-times" style="color: red" id="img2_i<?php echo $a->id_home; ?>"></i>
                                                <input type="file" class="form-control" name="img2" value="<?php echo $a->img2; ?>" id="img2<?php echo $a->id_home; ?>">
                                                <input type="type" style="display: none" name="id" value="<?php echo $a->id_home; ?>" id="id<?php echo $a->id_home; ?>">
                                            </div>
                                        </div>
                                    </form>
                                    <br>
                                    <form action="" method="post" id="form3">
                                        <div class="form-group form-group1">
                                            <label class="control-label col-sm-2 size_font" for="img3">عکس 3 :</label>
                                            <div class="col-sm-7">      
                                                <img width="70" height="50" src="<?php echo base_url(); ?>assets/upload/<?php echo $a->img3; ?>" id="img3_sh<?php echo $a->id_home; ?>">
                                                <i class="fa fa-times" style="color: red" id="img3_i<?php echo $a->id_home; ?>"></i>
                                                <input type="file" class="form-control" name="img3" value="<?php echo $a->img3; ?>" id="img3<?php echo $a->id_home; ?>">
                                                <input type="type" style="display: none" name="id" value="<?php echo $a->id_home; ?>" id="id<?php echo $a->id_home; ?>">
                                            </div><br>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-body modal-body1" id="resend_add"></div>
                                <div class="modal-footer" >
                                    <button type="button" id="close_form" class="btn btn-default font_title" data-dismiss="modal">بستن</button>
                                    <input name="submit" type="submit" id="edit_home<?php echo $a->id_home; ?>" class="btn btn-primary font_title" value="ويرايش">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="myModalremove<?php echo $a->id_home; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">

                            <div class="modal-content" style="margin-top: -100px;">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title font_title" id="myModalLabel">حذف</h4>
                                </div>
                                <div class="modal-body" id="form">
                                    آیا مطمئن هستید که می خواهید این خانه را حذف کنید؟
                                </div>
                                <div class="modal-body modal-body1" id="resend_add"></div>
                                <div class="modal-footer" >
                                    <button type="button" id="close_form" class="btn btn-default font_title" data-dismiss="modal">خیر</button>
                                    <input name="submit" type="submit" id="remove_home<?php echo $a->id_home; ?>" class="btn btn-danger font_title" value="بله">
                                </div>
                            </div>
                        </div>
                    </div>
    <?php }
} ?>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        applyPagination();

        function applyPagination() {
            $("#ajax_pagingsearc a").click(function () {
                var url = $(this).attr("href");
                $.ajax({
                    type: "POST",
                    data: "ajax=1",
                    url: url,
                    success: function (msg) {
                        $(".ajax_show_estate").html(msg);
                        applyPagination();
                    }
                });
                return false;
            });
        }
    });
</script>
<script>
<?php foreach ($rows1 as $b) { ?>
        $(document).ready(function () {
            $('#img1<?php echo $b->id_home; ?>').hide();
            $('#img2<?php echo $b->id_home; ?>').hide();
            $('#img3<?php echo $b->id_home; ?>').hide();
            $('#img1_i<?php echo $b->id_home; ?>').click(function () {
                $('#img1_sh<?php echo $b->id_home; ?>').hide();
                $('#img1_i<?php echo $b->id_home; ?>').hide();
                $('#img1<?php echo $b->id_home; ?>').show();
                $(document).on('change', '#img1<?php echo $b->id_home; ?>', function () {
                    var formData = new FormData($("#form1")[0]);
                    $.ajax({
                        url: '<?php echo base_url('panel/upload1'); ?>',
                        type: "POST",
                        data: formData,
                        fileElementId: 'image',
                        async: false,
                        success: function (data)
                        {
                            $('#img1<?php echo $b->id_home; ?>').hide();
                            $('#img1_sh<?php echo $b->id_home; ?>').show();
                            $('#img1_sh<?php echo $b->id_home; ?>').attr({src: '<?php echo base_url(); ?>assets/upload/' + data});
                            $('#img1_i<?php echo $b->id_home; ?>').show();
                        },
                        cache: false,
                        contentType: false,
                        processData: false
                    });
                });
            });
            $('#img2_i<?php echo $b->id_home; ?>').click(function () {
                $('#img2_sh<?php echo $b->id_home; ?>').hide();
                $('#img2_i<?php echo $b->id_home; ?>').hide();
                $('#img2<?php echo $b->id_home; ?>').show();
                $(document).on('change', '#img2<?php echo $b->id_home; ?>', function () {
                    var formData = new FormData($("#form2")[0]);
                    $.ajax({
                        url: '<?php echo base_url('panel/upload2'); ?>',
                        type: "POST",
                        data: formData,
                        fileElementId: 'image',
                        async: false,
                        success: function (data)
                        {
                            $('#img2<?php echo $b->id_home; ?>').hide();
                            $('#img2_sh<?php echo $b->id_home; ?>').show();
                            $('#img2_sh<?php echo $b->id_home; ?>').attr({src: '<?php echo base_url(); ?>assets/upload/' + data});
                            $('#img2_i<?php echo $b->id_home; ?>').show();
                        },
                        cache: false,
                        contentType: false,
                        processData: false
                    });
                });
            });
            $('#img3_i<?php echo $b->id_home; ?>').click(function () {
                $('#img3_sh<?php echo $b->id_home; ?>').hide();
                $('#img3_i<?php echo $b->id_home; ?>').hide();
                $('#img3<?php echo $b->id_home; ?>').show();
                $(document).on('change', '#img3<?php echo $b->id_home; ?>', function () {
                    var formData = new FormData($("#form3")[0]);
                    $.ajax({
                        url: '<?php echo base_url('panel/upload3'); ?>',
                        type: "POST",
                        data: formData,
                        fileElementId: 'image',
                        async: false,
                        success: function (data)
                        {
                            $('#img3<?php echo $b->id_home; ?>').hide();
                            $('#img3_sh<?php echo $b->id_home; ?>').show();
                            $('#img3_sh<?php echo $b->id_home; ?>').attr({src: '<?php echo base_url(); ?>assets/upload/' + data});
                            $('#img3_i<?php echo $b->id_home; ?>').show();
                        },
                        cache: false,
                        contentType: false,
                        processData: false
                    });
                });
            });
            $(document).on('click', '#edit_home<?php echo $b->id_home; ?>', function () {
                var id = <?php echo $b->id_home; ?>;
                var y1 = $('#price<?php echo $b->id_home; ?>').val();
                var y2 = $('#area<?php echo $b->id_home; ?>').val();
                var y3 = $('#elevator<?php echo $b->id_home; ?>').val();
                var y4 = $('#bedroom<?php echo $b->id_home; ?>').val();
                var y5 = $('#tell<?php echo $b->id_home; ?>').val();
                var y6 = $('#phone<?php echo $b->id_home; ?>').val();
                var y7 = $('#description<?php echo $b->id_home; ?>').val();
                var y8 = $('#address<?php echo $b->id_home; ?>').val();
                var y9 = $('#storehouse<?php echo $b->id_home; ?>').val();
                var y10 = $('#parking<?php echo $b->id_home; ?>').val();
                var y11 = $('#build<?php echo $b->id_home; ?>').val();
                if (y1 != '' & y2 != '' & y3 != '' & y4 != '' & y5 != '' & y6 != '' & y7 != '' & y8 != '' & y9 != '' & y10 != '' & y11 != '') {
                    $.post("<?php echo base_url('panel/edit_home'); ?>", {id: id, q1: y1, q2: y2, q3: y3, q4: y4, q5: y5, q6: y6, q7: y7, q8: y8, q9: y9, q10: y10, q11: y11}, function (data) {
                        alert(data);
                    });
                } else {
                    alert('پر کردن تمامی فیلد ها اجباری می باشد');
                }
            });
            $(document).on('click', '#remove_home<?php echo $b->id_home; ?>', function () {
                var id = <?php echo $b->id_home; ?>;
                $.post('<?php echo base_url('panel/remove'); ?>', {q1: id}, function (data) {
                    alert(data);
                });
            });

            $(document).on('change','#status_home<?php echo $b->id_home ?>',function (){
                var val = $('#status_home<?php echo $b->id_home; ?>').val();
                var id = <?php echo $b->id_home; ?>;
                $.post('<?php echo base_url('panel/status_home'); ?>',{q:val,p:id},function(data){
                    if(data == 'در حال فروش'){
                        $('#status_home<?php echo $b->id_home; ?>').css('background-color', '#00a157');
                    }else if(data == 'فروخته شده'){
                        $('#status_home<?php echo $b->id_home; ?>').css('background-color', '#c9302c');
                    }
                });
            });
        });
<?php } ?>
</script>