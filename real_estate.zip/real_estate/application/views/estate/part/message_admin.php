<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="margin-top: -80px;" style="margin-bottom: 10px">
                    <div class="modal-header">
                        <textarea name="message" id="pm" class="form-control" placeholder="متن پیام"></textarea>
                        <input style="margin-top: 10px;" class="btn btn-lg btn-success btn-block" name="submit" type="submit" value="ارسال" id="send">
                    </div>
                    <div class="modal-body  modal-body1" id="form">
                        <div class="message_box_show" id="msg">
                            <?php
                            if ($rows_message !== null) {
                                foreach ($rows_message as $a) {
                                    if ($a->send == 0) {
                                        ?>
                                        <div class="message_box_show_out">
                                            <span class="date_message"><?php echo $a->date; ?></span><br>
                                            <?php echo $a->message; ?></div>
                                    <?php } else { ?>
                                        <div class="message_box_show_in">
                                            <span class="date_message"><?php echo $a->date; ?></span><br>
                                            <?php echo $a->message; ?></div>
                                            <?php
                                        }
                                    }
                                }
                                ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        $.post("<?php echo base_url('panel/noti_message'); ?>");
        refresh();
        function refresh() {
            setTimeout(function () {
                $('#msg').load('<?php echo base_url('panel/msg'); ?>');
                refresh();
            }, 5000);
        }
        ;
        var y3 = 0;
        $(document).on('blur', '#pm', function () {
            if ($('#pm').val() == null || $('#pm').val() == "") {
                alert('پیغام را وارد کنید');
                $('#pm').css('border-color', 'red');
                y3 = 0;
                if (y3 == 1) {
                    $('#send').removeClass('disabled');
                } else {
                    $('#send').addClass('disabled');
                }
            } else {
                $('#pm').css('border-color', 'green');
                y3 = 1;
                if (y3 == 1) {
                    $('#send').removeClass('disabled');
                } else {
                    $('#send').addClass('disabled');
                }
            }
        });
        if (y3 == 1) {
            $('#send').removeClass('disabled');
        } else {
            $('#send').addClass('disabled');
        }
        $(document).on('click', '#send', function () {
            var message = $('#pm').val();
            $.post("<?php echo base_url('panel/send_pm'); ?>", {q1: message}, function () {
                alert('ارسال شد');
            });
        });

    });</script>