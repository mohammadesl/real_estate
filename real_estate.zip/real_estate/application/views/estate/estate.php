<?php require_once 'part/template/estate_header.php'; ?>
<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.0.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>

<?php foreach ($rows as $a) { ?>
    <script>
        $(document).ready(function () {
            refresh();
            function refresh() {
                setTimeout(function () {
                    $('#new_msg_count').load('<?php echo base_url('site/new_msg_count1'); ?>?x=<?php echo $a->username; ?> #new_msg_count');
                    refresh();
                }, 1000);
            }
            ;
        });
    </script>
    <?php if ($a->status == 1) {
        ?>
        <body style="background-color: orange">
            <div class="container">
                <div class="row vertical-offset-100">
                    <div class="col-md-4 col-md-offset-4 pending_user" >
                        مدیریت محترم املاک <span style="color: red"><?php echo $a->name; ?></span> آقا/خانم <span style="color: red"><?php echo $a->manager; ?></span> شما باید تا تایید مشخصاتتان توسط مدیریت منتظر بمانید.<br>با تشکر مدیریت محترم سایت
                        <br>
                        <a href="<?php echo base_url('site/logout'); ?>" style="font-weight: bold;font-size: 40px;color: white;margin-right: 170px;" title="خروج">
                            <span class="fa fa-power-off"></span>
                        </a>
                    </div>
                </div>
            </div>
        </body>
    <?php } elseif ($a->status == 2) { ?>
        <body class="hold-transition skin-blue sidebar-mini" onload="up206b.initialize()">
            <div class="wrapper">
                <header class="main-header">
                    <a href="<?php echo base_url('panel'); ?>" class="logo" style="background-color: #009999">
                        <span class="logo-mini font_title" style="font-size: 10px">املاک <?php
                            foreach ($rows as $a) {
                                echo $a->name;
                            }
                            ?></span>
                        <span class="logo-lg font_title">املاک <?php
                            foreach ($rows as $a) {
                                echo $a->name;
                            }
                            ?></span>
                    </a>
                    <nav class="navbar navbar-static-top" role="navigation" style="background-color: #00b0b1">
                        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                            <span class="sr-only">منو</span>
                        </a>
                        <div class="navbar-custom-menu">
                            <ul class="nav navbar-nav">
                                <li class="messages-menu" style="margin-bottom:0px;">
                                    <a href="<?php echo base_url('site/logout'); ?>" style="color: red;font-size: 19px;" title="خروج">
                                        <i class="fa fa-power-off"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </header>
                <aside class="main-sidebar">
                    <section class="sidebar">
                        <ul class="sidebar-menu">
                            <li class="header menu_admin">منو اصلی</li> 
                            <li class="treeview <?php if ($page == 1 || $page == 2 || $page == 3) { ?> active <?php } ?>">
                                <a href="#">
                                    <i class="fa fa-plus-square"></i>
                                    <span>افزودن ملک</span>
                                    <i class="fa fa-angle-left pull-right"></i>
                                </a>
                                <ul class="treeview-menu">
                                    <li class="<?php if ($page == 1) { ?>active<?php } ?>"><a href="<?php echo base_url('panel/home_sale'); ?>"><i class="fa fa-check-square"></i> فروش</a></li>
                                    <li class="<?php if ($page == 2) { ?>active<?php } ?>"><a href="<?php echo base_url('panel/home_mortgage'); ?>"><i class="fa fa-check-square"></i> رهن</a></li>
                                    <li class="<?php if ($page == 3) { ?>active<?php } ?>"><a href="<?php echo base_url('panel/home_rent'); ?>"><i class="fa fa-check-square"></i> اجاره</a></li>
                                </ul>
                            </li>
                            <li class="treeview <?php if ($page == 7 || $page == 8 || $page == 9) { ?>active<?php } ?>">
                                <a href="#">
                                    <i class="fa fa-home"></i>
                                    <span>املاک</span>
                                    <span class="fa fa-angle-left pull-right"></span>
                                </a>
                                <ul class="treeview-menu">
                                    <li class="<?php if ($page == 7) { ?>active<?php } ?>"><a href="<?php echo base_url('panel/home_sale_show'); ?>"><i class="fa fa-check-square-o"></i> فروش</a></li>
                                    <li class="<?php if ($page == 8) { ?>active<?php } ?>"><a href="<?php echo base_url('panel/home_mortgage_show'); ?>"><i class="fa fa-check-square-o"></i> رهن</a>
                                    <li class="<?php if ($page == 9) { ?>active<?php } ?>"><a href="<?php echo base_url('panel/home_rent_show'); ?>"><i class="fa fa-check-square-o"></i> اجاره</a> 
                                </ul>
                            </li>
                            <li id="message1" class="treeview <?php if ($page == 5) { ?> active <?php } ?>">
                                <a href="<?php echo base_url('panel/message_admin'); ?>">
                                    <i class="fa fa-envelope"></i>
                                    <span>پیام ها</span>
                                    <span id="new_msg_count"> 
                                        <span class="label label-danger pull-right" ><?php echo $new_msg_count; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="treeview <?php if ($page == 10) { ?> active <?php } ?>">
                                <a href="<?php echo base_url('panel/edit'); ?>">
                                    <i class="fa fa-lock"></i>
                                    <span>ویرایش اطلاعات کاربری</span>
                                </a>
                            </li>
                            <li class="treeview <?php if ($page == 6) { ?> active <?php } ?>">
                                <a href="#">
                                    <i class="fa fa-lock"></i>
                                    <span>امنیت</span>
                                    <i class="fa fa-angle-left pull-right"></i>
                                </a>
                                <ul class="treeview-menu">
                                    <li class="<?php if ($page == 6) { ?>active<?php } ?>"><a href="<?php echo base_url('panel/change_pass'); ?>"><i class="fa fa-check-square"></i> تغییر پسورد</a></li>
                                </ul>
                            </li>
                        </ul>
                    </section>
                </aside>
                <div class="content-wrapper">
                    <section class="content-header">
                        <h1>
                            پنل مشاوران املاک
                        </h1>
                        <div class="body_admin">
                            <?php
                            if ($page == 1) {
                                require_once 'part/home_sale.php';
                            } elseif ($page == 2) {
                                require_once 'part/home_mortgage.php';
                            } elseif ($page == 3) {
                                require_once 'part/home_rent.php';
                            } elseif ($page == 5) {
                                require_once 'part/message_admin.php';
                            } elseif ($page == 6) {
                                require_once 'part/change_pass.php';
                            } elseif ($page == 7) {
                                require_once 'part/home_sale_show.php';
                            } elseif ($page == 8) {
                                require_once 'part/home_mortgage_show.php';
                            } elseif ($page == 9) {
                                require_once 'part/home_rent_show.php';
                            } elseif ($page == 10) {
                                require_once 'part/edit.php';
                            } else {
                                require_once 'part/main_page.php';
                            }
                            ?>
                        </div>
                    </section>
                </div>
            </div>
        </body>
        <?php
    } elseif ($a->status == 3) {
        ?>
        <body style="background-color: red">
            <div class="container">
                <div class="row vertical-offset-100">
                    <div class="col-md-4 col-md-offset-4 pending_user" >
                        مدیریت محترم املاک <span style="color: orange"><?php echo $a->name; ?></span> آقا/خانم <span style="color: orange"><?php echo $a->manager; ?></span> متاسفانه سرویس اشتراک شما در سایت بنا به دلایلی لغو شده است<br>برای اطلاعات از جزییات با ما تماس بگیرید.<br>با تشکر مدیریت محترم سایت
                        <br>
                        <a href="<?php echo base_url('site/logout'); ?>" style="font-weight: bold;font-size: 40px;color: white;margin-right: 170px;" title="خروج">
                            <span class="fa fa-power-off"></span>
                        </a>
                    </div>
                </div>
            </div>
        </body>       
        <?php
    }
}
?>
<?php require_once 'part/template/estate_footer.php'; ?>