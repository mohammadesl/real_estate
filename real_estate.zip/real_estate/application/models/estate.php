<?php
class estate extends CI_Model {
    
    public function pass($id,$pass){
        $data = array(
            'password' => $pass
        );
        $this->db->where('id1', $id);
        $this->db->update('estate', $data);
    }
    
    public function search_user($x) {
        $this->db->select('username');
        $this->db->where('id1', $x);
        $this->db->limit(1);
        $q = $this->db->get('estate');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function search_user2($x) {
        $this->db->select('mail');
        $this->db->where('id_user', $x);
        $this->db->limit(1);
        $q = $this->db->get('user');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function msg($x){
        $this->db->select();
        $this->db->where('username_estate', $x);
        $this->db->order_by('id_message','DESC');
        $q = $this->db->get('message');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function msg2($x){
        $this->db->select();
        $this->db->where('email', $x);
        $this->db->order_by('id','DESC');
        $q = $this->db->get('contact_us');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function noti_message($x) {
        $data = array(
            'seen_user' => 1
        );
        $this->db->where('username_estate', $x);
        $this->db->update('message', $data);
    }
    
    public function send_message_admin($x, $y) {
        $this->db->set('username_estate', $x);
        $this->db->set('message', $y);
        $this->db->set('date', jdate('Y / F / j _ H:i:s'));
        $this->db->set('send', 0);
        $this->db->set('seen_admin', 0);
        $this->db->set('seen_user', 1);
        $this->db->insert('message');
    }
    
    public function send_message_admin2($x, $y) {
        $this->db->set('email', $x);
        $this->db->set('message', $y);
        $this->db->set('date', jdate('Y / F / j _ H:i:s'));
        $this->db->set('send', 0);
        $this->db->set('seen_admin', 0);
        $this->db->set('seen_user', 1);
        $this->db->insert('contact_us');
    }
    
    public function home_sale_show ($limit, $start,$id) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '1');
        $this->db->where('id_real_estate', $id);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $this->db->limit($limit, $start);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function home_sale_show1($id) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '1');
        $this->db->where('id_real_estate', $id);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function edit_home($id,$q1,$q2,$q3,$q4,$q5,$q6,$q7,$q8,$q9,$q10,$q11) {
        $data = array(
            'price' => $q1,
            'area' => $q2,
            'elevator' => $q3,
            'bedroom' => $q4,
            'tell_home' => $q5,
            'phone_home' => $q6,
            'description' => $q7,
            'address_home' => $q8,
            'storehouse' => $q9,
            'parking' => $q10,
            'build' => $q11
        );
        $this->db->where('id_home', $id);
        $this->db->update('home', $data);
    }
    
    public function upload1($x,$y) {
        $data = array(
            'img1' => $x
        );
        $this->db->where('id_home', $y);
        $this->db->update('home', $data);
    }
    
    public function upload2($x,$y) {
        $data = array(
            'img2' => $x
        );
        $this->db->where('id_home', $y);
        $this->db->update('home', $data);
    }
    
    public function upload3($x,$y) {
        $data = array(
            'img3' => $x
        );
        $this->db->where('id_home', $y);
        $this->db->update('home', $data);
    }
    
    public function uploadshow1($x){
        $this->db->select('img1,img2,img3');
        $this->db->where('id_home', $x);
        $q = $this->db->get('home');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function remove($x){
        $this->db->delete('home', array('id_home' => $x)); 
    }
    /////////
    public function home_sale_search_price_sale($id) {
        $this->db->select('price');
        $this->db->where('status_home', '1');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_sale_search_price_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('price', $z[$i]);
            $this->db->where('status_home', '1');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_sale_search_address_home($id) {
        $this->db->select('address_home');
        $this->db->where('status_home', '1');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_sale_search_address_home_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('address_home', $z[$i]);
            $this->db->where('status_home', '1');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_sale_search_bedroom($id) {
        $this->db->select('bedroom');
        $this->db->where('status_home', '1');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_sale_search_bedroom_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('bedroom', $z[$i]);
            $this->db->where('status_home', '1');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_sale_search_area($id) {
        $this->db->select('area');
        $this->db->where('status_home', '1');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_sale_search_area_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('area', $z[$i]);
            $this->db->where('status_home', '1');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }
    ///////
    public function update_home($val, $id) {
        $data = array(
            'type_home' => $val
        );
        $this->db->where('id_home', $id);
        $this->db->update('home', $data);
    }
    
    public function update_home_show($id) {
        $this->db->select('type_sale');
        $this->db->where('id_home', $id);
        $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function home_rent_show ($limit, $start,$id) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '3');
        $this->db->where('id_real_estate', $id);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $this->db->limit($limit, $start);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function home_rent_show1($id) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '3');
        $this->db->where('id_real_estate', $id);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    public function home_rent_search_price_sale($id) {
        $this->db->select('price');
        $this->db->where('status_home', '3');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent_search_price_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('price', $z[$i]);
            $this->db->where('status_home', '3');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_rent_search_address_home($id) {
        $this->db->select('address_home');
        $this->db->where('status_home', '3');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent_search_address_home_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('address_home', $z[$i]);
            $this->db->where('status_home', '3');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_rent_search_bedroom($id) {
        $this->db->select('bedroom');
        $this->db->where('status_home', '3');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent_search_bedroom_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('bedroom', $z[$i]);
            $this->db->where('status_home', '3');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_rent_search_area($id) {
        $this->db->select('area');
        $this->db->where('status_home', '3');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent_search_area_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('area', $z[$i]);
            $this->db->where('status_home', '3');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }
    
    public function home_mortgage_show ($limit, $start,$id) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '2');
        $this->db->where('id_real_estate', $id);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $this->db->limit($limit, $start);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function home_mortgage_show1($id) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '2');
        $this->db->where('id_real_estate', $id);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    public function home_mortgage_search_price_sale($id) {
        $this->db->select('price');
        $this->db->where('status_home', '2');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage_search_price_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('price', $z[$i]);
            $this->db->where('status_home', '2');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_mortgage_search_address_home($id) {
        $this->db->select('address_home');
        $this->db->where('status_home', '2');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage_search_address_home_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('address_home', $z[$i]);
            $this->db->where('status_home', '2');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_mortgage_search_bedroom($id) {
        $this->db->select('bedroom');
        $this->db->where('status_home', '2');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage_search_bedroom_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('bedroom', $z[$i]);
            $this->db->where('status_home', '2');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_mortgage_search_area($id) {
        $this->db->select('area');
        $this->db->where('status_home', '2');
        $this->db->where('id_real_estate', $id);
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage_search_area_show($x,$id) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('area', $z[$i]);
            $this->db->where('status_home', '2');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $this->db->where('id_real_estate', $id);
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }
    
    public function home_sale_print($x) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '1');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
        $this->db->where('estate.id1', $x);
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function home_mortgage_print($x) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '2');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
        $this->db->where('estate.id1', $x);
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function home_rent_print($x) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '3');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
        $this->db->where('estate.id1', $x);
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
     public function add_home($lon,$lat,$price,$area,$elevator,$bedroom,$tell,$phone,$description,$address,$storehouse,$parking,$build,$id,$img1,$img2,$img3) {
        $this->db->set('status_home', 1);
        $this->db->set('price', $price);
        $this->db->set('area', $area);
        $this->db->set('elevator', $elevator);
        $this->db->set('bedroom', $bedroom);
        $this->db->set('tell_home', $tell);
        $this->db->set('phone_home', $phone);
        $this->db->set('description', $description);
        $this->db->set('register_date', jdate('Y / F / j _ H:i:s'));
        $this->db->set('id_real_estate', $id);
        $this->db->set('type_home', 1);
        $this->db->set('address_home', $address);
        $this->db->set('lon', $lon);
        $this->db->set('lat', $lat);
        $this->db->set('storehouse', $storehouse);
        $this->db->set('parking', $parking);
        if($img1 != null){
        $this->db->set('img1', $img1);
        }if($img2 != null){
        $this->db->set('img2', $img2);
        }if($img3 != null){
        $this->db->set('img3', $img3);
        }
        $this->db->set('build', $build);
        $this->db->insert('home');
    }
    
    public function add_home_rent($lon,$lat,$price,$area,$elevator,$bedroom,$tell,$phone,$description,$address,$storehouse,$parking,$build,$id,$img1,$img2,$img3) {
        $this->db->set('status_home', 3);
        $this->db->set('price', $price);
        $this->db->set('area', $area);
        $this->db->set('elevator', $elevator);
        $this->db->set('bedroom', $bedroom);
        $this->db->set('tell_home', $tell);
        $this->db->set('phone_home', $phone);
        $this->db->set('description', $description);
        $this->db->set('register_date', jdate('Y / F / j _ H:i:s'));
        $this->db->set('id_real_estate', $id);
        $this->db->set('type_home', 1);
        $this->db->set('address_home', $address);
        $this->db->set('lon', $lon);
        $this->db->set('lat', $lat);
        $this->db->set('storehouse', $storehouse);
        $this->db->set('parking', $parking);
        if($img1 != null){
        $this->db->set('img1', $img1);
        }if($img2 != null){
        $this->db->set('img2', $img2);
        }if($img3 != null){
        $this->db->set('img3', $img3);
        }
        $this->db->set('build', $build);
        $this->db->insert('home');
    }
    
    public function add_home_mortgage($lon,$lat,$price,$area,$elevator,$bedroom,$tell,$phone,$description,$address,$storehouse,$parking,$build,$id,$img1,$img2,$img3) {
        $this->db->set('status_home', 2);
        $this->db->set('price', $price);
        $this->db->set('area', $area);
        $this->db->set('elevator', $elevator);
        $this->db->set('bedroom', $bedroom);
        $this->db->set('tell_home', $tell);
        $this->db->set('phone_home', $phone);
        $this->db->set('description', $description);
        $this->db->set('register_date', jdate('Y / F / j _ H:i:s'));
        $this->db->set('id_real_estate', $id);
        $this->db->set('type_home', 1);
        $this->db->set('address_home', $address);
        $this->db->set('lon', $lon);
        $this->db->set('lat', $lat);
        $this->db->set('storehouse', $storehouse);
        $this->db->set('parking', $parking);
        if($img1 != null){
        $this->db->set('img1', $img1);
        }if($img2 != null){
        $this->db->set('img2', $img2);
        }if($img3 != null){
        $this->db->set('img3', $img3);
        }
        $this->db->set('build', $build);
        $this->db->insert('home');
    }
    
    public function getdata_search($id,$price_down, $price_up, $bedroom, $build, $type, $parking, $elevator, $storehouse) {
        $this->db->select('*');
        $this->db->where('type_home', 1);
        $this->db->where('id_real_estate', $id);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->where('price >=', $price_down);
        $this->db->where('price <=', $price_up);
        if ($bedroom != 0) {
            $this->db->where('bedroom', $bedroom);
        }
        if ($build != 0) {
            $this->db->where('build', $build);
        }
        if ($type != 0) {
            $this->db->where('status_home', $type);
        }
        if ($parking != 0) {
            $this->db->where('parking', 1);
        }
        if ($elevator != 0) {
            $this->db->where('elevator', 1);
        }
        if ($storehouse != 0) {
            $this->db->where('storehouse', 1);
        }
       $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function edit($id) {
        $this->db->select();
        $this->db->where('id1', $id);
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
     public function edit_member($id,$name, $manager, $tell, $phone, $address) {
        $data = array(
            'name' => $name,
            'manager' => $manager,
            'tell' => $tell,
            'phone' => $phone,
            'address' => $address
        );
        $this->db->where('id1', $id);
        $this->db->update('estate', $data);
    }
    
}
