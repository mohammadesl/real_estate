<?php

class Admin extends CI_Model {

    public function real_estate($limit, $start) {
        $this->db->select('*');
        $this->db->from('estate');
        $this->db->join('status', 'estate.status = status.id', 'inner');
        $this->db->order_by('estate.id1', 'DESC');
        $this->db->limit($limit, $start);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate1() {
        $this->db->select('*');
        $this->db->from('estate');
        $this->db->join('status', 'estate.status = status.id', 'inner');
        $this->db->order_by('estate.id1', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_pendding($limit, $start) {
        $this->db->select('*');
        $this->db->from('estate');
        $this->db->join('status', 'estate.status = status.id', 'inner');
        $this->db->order_by('estate.id1', 'DESC');
        $this->db->where('estate.status', '1');
        $this->db->limit($limit, $start);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_pendding1() {
        $this->db->select('*');
        $this->db->from('estate');
        $this->db->join('status', 'estate.status = status.id', 'inner');
        $this->db->order_by('estate.id1', 'DESC');
        $this->db->where('estate.status', '1');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function add_real_estate($name, $date, $manager, $register, $tell, $phone, $address, $user, $pass, $img) {
        $this->db->set('name', $name);
        $this->db->set('date_ragister', $date);
        $this->db->set('manager', $manager);
        $this->db->set('register_num', $register);
        $this->db->set('tell', $tell);
        $this->db->set('phone', $phone);
        $this->db->set('address', $address);
        $this->db->set('username', $user);
        $this->db->set('password', $pass);
        $this->db->set('evidence', $img);
        $this->db->set('status', 2);
        $this->db->set('type_admin', 0);
        $this->db->insert('estate');
    }

    public function add_real_estate_user($name, $date, $manager, $register, $tell, $phone, $address, $user, $pass, $img) {
        $this->db->set('name', $name);
        $this->db->set('date_ragister', $date);
        $this->db->set('manager', $manager);
        $this->db->set('register_num', $register);
        $this->db->set('tell', $tell);
        $this->db->set('phone', $phone);
        $this->db->set('address', $address);
        $this->db->set('username', $user);
        $this->db->set('password', $pass);
        $this->db->set('evidence', $img);
        $this->db->set('status', 1);
        $this->db->set('type_admin', 0);
        $this->db->insert('estate');
    }

    public function real_estate_user() {
        $this->db->select('username');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function real_estate_user2() {
        $this->db->select('mail');
        $query = $this->db->get('user');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_user_message() {
        $this->db->select('username');
        $this->db->where('type_admin', 0);
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_search_user() {
        $this->db->select('*');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_search_user_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('username', $z[$i]);
            $this->db->join('status', 'estate.status = status.id', 'inner');
            $query = $this->db->get('estate');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function real_estate_search_address() {
        $this->db->select('address');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_search_address_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('address', $z[$i]);
            $this->db->join('status', 'estate.status = status.id', 'inner');
            $query = $this->db->get('estate');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function real_estate_search_manager() {
        $this->db->select('manager');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_search_manager_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('manager', $z[$i]);
            $this->db->join('status', 'estate.status = status.id', 'inner');
            $query = $this->db->get('estate');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function real_estate_search_register() {
        $this->db->select('register_num');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_search_register_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('register_num', $z[$i]);
            $this->db->join('status', 'estate.status = status.id', 'inner');
            $query = $this->db->get('estate');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function real_estate_search_status() {
        $this->db->select('status');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_search_status_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->join('status', 'estate.status = status.id', 'inner');
            $this->db->where('status', $z[$i]);
            $query = $this->db->get('estate');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function update_real_estate($val, $id) {
        $data = array(
            'status' => $val
        );
        $this->db->where('id1', $id);
        $this->db->update('estate', $data);
    }

    public function update_real_estate_show($id) {
        $this->db->select('type');
        $this->db->where('id1', $id);
        $this->db->join('status', 'estate.status = status.id', 'inner');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    /////////////////////////////////////////////////
    public function real_estate_search_user_pending() {
        $this->db->select('*');
        $this->db->where('status', '1');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_search_user_show_pending($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('username', $z[$i]);
            $this->db->where('status', '1');
            $this->db->join('status', 'estate.status = status.id', 'inner');
            $query = $this->db->get('estate');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function real_estate_search_address_pending() {
        $this->db->select('address');
        $this->db->where('status', '1');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_search_address_show_pending($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('address', $z[$i]);
            $this->db->where('status', '1');
            $this->db->join('status', 'estate.status = status.id', 'inner');
            $query = $this->db->get('estate');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function real_estate_search_manager_pending() {
        $this->db->select('manager');
        $this->db->where('status', '1');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_search_manager_show_pending($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('manager', $z[$i]);
            $this->db->where('status', '1');
            $this->db->join('status', 'estate.status = status.id', 'inner');
            $query = $this->db->get('estate');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function real_estate_search_register_pending() {
        $this->db->select('register_num');
        $this->db->where('status', '1');
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function real_estate_search_register_show_pending($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('register_num', $z[$i]);
            $this->db->where('status', '1');
            $this->db->join('status', 'estate.status = status.id', 'inner');
            $query = $this->db->get('estate');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_sale($limit, $start) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '1');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $this->db->limit($limit, $start);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_sale1() {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '1');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_sale_print() {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '1');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage($limit, $start) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '2');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $this->db->limit($limit, $start);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage1() {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '2');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage_print() {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '2');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows()> 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent($limit, $start) {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '3');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $this->db->limit($limit, $start);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent1() {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '3');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent_print() {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '3');
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
        $this->db->order_by('home.id_home', 'DESC');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    ///////
    public function home_sale_search_price_sale() {
        $this->db->select('price');
        $this->db->where('status_home', '1');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_sale_search_price_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('price', $z[$i]);
            $this->db->where('status_home', '1');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_sale_search_address_home() {
        $this->db->select('address_home');
        $this->db->where('status_home', '1');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_sale_search_address_home_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('address_home', $z[$i]);
            $this->db->where('status_home', '1');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_sale_search_bedroom() {
        $this->db->select('bedroom');
        $this->db->where('status_home', '1');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_sale_search_bedroom_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('bedroom', $z[$i]);
            $this->db->where('status_home', '1');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_sale_search_area() {
        $this->db->select('area');
        $this->db->where('status_home', '1');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_sale_search_area_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('area', $z[$i]);
            $this->db->where('status_home', '1');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('sale', 'home.type_home = sale.id_sale', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    ////////////
    public function home_mortgage_search_price_sale() {
        $this->db->select('price');
        $this->db->where('status_home', '2');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage_search_price_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('price', $z[$i]);
            $this->db->where('status_home', '2');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_mortgage_search_address_home() {
        $this->db->select('address_home');
        $this->db->where('status_home', '2');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage_search_address_home_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('address_home', $z[$i]);
            $this->db->where('status_home', '2');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_mortgage_search_bedroom() {
        $this->db->select('bedroom');
        $this->db->where('status_home', '2');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage_search_bedroom_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('bedroom', $z[$i]);
            $this->db->where('status_home', '2');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_mortgage_search_area() {
        $this->db->select('area');
        $this->db->where('status_home', '2');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_mortgage_search_area_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('area', $z[$i]);
            $this->db->where('status_home', '2');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('mortgage', 'home.type_home = mortgage.id_mortgage', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    ////////
    public function home_rent_search_price_sale() {
        $this->db->select('price');
        $this->db->where('status_home', '3');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent_search_price_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('price', $z[$i]);
            $this->db->where('status_home', '3');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_rent_search_address_home() {
        $this->db->select('address_home');
        $this->db->where('status_home', '3');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent_search_address_home_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('address_home', $z[$i]);
            $this->db->where('status_home', '3');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_rent_search_bedroom() {
        $this->db->select('bedroom');
        $this->db->where('status_home', '3');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent_search_bedroom_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('bedroom', $z[$i]);
            $this->db->where('status_home', '3');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function home_rent_search_area() {
        $this->db->select('area');
        $this->db->where('status_home', '3');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_rent_search_area_show($x) {
        $z = explode(',', $x);
        for ($i = 0; $i < count($z); $i++) {
            $this->db->select('*');
            $this->db->where('area', $z[$i]);
            $this->db->where('status_home', '3');
            $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
            $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
            $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
            $this->db->join('rent', 'home.type_home = rent.id_rent', 'inner');
            $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
            $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
            $query = $this->db->get('home');
            if ($query->num_rows() > 0) {
                foreach ($query->result() as $r) {
                    $data[$i][] = $r;
                }
                return $data;
            }
        }
    }

    public function login($user, $pass) {
        $this->db->select('id1 , type_admin');
        $this->db->limit(1);
        $this->db->where('username', $user);
        $this->db->where('password', $pass);
        $query = $this->db->get('estate');
        if ($query->num_rows() > 0) {
            $result = $query->result();
            foreach ($result as $a) {
                $result = array();
                $result[0] = $a->id1;
                $result[1] = $a->type_admin;
                return $result;
            }
        } else {
            return FALSE;
        }
    }

    public function login_user($user, $pass) {
        $this->db->select('id_user');
        $this->db->limit(1);
        $this->db->where('mail', $user);
        $this->db->where('pass', $pass);
        $query = $this->db->get('user');
        if ($query->num_rows() > 0) {
            $result = $query->result();
            foreach ($result as $a) {
                $result = array();
                $result[0] = $a->id_user;
                return $result;
            }
        } else {
            return FALSE;
        }
    }
    
    public function real_estate_admin($x) {
        $this->db->select();
        $this->db->order_by('id1', 'DESC');
        $this->db->where('type_admin', '0');
        $this->db->where('id1', $x);
        $this->db->limit('1');
        $q = $this->db->get('estate');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {

                $data[] = $r;
            }
            return $data;
        }
    }

    public function send_message_admin($x, $y) {
        $this->db->set('username_estate', $x);
        $this->db->set('message', $y);
        $this->db->set('date', jdate('Y / F / j _ H:i:s'));
        $this->db->set('send', 1);
        $this->db->set('seen_admin', 1);
        $this->db->set('seen_user', 0);
        $this->db->insert('message');
    }
    
    public function send_message_admin2($x, $y) {
        $this->db->set('email', $x);
        $this->db->set('message', $y);
        $this->db->set('date', jdate('Y / F / j _ H:i:s'));
        $this->db->set('send', 1);
        $this->db->set('seen_admin', 1);
        $this->db->set('seen_user', 0);
        $this->db->insert('contact_us');
    }

    public function noti_message($x) {
        $data = array(
            'seen_admin' => 1
        );
        $this->db->where('username_estate', $x);
        $this->db->update('message', $data);
    }
    
    public function noti_message2($x) {
        $data = array(
            'seen_admin' => 1
        );
        $this->db->where('email', $x);
        $this->db->update('contact_us', $data);
    }

    public function send_pm($x) {
        $this->db->select('username_estate');
        $this->db->where('id_message', $x);
        $this->db->limit(1);
        $q = $this->db->get('message');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function send_pm2($x) {
        $this->db->select('email');
        $this->db->where('id', $x);
        $this->db->limit(1);
        $q = $this->db->get('contact_us');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function msg($x) {
        $this->db->select();
        $this->db->where('username_estate', $x);
        $this->db->order_by('id_message', 'DESC');
        $q = $this->db->get('message');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function msg2($x) {
        $this->db->select();
        $this->db->where('email', $x);
        $this->db->order_by('id', 'DESC');
        $q = $this->db->get('contact_us');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function alaki() {
//        $q = 'SELECT  a.* FROM message a WHERE a.id_message = (SELECT  MAX(id_message) id_message FROM message b WHERE   a.username_estate = b.username_estate ) order by id_message DESC ';
//        $result = mysqli_query(\mysqli_connect(),$q);
        $this->db->select('*');
        $this->db->order_by('id_message', 'DESC');
        $result = $this->db->get('message');
        if ($result->num_rows() > 0) {
            foreach ($result->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function pass($id, $pass) {
        $data = array(
            'password' => $pass
        );
        $this->db->where('id1', $id);
        $this->db->update('estate', $data);
    }

    public function gallery_sale($limit, $start) {
        $this->db->select('*');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->order_by('id_home', 'DESC');
        $this->db->where('status_home', '1');
        $this->db->limit($limit, $start);
        $q = $this->db->get('home');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function gallery_sale1() {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '1');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function show_home() {
        $this->db->select('*');
        $q = $this->db->get('home');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {

                $data[] = $r;
            }
            return $data;
        }
    }

    public function getdata() {
        $this->db->select('*');
        $this->db->where('type_home', 1);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function home_page($x) {
        $this->db->select('*');
        $this->db->where('type_home', 1);
        $this->db->where('id_home', $x);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function search_home() {
        $this->db->select('address_home');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function search_home_show($y) {
        $this->db->select('*');
        $this->db->where('address_home', $y);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $q = $this->db->get('home');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function remove_img1($id) {
        $data = array(
            'img1' => 'no.png'
        );
        $this->db->where('id_home', $id);
        $this->db->update('home', $data);
    }

    public function remove_img2($id) {
        $data = array(
            'img2' => 'no.png'
        );
        $this->db->where('id_home', $id);
        $this->db->update('home', $data);
    }

    public function remove_img3($id) {
        $data = array(
            'img3' => 'no.png'
        );
        $this->db->where('id_home', $id);
        $this->db->update('home', $data);
    }

    public function gallery_mortgage($limit, $start) {
        $this->db->select('*');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->order_by('id_home', 'DESC');
        $this->db->where('status_home', '2');
        $this->db->limit($limit, $start);
        $q = $this->db->get('home');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function gallery_mortgage1() {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '2');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function gallery_rent($limit, $start) {
        $this->db->select('*');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->order_by('id_home', 'DESC');
        $this->db->where('status_home', '3');
        $this->db->limit($limit, $start);
        $q = $this->db->get('home');
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function gallery_rent1() {
        $this->db->select('*');
        $this->db->from('home');
        $this->db->where('status_home', '3');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function contact_message($name, $mail, $phone, $message) {
        $this->db->set('name', $name);
        $this->db->set('email', $mail);
        $this->db->set('phone', $phone);
        $this->db->set('date', jdate('Y / F / j _ H:i:s'));
        $this->db->set('message', $message);
        $this->db->insert('contact_us');
    }
    
    public function contact_add($name, $mail, $phone,$pass) {
        $this->db->set('name', $name);
        $this->db->set('mail', $mail);
        $this->db->set('phone', $phone);
        $this->db->set('pass', $pass);
        $this->db->insert('user');
    }

    public function contact($limit, $start) {
        $this->db->select('*');
        $this->db->from('contact_us');
        $this->db->limit($limit, $start);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function contact1() {
        $this->db->select('*');
        $this->db->from('contact_us');
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            foreach ($q->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }

    public function getdata_search($price_down, $price_up, $bedroom, $build, $type, $parking, $elevator, $storehouse) {
        $this->db->select('*');
        $this->db->where('type_home', 1);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $this->db->where('price >=', $price_down);
        $this->db->where('price <=', $price_up);
        if ($bedroom != 0) {
            $this->db->where('bedroom', $bedroom);
        }
        if ($build != 0) {
            $this->db->where('build', $build);
        }
        if ($type != 0) {
            $this->db->where('status_home', $type);
        }
        if ($parking != 0) {
            $this->db->where('parking', 1);
        }
        if ($elevator != 0) {
            $this->db->where('elevator', 1);
        }
        if ($storehouse != 0) {
            $this->db->where('storehouse', 1);
        }
       $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function getdata2($price_down,$price_up) {
        $this->db->select('*');
        $this->db->where('type_home', 1);
        $this->db->where('price >=', $price_down);
        $this->db->where('price <=', $price_up);
        $this->db->join('status_home', 'home.status_home = status_home.id_status_home', 'inner');
        $this->db->join('estate', 'home.id_real_estate = estate.id1', 'inner');
        $this->db->join('elevator', 'home.elevator = elevator.id', 'inner');
        $this->db->join('parking', 'home.parking = parking.id_parking', 'inner');
        $this->db->join('storehouse', 'home.storehouse = storehouse.id_storehouse', 'inner');
        $query = $this->db->get('home');
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function contact_message2() {
//        $q = 'SELECT  a.* FROM contact_us a WHERE a.id = (SELECT  MAX(id) id FROM contact_us b WHERE   a.email = b.email ) order by id DESC ';
//        $result = mysql_query($q);
//        return $result;
        $this->db->select('*');
        $this->db->order_by('id', 'DESC');
        $result = $this->db->get('contact_us');
        if ($result->num_rows() > 0) {
            foreach ($result->result() as $r) {
                $data[] = $r;
            }
            return $data;
        }
    }
    
    public function edit_member($id,$name, $manager, $tell, $phone, $address) {
        $data = array(
            'name' => $name,
            'manager' => $manager,
            'tell' => $tell,
            'phone' => $phone,
            'address' => $address
        );
        $this->db->where('id1', $id);
        $this->db->update('estate', $data);
    }

}
