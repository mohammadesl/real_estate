<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class user extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('type_admin') != 2 | $this->session->userdata('type_admin') == null | $this->session->userdata('id') == null) {
            redirect('site/log_in', 'refresh');
        }
    }

    function index() {
        $id = $this->session->userdata('id');
        $this->load->model('estate');
        $x = $this->estate->search_user2($id);
        if ($x != null) {
            $user = $x[0]->mail;
            $data['rows_message'] = $this->estate->msg2($user);
        } else {
            $data['rows_message'] = null;
        }
        $this->load->view('user/index.php', $data);
    }

    public function send_pm() {
        $x1 = $this->session->userdata('id');
        $message = $_POST['q1'];
        $this->load->model('estate');
        $x = $this->estate->search_user2($x1);
        $user = $x[0]->mail;
        $this->estate->send_message_admin2($user, $message);
    }

    public function msg() {
        $x1 = $this->session->userdata('id');
        $this->load->model('estate');
        $x = $this->estate->search_user2($x1);
        if ($x != null) {
            $user = $x[0]->mail;
            $data['rows'] = $this->estate->msg2($user);
        } else {
            $data['rows'] = null;
        }
        $this->load->view('estate/part/msg.php', $data);
    }

    public function logout() {
            $this->session->unset_userdata('type_admin');
            $this->session->sess_destroy();
            $url = base_url('site/log_in');
            redirect($url);
    }

}
