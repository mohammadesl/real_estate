<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class site extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->library('session');
    }

    public function index() {
        $this->load->model('admin');
        $data['rows'] = $this->admin->show_home();
        $this->load->view('index');
    }

    public function log_in() {
        $data['title'] = 'ورود';
        $data['error'] = '';
        $this->load->view('login.php', $data);
    }

    public function sign_up() {
        $this->load->view('sign_up.php');
    }

    public function check_login() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('user_name', 'نام کاربری', 'trim|required|xss_clean');
        $this->form_validation->set_rules('password', 'رمز عبور', 'trim|required|xss_clean');
        $this->form_validation->set_message('required', 'فیلد %s اجباری است');
        if ($this->form_validation->run() == FALSE) {
            $data['error'] = '';
            $this->load->view('login.php', $data);
        } else {
            $username = $this->input->post('user_name');
            $password = $this->input->post('password');

            $username = $this->mres($username);
            $password = $this->mres($password);
            $password = sha1($password);

            if ($this->input->post('type_user') == 0) {
                $this->load->model('admin', 'fetch');
                $result = $this->fetch->login($username, $password);
                if ($result) {
                    if ($result[1] == 0) {
                        $se_val = array('type_admin' => '0', 'id' => $result[0]);
                        $this->session->set_userdata($se_val);
                        redirect('panel', 'refresh');
                    } elseif ($result[1] == 1) {
                        $se_val = array('type_admin' => '1', 'id' => $result[0]);
                        $this->session->set_userdata($se_val);
                        redirect('site/admin', 'refresh');
                    }
                } else {
                    $message['error'] = 'نام کاربری یا  کلمه عبور اشتباه است';
                    $message['page'] = 1;
                    $this->load->view('login', $message);
                }
            }if ($this->input->post('type_user') == 1) {
                $this->load->model('admin', 'fetch');
                $result = $this->fetch->login_user($username, $password);

                if ($result) {
                    $se_val = array('type_admin' => '2', 'id' => $result[0]);
                    $this->session->set_userdata($se_val);
                    redirect('user', 'refresh');
                } else {
                    $message['error'] = 'نام کاربری یا  کلمه عبور اشتباه است';
                    $message['page'] = 1;
                    $this->load->view('login', $message);
                }
            }
        }
    }

    public function admin() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $data['title'] = 'پنل مدیریت';
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $data['page'] = 0;
            $this->load->view('admin/admin.php', $data);
        }
    }

    public function check_user_message() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $username = $_POST['user_name'];
            $arr_user = $this->admin->real_estate_user_message();

            $result = array();
            foreach ($arr_user as $key => $value) {
                $result[] = $value->username;
            }
            if (in_array($username, $result)) {
                echo '<span id="user_id_span" class="add_estate1">قابل قبول</span>';
                exit;
            } else {
                echo '<span id="user_id_span" class="add_estate">نام کاربری در دسترس نیست</span>';
            }
        }
    }

    public function check_user() {
        $this->load->model('admin');
        $username = $_POST['user_name'];
        $arr_user = $this->admin->real_estate_user();

        $result = array();
        foreach ($arr_user as $key => $value) {
            $result[] = $value->username;
        }
        if (in_array($username, $result)) {
            echo '<span id="user_id_span" class="add_estate">نام کاربری در دسترس نیست</span>';
            exit;
        } else if (strlen($username) < 6 || strlen($username) > 15) {
            echo '<span id="user_id_span" class="add_estate">تعداد حروف باید بین 6 تا 15 باشد.</span>';
        } else {
            echo '<span id="user_id_span" class="add_estate1">قابل قبول</span>';
        }
    }

    public function check_user2() {
        $this->load->model('admin');
        $username = $_POST['user_name'];
        $arr_user = $this->admin->real_estate_user2();
        if ($arr_user != null) {
            $result = array();
            foreach ($arr_user as $key => $value) {
                $result[] = $value->mail;
            }
            if (in_array($username, $result)) {
                echo '<span id="user_id_span" class="add_estate">نام کاربری در دسترس نیست</span>';
                exit;
            } else {
                echo '<span id="user_id_span" class="add_estate1">قابل قبول</span>';
            }
        } else {
            echo '<span id="user_id_span" class="add_estate1">قابل قبول</span>';
        }
    }

    public function search_real_estate_show() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $q = $_POST["q"];
            $p = $_POST["p"];
            $this->load->model('admin');
            if ($p == 'نام کاربری') {
                $arr_user = $this->admin->real_estate_search_user_show($q);
            } elseif ($p == 'آدرس') {
                $arr_user = $this->admin->real_estate_search_address_show($q);
            } elseif ($p == 'مدیر') {
                $arr_user = $this->admin->real_estate_search_manager_show($q);
            } elseif ($p == 'شماره ثبت') {
                $arr_user = $this->admin->real_estate_search_register_show($q);
            } elseif ($p == 'وضعیت') {
                $arr_user = $this->admin->real_estate_search_status_show($q);
            }
            $result = array();
            $result1 = array();
            $result2 = array();
            $result3 = array();
            $result4 = array();
            $result5 = array();
            $result6 = array();
            $result7 = array();
            $result8 = array();
            $result9 = array();
            $result10 = array();
            foreach ($arr_user[0] as $key => $value) {
                $result[] = $value->id1;
                $result1[] = $value->name;
                $result2[] = $value->date_ragister;
                $result3[] = $value->type;
                $result4[] = $value->manager;
                $result5[] = $value->register_num;
                $result6[] = $value->address;
                $result7[] = $value->tell;
                $result8[] = $value->phone;
                $result9[] = $value->username;
                $result10[] = $value->evidence;
            }
            echo '<table id="printTable" class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>کد</th>
                        <th>وضعیت</th>
                        <th>نام املاک</th>
                        <th>روز ثبت</th>
                        <th>مدیر</th>
                        <th>شماره ثبت</th>
                        <th>آدرس</th>
                        <th>شماره همراه</th>
                        <th>شماره ثابت</th>
                        <th>نام کاربری</th>
                        <th>مدرک</th>
                    </tr>';
            for ($i = 0; $i < count($result); $i++) {
                echo '<tr class="table_real_estate">
                                <td>' . $result[$i] . '</td>
                                <td>
                                    <div class="btn-group"> 
                                         <select id="status_estate' . $result[$i] . '" class="status_estate" >
                                            <option style="display: none;">' . $result3[$i] . '</option>
                                            <option class="select_real_estate" value="2">تایید شده</option>
                                            <option class="select_real_estate"value="1">در حال بررسی</option>
                                            <option class="select_real_estate"value="3">لغو شده</option>
                                        </select>
                                    </div>
                                </td>
                                <td>' . $result1[$i] . '</td>
                                <td>' . $result2[$i] . '</td>
                                <td>' . $result4[$i] . '</td>
                                <td>' . $result5[$i] . '</td>
                                <td>' . $result6[$i] . '</td>
                                <td>' . $result7[$i] . '</td>
                                <td>' . $result8[$i] . '</td>
                                <td>' . $result9[$i] . '</td>
                                <td><img data-toggle="modal" data-target="#myModalimg' . $result1[$i] . '" style="width: 50px;height: 50px;" src="' . base_url() . 'assets/upload/' . $result10[$i] . '"> 
                                 <div class="modal fade" id="myModalimg' . $result1[$i] . '" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document" style="margin-top: -40px;margin-right: 250px">
                                            <div class="modal-content">
                                                <img style="width: 900px;height: 550px;" src="' . base_url() . 'assets/upload/' . $result10[$i] . '">
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>';
            }
            echo '</table>';
        }
    }

    public function search_real_estate_show_pending() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $q = $_POST["q"];
            $p = $_POST["p"];
            $this->load->model('admin');
            if ($p == 'نام کاربری') {
                $arr_user = $this->admin->real_estate_search_user_show_pending($q);
            } elseif ($p == 'آدرس') {
                $arr_user = $this->admin->real_estate_search_address_show_pending($q);
            } elseif ($p == 'مدیر') {
                $arr_user = $this->admin->real_estate_search_manager_show_pending($q);
            } elseif ($p == 'شماره ثبت') {
                $arr_user = $this->admin->real_estate_search_register_show_pending($q);
            }
            $result = array();
            $result1 = array();
            $result2 = array();
            $result3 = array();
            $result4 = array();
            $result5 = array();
            $result6 = array();
            $result7 = array();
            $result8 = array();
            $result9 = array();
            foreach ($arr_user[0] as $key => $value) {
                $result[] = $value->id1;
                $result1[] = $value->name;
                $result2[] = $value->date_ragister;
                $result3[] = $value->type;
                $result4[] = $value->manager;
                $result5[] = $value->register_num;
                $result6[] = $value->address;
                $result7[] = $value->tell;
                $result8[] = $value->phone;
                $result9[] = $value->username;
            }
            echo '<table id="printTable" class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>کد</th>
                        <th>وضعیت</th>
                        <th>نام املاک</th>
                        <th>روز ثبت</th>
                        <th>مدیر</th>
                        <th>شماره ثبت</th>
                        <th>آدرس</th>
                        <th>شماره همراه</th>
                        <th>شماره ثابت</th>
                        <th>نام کاربری</th>
                        <th>مدرک</th>
                    </tr>';
            for ($i = 0; $i < count($result); $i++) {
                echo '<tr class="table_real_estate">
                                <td>' . $result[$i] . '</td>
                                <td>
                                    <div class="btn-group"> 
                                       <select id="status_estate_pending' . $result[$i] . '" class="status_estate" >
                                            <option style="display: none;">' . $result3[$i] . '</option>
                                            <option class="select_real_estate" value="2">تایید شده</option>
                                            <option class="select_real_estate"value="1">در حال بررسی</option>
                                            <option class="select_real_estate"value="3">لغو شده</option>
                                        </select>
                                    </div>
                                </td>
                                <td>' . $result1[$i] . '</td>
                                <td>' . $result2[$i] . '</td>
                                <td>' . $result4[$i] . '</td>
                                <td>' . $result5[$i] . '</td>
                                <td>' . $result6[$i] . '</td>
                                <td>' . $result7[$i] . '</td>
                                <td>' . $result8[$i] . '</td>
                                <td>' . $result9[$i] . '</td>
                                <td><img data-toggle="modal" data-target="#myModalimg' . $result1[$i] . '" style="width: 50px;height: 50px;" src="' . base_url() . 'assets/upload/' . $result10[$i] . '"> 
                                 <div class="modal fade" id="myModalimg' . $result1[$i] . '" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document" style="margin-top: -40px;margin-right: 250px">
                                            <div class="modal-content">
                                                <img style="width: 900px;height: 550px;" src="' . base_url() . 'assets/upload/' . $result10[$i] . '">
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>';
            }
            echo '</table>';
        }
    }

    public function search_real_estate() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $q = $_POST["q"];
            $p = $_POST["p"];
            $this->load->model('admin');
            if ($p == 'نام کاربری') {
                $arr_user = $this->admin->real_estate_search_user();
            } elseif ($p == 'آدرس') {
                $arr_user = $this->admin->real_estate_search_address();
            } elseif ($p == 'مدیر') {
                $arr_user = $this->admin->real_estate_search_manager();
            } elseif ($p == 'شماره ثبت') {
                $arr_user = $this->admin->real_estate_search_register();
            } elseif ($p == 'وضعیت') {
                $arr_user = $this->admin->real_estate_search_status();
            }
            $result = array();
            foreach ($arr_user as $key => $value) {
                if ($p == 'نام کاربری') {
                    $result[] = $value->username;
                } elseif ($p == 'آدرس') {
                    $result[] = $value->address;
                } elseif ($p == 'مدیر') {
                    $result[] = $value->manager;
                } elseif ($p == 'شماره ثبت') {
                    $result[] = $value->register_num;
                } elseif ($p == 'وضعیت') {
                    $result[] = $value->status;
                }
            }
            $hint = "";
            if (strlen($q) > 0) {
                for ($i = 0; $i < count($result); $i++) {
                    if (strtolower($q) == strtolower(substr($result[$i], 0, strlen($q)))) {
                        if ($hint === "") {
                            $hint = $result[$i];
                        } else {
                            $hint = $hint . " , " . $result[$i];
                        }
                    }
                }
            }
            if ($hint == "") {
                $response = "موردی یافت نشد";
            } else {
                $response = $hint;
            }
            echo $response;
        }
    }

    public function search_real_estate_pending() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $q = $_POST["q"];
            $p = $_POST["p"];
            $this->load->model('admin');
            if ($p == 'نام کاربری') {
                $arr_user = $this->admin->real_estate_search_user_pending();
            } elseif ($p == 'آدرس') {
                $arr_user = $this->admin->real_estate_search_address_pending();
            } elseif ($p == 'مدیر') {
                $arr_user = $this->admin->real_estate_search_manager_pending();
            } elseif ($p == 'شماره ثبت') {
                $arr_user = $this->admin->real_estate_search_register_pending();
            }
            $result = array();
            foreach ($arr_user as $key => $value) {
                if ($p == 'نام کاربری') {
                    $result[] = $value->username;
                } elseif ($p == 'آدرس') {
                    $result[] = $value->address;
                } elseif ($p == 'مدیر') {
                    $result[] = $value->manager;
                } elseif ($p == 'شماره ثبت') {
                    $result[] = $value->register_num;
                }
            }
            $hint = "";
            if (strlen($q) > 0) {
                for ($i = 0; $i < count($result); $i++) {
                    if (strtolower($q) == strtolower(substr($result[$i], 0, strlen($q)))) {
                        if ($hint === "") {
                            $hint = $result[$i];
                        } else {
                            $hint = $hint . " , " . $result[$i];
                        }
                    }
                }
            }
            if ($hint == "") {
                $response = "موردی یافت نشد";
            } else {
                $response = $hint;
            }
            echo $response;
        }
    }

    public function form() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $name = $_POST['name'];
            $date = jdate('Y / F / j _ H:i:s');
            $manager = $_POST['manager'];
            $register = $_POST['register'];
            $tell = $_POST['tell'];
            $phone = $_POST['phone'];
            $address = $_POST['address'];
            $user = $_POST['user'];
            $pass = sha1($_POST['pass']);
            $var = $_FILES['img'];
            $config['upload_path'] = 'assets/upload';
            $config['file_name'] = $_FILES['img']['name'];
            $config['overwrite'] = 'TRUE';
            $config["allowed_types"] = 'jpg|jpeg|png|gif';
            $config["max_size"] = '1024';
            $config["max_width"] = '800';
            $config["max_height"] = '800';
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('img')) {
                $this->data['error'] = $this->upload->display_errors();
                print_r($this->data['error']);
                echo '<a href="' . base_url('site/sign_up') . '">برگشت</a>';
            } else {
                $data = $this->upload->data();
                $this->load->model('admin');
                $this->admin->add_real_estate($name, $date, $manager, $register, $tell, $phone, $address, $user, $pass, $data['file_name']);
                echo 'ثبت نام با موفقیت انجام شد ';
            }
        }
    }

    public function form_user() {
        $name = $_POST['name'];
        $date = jdate('Y / F / j _ H:i:s');
        $manager = $_POST['manager'];
        $register = $_POST['register'];
        $tell = $_POST['tell'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        $user = $_POST['user'];
        $pass = sha1($_POST['pass']);
        $var = $_FILES['img'];
        $config['upload_path'] = 'assets/upload';
        $config['file_name'] = $_FILES['img']['name'];
        $config['overwrite'] = 'TRUE';
        $config["allowed_types"] = 'jpg|jpeg|png|gif';
        $config["max_size"] = '1024';
        $config["max_width"] = '800';
        $config["max_height"] = '800';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('img')) {
            $this->data['error'] = $this->upload->display_errors();
            print_r($this->data['error']);
            echo '<a href="' . base_url('site/sign_up') . '">برگشت</a>';
        } else {
            $data = $this->upload->data();
            $this->load->model('admin');
            $this->admin->add_real_estate_user($name, $date, $manager, $register, $tell, $phone, $address, $user, $pass, $data['file_name']);
            echo 'ثبت نام با موفقیت انجام شد . لطفا تا تایید از طریق مدیریت سایت صبر کنید.برای دیدن جزییات به <a href="' . base_url('site/log_in') . '"> صفحه ورود </a>بروید';
        }
    }

    public function status_satate() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $val = $_POST['q'];
            $id = $_POST['p'];
            $this->load->model('admin');
            $this->admin->update_real_estate($val, $id);
            $arr = $this->admin->update_real_estate_show($id);
            $result = array();
            foreach ($arr as $key => $value) {
                $result[] = $value->type;
            }
            echo $result[0];
        }
    }

    public function real_estate_accept() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['title'] = 'پنل مدیریت | مشاوران املاک';
            $data['page'] = 1;
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $config['base_url'] = site_url() . '/site/real_estate_accept/';
            $config['total_rows'] = $this->db->get_where('estate')->num_rows();
            $config['per_page'] = 20;
            $config['next_link'] = 'بعدی';
            $config['prev_link'] = 'قبلی';
            $config['last_link'] = 'انتها';
            $config['first_link'] = 'ابتدا';
            $this->pagination->initialize($config);
            $data['rows'] = $this->admin->real_estate($config['per_page'], $this->uri->segment(3));
            $data['rows1'] = $this->admin->real_estate1();
            if ($this->input->post('ajax')) {
                $this->load->view('admin/part/show_estate.php', $data);
            } else {
                $this->load->view('admin/admin.php', $data);
            }
        }
    }

    public function printpage() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['rows'] = $this->admin->real_estate1();
            $data['title'] = 'پنل مدیریت | پرینت';
            $this->load->view('admin/part/printpage.php', $data);
        }
    }

    public function real_estate_pending() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['title'] = 'پنل مدیریت | مشاوران املاک در حال بررسی';
            $data['page'] = 2;
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $config['base_url'] = site_url() . '/site/real_estate_pending/';
            $config['total_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $config['per_page'] = 20;
            $config['next_link'] = 'بعدی';
            $config['prev_link'] = 'قبلی';
            $this->pagination->initialize($config);
            $data['rows'] = $this->admin->real_estate_pendding($config['per_page'], $this->uri->segment(3));
            $data['rows1'] = $this->admin->real_estate_pendding1();
            if ($this->input->post('ajax')) {
                $this->load->view('admin/part/show_estate.php', $data);
            } else {
                $this->load->view('admin/admin.php', $data);
            }
        }
    }

    public function pending_estate_count() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $this->load->view('admin/admin.php', $data);
        }
    }

    public function new_msg_count() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $this->load->view('admin/admin.php', $data);
        }
    }
    
    public function new_msg_count2() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $this->load->view('admin/admin.php', $data);
        }
    }

    public function new_msg_count1() {
        $this->load->model('admin');
        $x = $_GET['x'];
        $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $x))->num_rows();
        $this->load->view('admin/admin.php', $data);
    }

    public function estate_sale() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['page'] = 3;
            $data['title'] = 'پنل مدیریت | فروش';
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $config['base_url'] = site_url() . '/site/estate_sale/';
            $config['total_rows'] = $this->db->get_where('home', 'status_home = 1')->num_rows();
            $config['per_page'] = 20;
            $config['next_link'] = 'بعدی';
            $config['prev_link'] = 'قبلی';
            $this->pagination->initialize($config);
            $data['rows'] = $this->admin->home_sale($config['per_page'], $this->uri->segment(3));
            $data['rows1'] = $this->admin->home_sale1();
            if ($this->input->post('ajax')) {
                $this->load->view('admin/part/sale.php', $data);
            } else {
                $this->load->view('admin/admin.php', $data);
            }
        }
    }

    public function search_home_sale() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $q = $_POST["q"];
            $p = $_POST["p"];
            $this->load->model('admin');
            if ($p == 'قیمت') {
                $arr_user = $this->admin->home_sale_search_price_sale();
            } elseif ($p == 'آدرس') {
                $arr_user = $this->admin->home_sale_search_address_home();
            } elseif ($p == 'اتاق خواب') {
                $arr_user = $this->admin->home_sale_search_bedroom();
            } elseif ($p == 'متراژ') {
                $arr_user = $this->admin->home_sale_search_area();
            }
            $result = array();
            foreach ($arr_user as $key => $value) {
                if ($p == 'قیمت') {
                    $result[] = $value->price;
                } elseif ($p == 'آدرس') {
                    $result[] = $value->address_home;
                } elseif ($p == 'اتاق خواب') {
                    $result[] = $value->bedroom;
                } elseif ($p == 'متراژ') {
                    $result[] = $value->area;
                }
            }
            $hint = "";
            if (strlen($q) > 0) {
                for ($i = 0; $i < count($result); $i++) {
                    if (strtolower($q) == strtolower(substr($result[$i], 0, strlen($q)))) {
                        if ($hint === "") {
                            $hint = $result[$i];
                        } else {
                            $hint = $hint . " , " . $result[$i];
                        }
                    }
                }
            }
            if ($hint == "") {
                $response = "موردی یافت نشد";
            } else {
                $response = $hint;
            }
            echo $response;
        }
    }

    public function search_home_sale_show() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $q = $_POST["q"];
            $p = $_POST["p"];
            $this->load->model('admin');
            if ($p == 'قیمت') {
                $arr_user = $this->admin->home_sale_search_price_show($q);
            } elseif ($p == 'آدرس') {
                $arr_user = $this->admin->home_sale_search_address_home_show($q);
            } elseif ($p == 'اتاق خواب') {
                $arr_user = $this->admin->home_sale_search_bedroom_show($q);
            } elseif ($p == 'متراژ') {
                $arr_user = $this->admin->home_sale_search_area_show($q);
            }
            $result = array();
            $result1 = array();
            $result2 = array();
            $result3 = array();
            $result4 = array();
            $result5 = array();
            $result6 = array();
            $result7 = array();
            $result8 = array();
            $result9 = array();
            $result10 = array();
            $result11 = array();
            $result12 = array();
            $result13 = array();
            $result14 = array();
            $result15 = array();
            foreach ($arr_user[0] as $key => $value) {
                $result[] = $value->id_real_estate;
                $result1[] = $value->name;
                $result2[] = $value->register_date;
                $result3[] = $value->type_sale;
                $result4[] = $value->tell_home;
                $result5[] = $value->phone_home;
                $result6[] = $value->address_home;
                $result7[] = $value->price;
                $result8[] = $value->bedroom;
                $result9[] = $value->type1;
                $result10[] = $value->area;
                $result11[] = $value->description;
                $result12[] = $value->type_parking;
                $result13[] = $value->type_storehouse;
                $result14[] = $value->build;
                $result15[] = $value->id_home;
            }
            echo '<table id="printTable" class="table table-hover">
                    <tr class="table_real_estate_title">
                       <th>کد</th>
                        <th>نام املاک</th>
                        <th>تاریخ ثبت</th>
                        <th>وضعیت</th>
                        <th>شماره تماس</th>
                        <th>شماره همراه</th>
                        <th>آدرس</th>
                        <th>قیمت</th>
                        <th>اتاق خواب</th>
                        <th>اسانسور</th>
                        <th>متراژ</th>
                        <th>پارکينگ</th>
                        <th>انبار</th>
                        <th>سال ساخت</th>
                        <th>توضیحات</th>
                        <th>عکس</th>
                    </tr>';
            for ($i = 0; $i < count($result); $i++) {
                echo '<tr class="table_real_estate">
                                <td>' . $result[$i] . '</td>
                                <td>' . $result1[$i] . '</td>
                                <td>' . $result2[$i] . '</td>
                                <td>
                                    <div class="btn-group"> 
                                         <select class="status_estate" >
                                            <option style="display: none;">' . $result3[$i] . '</option>
                                        </select>
                                    </div>
                                </td>
                                <td>' . $result4[$i] . '</td>
                                <td>' . $result5[$i] . '</td>
                                <td>' . $result6[$i] . '</td>
                                <td>' . $result7[$i] . '</td>
                                <td>' . $result8[$i] . '</td>
                                <td>' . $result9[$i] . '</td>
                                <td>' . $result10[$i] . '</td>
                                <td>' . $result12[$i] . '</td>
                                <td>' . $result13[$i] . '</td>
                                <td>' . $result14[$i] . '</td>
                                <td>' . $result11[$i] . '</td>
                                <td style="cursor: pointer"><span data-toggle="modal" data-target="#myModalimg' . $result15[$i] . '">گالري عکس</span>
                                </td>
                            </tr>';
            }
            echo '</table>';
        }
    }

    public function estate_mortgage() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['title'] = 'پنل مدیریت | رهن';
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $data['page'] = 4;
            $config['base_url'] = site_url() . '/site/estate_mortgage/';
            $config['total_rows'] = $this->db->get_where('home', 'status_home = 2')->num_rows();
            $config['per_page'] = 20;
            $config['next_link'] = 'بعدی';
            $config['prev_link'] = 'قبلی';
            $this->pagination->initialize($config);
            $data['rows'] = $this->admin->home_mortgage($config['per_page'], $this->uri->segment(3));
            $data['rows1'] = $this->admin->home_mortgage1();
            if ($this->input->post('ajax')) {
                $this->load->view('admin/part/mortgage.php', $data);
            } else {
                $this->load->view('admin/admin.php', $data);
            }
        }
    }

    public function search_home_mortgage() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $q = $_POST["q"];
            $p = $_POST["p"];
            $this->load->model('admin');
            if ($p == 'قیمت') {
                $arr_user = $this->admin->home_mortgage_search_price_sale();
            } elseif ($p == 'آدرس') {
                $arr_user = $this->admin->home_mortgage_search_address_home();
            } elseif ($p == 'اتاق خواب') {
                $arr_user = $this->admin->home_mortgage_search_bedroom();
            } elseif ($p == 'متراژ') {
                $arr_user = $this->admin->home_mortgage_search_area();
            }
            $result = array();
            foreach ($arr_user as $key => $value) {
                if ($p == 'قیمت') {
                    $result[] = $value->price;
                } elseif ($p == 'آدرس') {
                    $result[] = $value->address_home;
                } elseif ($p == 'اتاق خواب') {
                    $result[] = $value->bedroom;
                } elseif ($p == 'متراژ') {
                    $result[] = $value->area;
                }
            }
            $hint = "";
            if (strlen($q) > 0) {
                for ($i = 0; $i < count($result); $i++) {
                    if (strtolower($q) == strtolower(substr($result[$i], 0, strlen($q)))) {
                        if ($hint === "") {
                            $hint = $result[$i];
                        } else {
                            $hint = $hint . " , " . $result[$i];
                        }
                    }
                }
            }
            if ($hint == "") {
                $response = "موردی یافت نشد";
            } else {
                $response = $hint;
            }
            echo $response;
        }
    }

    public function search_home_mortgage_show() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $q = $_POST["q"];
            $p = $_POST["p"];
            $this->load->model('admin');
            if ($p == 'قیمت') {
                $arr_user = $this->admin->home_mortgage_search_price_show($q);
            } elseif ($p == 'آدرس') {
                $arr_user = $this->admin->home_mortgage_search_address_home_show($q);
            } elseif ($p == 'اتاق خواب') {
                $arr_user = $this->admin->home_mortgage_search_bedroom_show($q);
            } elseif ($p == 'متراژ') {
                $arr_user = $this->admin->home_mortgage_search_area_show($q);
            }
            $result = array();
            $result1 = array();
            $result2 = array();
            $result3 = array();
            $result4 = array();
            $result5 = array();
            $result6 = array();
            $result7 = array();
            $result8 = array();
            $result9 = array();
            $result10 = array();
            $result11 = array();
            $result12 = array();
            $result13 = array();
            $result14 = array();
            $result15 = array();
            foreach ($arr_user[0] as $key => $value) {
                $result[] = $value->id_real_estate;
                $result1[] = $value->name;
                $result2[] = $value->register_date;
                $result3[] = $value->type_mortgage;
                $result4[] = $value->tell_home;
                $result5[] = $value->phone_home;
                $result6[] = $value->address_home;
                $result7[] = $value->price;
                $result8[] = $value->bedroom;
                $result9[] = $value->type1;
                $result10[] = $value->area;
                $result11[] = $value->description;
                $result12[] = $value->type_parking;
                $result13[] = $value->type_storehouse;
                $result14[] = $value->build;
                $result15[] = $value->id_home;
            }
            echo '<table id="printTable" class="table table-hover">
                    <tr class="table_real_estate_title">
                       <th>کد</th>
                        <th>نام املاک</th>
                        <th>تاریخ ثبت</th>
                        <th>وضعیت</th>
                        <th>شماره تماس</th>
                        <th>شماره همراه</th>
                        <th>آدرس</th>
                        <th>قیمت</th>
                        <th>اتاق خواب</th>
                        <th>اسانسور</th>
                        <th>متراژ</th>
                        <th>پارکينگ</th>
                        <th>انبار</th>
                        <th>سال ساخت</th>
                        <th>توضیحات</th>
                        <th>عکس</th>
                    </tr>';
            for ($i = 0; $i < count($result); $i++) {
                echo '<tr class="table_real_estate">
                                <td>' . $result[$i] . '</td>
                                <td>' . $result1[$i] . '</td>
                                <td>' . $result2[$i] . '</td>
                                <td>
                                    <div class="btn-group"> 
                                         <select class="status_estate" >
                                            <option style="display: none;">' . $result3[$i] . '</option>
                                        </select>
                                    </div>
                                </td>
                                <td>' . $result4[$i] . '</td>
                                <td>' . $result5[$i] . '</td>
                                <td>' . $result6[$i] . '</td>
                                <td>' . $result7[$i] . '</td>
                                <td>' . $result8[$i] . '</td>
                                <td>' . $result9[$i] . '</td>
                                <td>' . $result10[$i] . '</td>
                                <td>' . $result12[$i] . '</td>
                                <td>' . $result13[$i] . '</td>
                                <td>' . $result14[$i] . '</td>
                                <td>' . $result11[$i] . '</td>
                                <td style="cursor: pointer"><span data-toggle="modal" data-target="#myModalimg' . $result15[$i] . '">گالري عکس</span>
                                </td>
                            </tr>';
            }
            echo '</table>';
        }
    }

    public function estate_rent() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['title'] = 'پنل مدیریت | اجاره';
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $data['page'] = 5;
            $config['base_url'] = site_url() . '/site/estate_rent/';
            $config['total_rows'] = $this->db->get_where('home', 'status_home = 3')->num_rows();
            $config['per_page'] = 20;
            $config['next_link'] = 'بعدی';
            $config['prev_link'] = 'قبلی';
            $this->pagination->initialize($config);
            $data['rows'] = $this->admin->home_rent($config['per_page'], $this->uri->segment(3));
            $data['rows1'] = $this->admin->home_rent1();
            if ($this->input->post('ajax')) {
                $this->load->view('admin/part/rent.php', $data);
            } else {
                $this->load->view('admin/admin.php', $data);
            }
        }
    }

    public function search_home_rent() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $q = $_POST["q"];
            $p = $_POST["p"];
            $this->load->model('admin');
            if ($p == 'قیمت') {
                $arr_user = $this->admin->home_rent_search_price_sale();
            } elseif ($p == 'آدرس') {
                $arr_user = $this->admin->home_rent_search_address_home();
            } elseif ($p == 'اتاق خواب') {
                $arr_user = $this->admin->home_rent_search_bedroom();
            } elseif ($p == 'متراژ') {
                $arr_user = $this->admin->home_rent_search_area();
            }
            $result = array();
            foreach ($arr_user as $key => $value) {
                if ($p == 'قیمت') {
                    $result[] = $value->price;
                } elseif ($p == 'آدرس') {
                    $result[] = $value->address_home;
                } elseif ($p == 'اتاق خواب') {
                    $result[] = $value->bedroom;
                } elseif ($p == 'متراژ') {
                    $result[] = $value->area;
                }
            }
            $hint = "";
            if (strlen($q) > 0) {
                for ($i = 0; $i < count($result); $i++) {
                    if (strtolower($q) == strtolower(substr($result[$i], 0, strlen($q)))) {
                        if ($hint === "") {
                            $hint = $result[$i];
                        } else {
                            $hint = $hint . " , " . $result[$i];
                        }
                    }
                }
            }
            if ($hint == "") {
                $response = "موردی یافت نشد";
            } else {
                $response = $hint;
            }
            echo $response;
        }
    }

    public function search_home_rent_show() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $q = $_POST["q"];
            $p = $_POST["p"];
            $this->load->model('admin');
            if ($p == 'قیمت') {
                $arr_user = $this->admin->home_rent_search_price_show($q);
            } elseif ($p == 'آدرس') {
                $arr_user = $this->admin->home_rent_search_address_home_show($q);
            } elseif ($p == 'اتاق خواب') {
                $arr_user = $this->admin->home_rent_search_bedroom_show($q);
            } elseif ($p == 'متراژ') {
                $arr_user = $this->admin->home_rent_search_area_show($q);
            }
            $result = array();
            $result1 = array();
            $result2 = array();
            $result3 = array();
            $result4 = array();
            $result5 = array();
            $result6 = array();
            $result7 = array();
            $result8 = array();
            $result9 = array();
            $result10 = array();
            $result11 = array();
            $result12 = array();
            $result13 = array();
            $result14 = array();
            $result15 = array();
            foreach ($arr_user[0] as $key => $value) {
                $result[] = $value->id_real_estate;
                $result1[] = $value->name;
                $result2[] = $value->register_date;
                $result3[] = $value->type_rent;
                $result4[] = $value->tell_home;
                $result5[] = $value->phone_home;
                $result6[] = $value->address_home;
                $result7[] = $value->price;
                $result8[] = $value->bedroom;
                $result9[] = $value->type1;
                $result10[] = $value->area;
                $result11[] = $value->description;
                $result12[] = $value->type_parking;
                $result13[] = $value->type_storehouse;
                $result14[] = $value->build;
                $result15[] = $value->id_home;
            }
            echo '<table id="printTable" class="table table-hover">
                    <tr class="table_real_estate_title">
                       <th>کد</th>
                        <th>نام املاک</th>
                        <th>تاریخ ثبت</th>
                        <th>وضعیت</th>
                        <th>شماره تماس</th>
                        <th>شماره همراه</th>
                        <th>آدرس</th>
                        <th>قیمت</th>
                        <th>اتاق خواب</th>
                        <th>اسانسور</th>
                        <th>متراژ</th>
                        <th>پارکينگ</th>
                        <th>انبار</th>
                        <th>سال ساخت</th>
                        <th>توضیحات</th>
                        <th>عکس</th>
                    </tr>';
            for ($i = 0; $i < count($result); $i++) {
                echo '<tr class="table_real_estate">
                                <td>' . $result[$i] . '</td>
                                <td>' . $result1[$i] . '</td>
                                <td>' . $result2[$i] . '</td>
                                <td>
                                    <div class="btn-group"> 
                                         <select class="status_estate" >
                                            <option style="display: none;">' . $result3[$i] . '</option>
                                        </select>
                                    </div>
                                </td>
                                <td>' . $result4[$i] . '</td>
                                <td>' . $result5[$i] . '</td>
                                <td>' . $result6[$i] . '</td>
                                <td>' . $result7[$i] . '</td>
                                <td>' . $result8[$i] . '</td>
                                <td>' . $result9[$i] . '</td>
                                <td>' . $result10[$i] . '</td>
                                <td>' . $result12[$i] . '</td>
                                <td>' . $result13[$i] . '</td>
                                <td>' . $result14[$i] . '</td>
                                <td>' . $result11[$i] . '</td>
                                <td style="cursor: pointer"><span data-toggle="modal" data-target="#myModalimg' . $result15[$i] . '">گالري عکس</span>
                                </td>
                            </tr>';
            }
            echo '</table>';
        }
    }

    public function printpage_sale() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['rows'] = $this->admin->home_sale_print();
            $data['title'] = 'پنل مدیریت | پرینت';
            $this->load->view('admin/part/print_sale_home.php', $data);
        }
    }

    public function printpage_mortgage() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['rows'] = $this->admin->home_mortgage_print();
            $data['title'] = 'پنل مدیریت | پرینت';
            $this->load->view('admin/part/print_mortgage_home.php', $data);
        }
    }

    public function printpage_rent() {
        $this->load->model('admin');
        $data['rows'] = $this->admin->home_rent_print();
        $data['title'] = 'پنل مدیریت | پرینت';
        $this->load->view('admin/part/print_rent_home.php', $data);
    }

    public function gallery_sale() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $data['title'] = 'پنل مدیریت | گالری فروش';
            $data['page'] = 6;
            $this->load->model('admin');
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $config['base_url'] = site_url() . '/site/gallery_sale/';
            $config['total_rows'] = $this->db->get_where('home', 'status_home = 1')->num_rows();
            $config['per_page'] = 10;
            $config['next_link'] = 'بعدی';
            $config['prev_link'] = 'قبلی';
            $this->pagination->initialize($config);
            $data['rows'] = $this->admin->gallery_sale($config['per_page'], $this->uri->segment(3));
            $data['rows1'] = $this->admin->gallery_sale1();
            if ($this->input->post('ajax')) {
                $this->load->view('admin/part/gallery.php', $data);
            } else {
                $this->load->view('admin/admin.php', $data);
            }
        }
    }

    public function gallery_mortgage() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['title'] = 'پنل مدیریت | گالری رهن';
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $data['page'] = 7;
            $config['base_url'] = site_url() . '/site/gallery_mortgage/';
            $config['total_rows'] = $this->db->get_where('home', 'status_home = 2')->num_rows();
            $config['per_page'] = 10;
            $config['next_link'] = 'بعدی';
            $config['prev_link'] = 'قبلی';
            $this->pagination->initialize($config);
            $data['rows'] = $this->admin->gallery_mortgage($config['per_page'], $this->uri->segment(3));
            $data['rows1'] = $this->admin->gallery_mortgage1();
            if ($this->input->post('ajax')) {
                $this->load->view('admin/part/gallery.php', $data);
            } else {
                $this->load->view('admin/admin.php', $data);
            }
        }
    }

    public function gallery_rent() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['title'] = 'پنل مدیریت | گالری اجاره';
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $data['page'] = 8;
            $config['base_url'] = site_url() . '/site/gallery_rent/';
            $config['total_rows'] = $this->db->get_where('home', 'status_home = 3')->num_rows();
            $config['per_page'] = 10;
            $config['next_link'] = 'بعدی';
            $config['prev_link'] = 'قبلی';
            $this->pagination->initialize($config);
            $data['rows'] = $this->admin->gallery_rent($config['per_page'], $this->uri->segment(3));
            $data['rows1'] = $this->admin->gallery_rent1();
            if ($this->input->post('ajax')) {
                $this->load->view('admin/part/gallery.php', $data);
            } else {
                $this->load->view('admin/admin.php', $data);
            }
        }
    }

    public function message() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $data['title'] = '‌پنل مدیریت | پیغام';
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $this->load->model('admin');
            $data['rows'] = $this->admin->alaki();
            $data['page'] = 10;
            $this->load->view('admin/admin.php', $data);
        }
    }

    public function msg() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $x1 = $_GET['x'];
            $this->load->model('admin');
            $x = $this->admin->send_pm($x1);
            $user = $x[0]->username_estate;
            $data['rows'] = $this->admin->msg($user);
            $this->load->view('admin/part/msg.php', $data);
        }
    }
    
    public function msg2() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $x1 = $_GET['x'];
            $this->load->model('admin');
            $x = $this->admin->send_pm2($x1);
            $user = $x[0]->email;
            $data['rows'] = $this->admin->msg2($user);
            $this->load->view('admin/part/msg.php', $data);
        }
    }

    public function send_message() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $user = $_POST['q1'];
            $message = $_POST['q2'];
            $this->load->model('admin');
            $this->admin->send_message_admin($user, $message);
        }
    }

    public function send_pm() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $id = $_POST['q2'];
            $message = $_POST['q1'];
            $this->load->model('admin');
            $x = $this->admin->send_pm($id);
            $user = $x[0]->username_estate;
            $this->admin->send_message_admin($user, $message);
        }
    }
    
    public function send_pm2() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $id = $_POST['q2'];
            $message = $_POST['q1'];
            $this->load->model('admin');
            $x = $this->admin->send_pm2($id);
            $user = $x[0]->email;
            $this->admin->send_message_admin2($user, $message);
        }
    }

    public function noti_message() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $id = $_POST['q'];
            $this->load->model('admin');
            $x = $this->admin->send_pm($id);
            $user = $x[0]->username_estate;
            $this->admin->noti_message($user);
        }
    }
    
    public function noti_message2() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $id = $_POST['q'];
            $this->load->model('admin');
            $x = $this->admin->send_pm2($id);
            $user = $x[0]->email;
            $this->admin->noti_message2($user);
        }
    }

    public function change_pass() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $data['title'] = 'پنل مدیریت |تغییر پسورد';
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $data['page'] = 9;
            $this->load->view('admin/admin.php', $data);
        }
    }

    function mres($input) {

        if (get_magic_quotes_gpc()) {
            $input = stripslashes($input);
        }
        return  $input;
    }

    public function logout() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->session->unset_userdata('type_admin');
            $this->session->sess_destroy();
            $url = base_url('site/log_in');
            redirect($url);
        }
    }

    public function pass() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $id = $this->session->userdata('id');
            $pass = sha1($_POST['q1']);
            $this->load->model('admin');
            $this->admin->pass($id, $pass);
            echo 'رمز عبور با موفقیت تغییر یافت';
        }
    }

    public function getdata() {
        $this->load->model('admin');
        $data['rows'] = $this->admin->getdata();
        $this->load->view('home/getdata.php', $data);
    }

    public function home_page() {
        $x = $_GET['x'];
        $this->load->model('admin');
        $data['rows'] = $this->admin->home_page($x);
        $this->load->view('home/home_page.php', $data);
    }

    public function search_home_show() {
        $q = $_POST["q"];
        $x = explode(" , ", $q);
        $this->load->model('admin');
        for ($i = 0; $i < count($x); $i++) {
            $arr_user[$i][] = $this->admin->search_home_show($x[$i]);
        }
        for ($j = 0; $j < count($arr_user); $j++) {
            $result = array();
            $result1 = array();
            $result2 = array();
            $result3 = array();
            $result4 = array();
            foreach ($arr_user[$j][0] as $key => $value) {
                $result[] = $value->id_home;
                $result1[] = $value->price;
                $result2[] = $value->area;
                $result3[] = $value->type;
                $result4[] = $value->build;
            }
            for ($i = 0; $i < count($result); $i++) {
                echo '
                    <a class="a_show_home" href="' . base_url('site/home_page') . '?x=' . $result[$i] . '">
                        <div class="show_home">
                            <span class="show_home_span">قیمت : ' . $result1[$i] . '</span>
                            <span class="show_home_span">متراژ : ' . $result2[$i] . '</span><br>
                            <span class="show_home_span">نوع : ' . $result3[$i] . '</span>
                            <span class="show_home_span">سال ساخت : ' . $result4[$i] . '</span>
                        </div>
                      </a>';
            }
        }
    }

    public function search_home() {
        $q = $_POST["q"];
        $this->load->model('admin');
        $arr_user = $this->admin->search_home();
        $result = array();
        foreach ($arr_user as $key => $value) {
            $result[] = $value->address_home;
        }
        $hint = "";
        if (strlen($q) > 0) {
            for ($i = 0; $i < count($result); $i++) {
                if (strtolower($q) == strtolower(substr($result[$i], 0, strlen($q)))) {
                    if ($hint == "") {
                        $hint = $result[$i];
                    } else {
                        $hint = $hint . " , " . $result[$i];
                    }
                }
            }
        }
        if ($hint == "") {
            $response = "موردی یافت نشد";
        } else {
            $response = $hint;
        }
        echo $response;
    }

    public function remove_img() {
        $id = $_POST['q1'];
        $x = $_POST['q2'];
        $this->load->model('admin');
        if ($x == 1) {
            $this->admin->remove_img1($id);
        } elseif ($x == 2) {
            $this->admin->remove_img2($id);
        } elseif ($x == 3) {
            $this->admin->remove_img3($id);
        }
        echo 'حذف با موفقیت انجام شد';
    }

    public function advance_search() {
        $data['title'] = '‌جستجوی پیشرفته';
        $this->load->model('admin');
        $this->load->view('home/advance_search.php', $data);
    }

    public function contact_us() {
        $data['title'] = '‌ارتباط با ما';
        $this->load->model('admin');
        $this->load->view('home/contact_us.php', $data);
    }

    public function contact_message() {
        $name = $_POST['q1'];
        $mail = $_POST['q2'];
        $phone = $_POST['q3'];
        $message = $_POST['q4'];
        $pass = sha1($_POST['q3']);
        $this->load->model('admin');
        $this->admin->contact_message($name, $mail, $phone, $message);
        $this->admin->contact_add($name, $mail, $phone, $pass);
        echo 'پیغام شما ثبت شد.';
    }

    public function contactUs() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $this->load->model('admin');
            $data['title'] = 'پنل مدیریت | ارتباط با ما';
            $data['count_rows'] = $this->db->get_where('estate', 'status = 1')->num_rows();
            $data['new_msg_count'] = $this->db->get_where('message', 'seen_admin = 0')->num_rows();
            $data['new_msg_count2'] = $this->db->get_where('contact_us', 'seen_admin = 0')->num_rows();
            $data['page'] = 11;
            $data['rows'] = $this->admin->contact_message2();
            $this->load->view('admin/admin.php', $data);
        }
    }

    public function senddata_search() {
        $price_down = $_GET['q1'];
        $price_up = $_GET['q2'];
        $bedroom = $_GET['q3'];
        $build = $_GET['q4'];
        $type = $_GET['q6'];
        $parking = $_GET['q7'];
        $elevator = $_GET['q8'];
        $storehouse = $_GET['q9'];
        $this->load->model('admin');
        $data['rows'] = $this->admin->getdata_search($price_down, $price_up, $bedroom, $build, $type, $parking, $elevator, $storehouse);
        $this->load->view('home/getdata.php', $data);
    }

    public function getdata_search() {
        $this->load->view('home/getdata2.php');
    }
    
    public function edit_member() {
        if ($this->session->userdata('type_admin') != 1 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        } else {
            $name = $_POST['q1'];
            $manager = $_POST['q2'];
            $phone = $_POST['q3'];
            $tell = $_POST['q4'];
            $address = $_POST['q5'];
            $id = $_POST['id'];
            $this->load->model('admin');
            $this->admin->edit_member($id,$name, $manager, $tell, $phone, $address);
            echo 'ویرایش با موفقیت انجام شد';
        }
    }

}
