<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class panel extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('session');
        if ($this->session->userdata('type_admin') != 0 | $this->session->userdata('type_admin') == null) {
            redirect('site/log_in', 'refresh');
        }
    }

    public function index() {
        if ($this->session->userdata('type_admin') != 0) {
            redirect('site/log_in', 'refresh');
        } else {

            $id = $this->session->userdata('id');
            $this->load->model('admin');
            $data['rows'] = $this->admin->real_estate_admin($id);
            $this->load->model('estate');
            $x = $this->estate->search_user($id);
            if ($x != null) {
                $user = $x[0]->username;
                $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
            } else {
                $data['new_msg_count'] = 0;
            }
            $data['title'] = 'پنل مشاورین املاک';
            $data['page'] = 0;
            $this->load->view('estate/estate.php', $data);
        }
    }

    public function home_sale() {
        $id = $this->session->userdata('id');
        $this->load->model('admin');
        $data['rows'] = $this->admin->real_estate_admin($id);
        $this->load->model('estate');
        $x = $this->estate->search_user($id);
        if ($x != null) {
            $user = $x[0]->username;
            $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
        } else {
            $data['new_msg_count'] = 0;
        }
        $data['title'] = 'افزودن |فروش';
        $data['page'] = 1;
        $this->load->view('estate/estate.php', $data);
    }

    public function home_mortgage() {
        $id = $this->session->userdata('id');
        $this->load->model('admin');
        $data['rows'] = $this->admin->real_estate_admin($id);
        $this->load->model('estate');
        $x = $this->estate->search_user($id);
        if ($x != null) {
            $user = $x[0]->username;
            $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
        } else {
            $data['new_msg_count'] = 0;
        }
        $data['title'] = 'افزودن | رهن';
        $data['page'] = 2;
        $this->load->view('estate/estate.php', $data);
    }

    public function home_rent() {
        $id = $this->session->userdata('id');
        $this->load->model('admin');
        $data['rows'] = $this->admin->real_estate_admin($id);
        $this->load->model('estate');
        $x = $this->estate->search_user($id);
        if ($x != null) {
            $user = $x[0]->username;
            $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
        } else {
            $data['new_msg_count'] = 0;
        }
        $data['title'] = 'افزودن| اجاره';
        $data['page'] = 3;
        $this->load->view('estate/estate.php', $data);
    }

    public function home_sale_show() {
        $id = $this->session->userdata('id');
        $this->load->model('admin');
        $data['rows'] = $this->admin->real_estate_admin($id);
        $this->load->model('estate');
        $x = $this->estate->search_user($id);
        if ($x != null) {
            $user = $x[0]->username;
            $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
        } else {
            $data['new_msg_count'] = 0;
        }
        $data['title'] = 'مشاهده| فروش';
        $data['page'] = 7;
        $config['base_url'] = site_url() . '/panel/home_sale_show/';
        $config['total_rows'] = $this->db->get_where('home', array('status_home = 1', 'id_real_estate = ' . $id))->num_rows();
        $config['per_page'] = 20;
        $config['next_link'] = 'بعدی';
        $config['prev_link'] = 'قبلی';
        $this->pagination->initialize($config);
        $data['rows2'] = $this->estate->home_sale_show($config['per_page'], $this->uri->segment(3), $id);
        $data['rows1'] = $this->estate->home_sale_show1($id);
        if ($this->input->post('ajax')) {
            $this->load->view('estate/part/sale.php', $data);
        } else {
            $this->load->view('estate/estate.php', $data);
        }
    }

    public function home_mortgage_show() {
        $id = $this->session->userdata('id');
        $this->load->model('admin');
        $data['rows'] = $this->admin->real_estate_admin($id);
        $this->load->model('estate');
        $x = $this->estate->search_user($id);
        if ($x != null) {
            $user = $x[0]->username;
            $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
        } else {
            $data['new_msg_count'] = 0;
        }
        $data['title'] = 'مشاهده| رهن';
        $data['page'] = 8;
        $config['base_url'] = site_url() . '/panel/home_mortgage_show/';
        $config['total_rows'] = $this->db->get_where('home', array('status_home = 1', 'id_real_estate = ' . $id))->num_rows();
        $config['per_page'] = 20;
        $config['next_link'] = 'بعدی';
        $config['prev_link'] = 'قبلی';
        $this->pagination->initialize($config);
        $data['rows2'] = $this->estate->home_mortgage_show($config['per_page'], $this->uri->segment(3), $id);
        $data['rows1'] = $this->estate->home_mortgage_show1($id);
        if ($this->input->post('ajax')) {
            $this->load->view('estate/part/sale.php', $data);
        } else {
            $this->load->view('estate/estate.php', $data);
        }
    }

    public function home_rent_show() {
        $id = $this->session->userdata('id');
        $this->load->model('admin');
        $data['rows'] = $this->admin->real_estate_admin($id);
        $this->load->model('estate');
        $x = $this->estate->search_user($id);
        if ($x != null) {
            $user = $x[0]->username;
            $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
        } else {
            $data['new_msg_count'] = 0;
        }
        $data['title'] = 'مشاهده| اجاره';
        $data['page'] = 9;
        $config['base_url'] = site_url() . '/panel/home_rent_show/';
        $config['total_rows'] = $this->db->get_where('home', array('status_home = 1', 'id_real_estate = ' . $id))->num_rows();
        $config['per_page'] = 20;
        $config['next_link'] = 'بعدی';
        $config['prev_link'] = 'قبلی';
        $this->pagination->initialize($config);
        $data['rows2'] = $this->estate->home_rent_show($config['per_page'], $this->uri->segment(3), $id);
        $data['rows1'] = $this->estate->home_rent_show1($id);
        if ($this->input->post('ajax')) {
            $this->load->view('estate/part/sale.php', $data);
        } else {
            $this->load->view('estate/estate.php', $data);
        }
    }

    public function about() {
        $id = $this->session->userdata('id');
        $this->load->model('admin');
        $data['rows'] = $this->admin->real_estate_admin($id);
        $this->load->model('estate');
        $x = $this->estate->search_user($id);
        if ($x != null) {
            $user = $x[0]->username;
            $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
        } else {
            $data['new_msg_count'] = 0;
        }
        $data['title'] = 'درباره املاک';
        $data['page'] = 4;
        $this->load->view('estate/estate.php', $data);
    }

    public function message_admin() {
        $id = $this->session->userdata('id');
        $this->load->model('admin');
        $data['rows'] = $this->admin->real_estate_admin($id);
        $this->load->model('estate');
        $x1 = $this->estate->search_user($id);
        if ($x1 != null) {
            $user = $x1[0]->username;
            $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
        } else {
            $data['new_msg_count'] = 0;
        }
        $this->load->model('estate');
        $x = $this->estate->search_user($id);
        if ($x != null) {
            $user = $x[0]->username;
            $data['rows_message'] = $this->estate->msg($user);
        } else {
            $data['rows_message'] = null;
        }
        $data['title'] = '‌پیغام';
        $data['page'] = 5;
        $this->load->view('estate/estate.php', $data);
    }

    public function msg() {
        $x1 = $this->session->userdata('id');
        $this->load->model('estate');
        $x = $this->estate->search_user($x1);
        if ($x != null) {
            $user = $x[0]->username;
            $data['rows'] = $this->estate->msg($user);
        } else {
            $data['rows'] = null;
        }
        $this->load->view('estate/part/msg.php', $data);
    }

    public function noti_message() {
        $x1 = $this->session->userdata('id');
        $this->load->model('estate');
        $x = $this->estate->search_user($x1);
        $user = $x[0]->username;
        $this->estate->noti_message($user);
    }

    public function new_msg_count() {
        $data['new_msg_count'] = $this->db->get_where('message', 'seen_user = 0')->num_rows();
        $this->load->view('admin/admin.php', $data);
    }

    public function send_pm() {
        $x1 = $this->session->userdata('id');
        $message = $_POST['q1'];
        $this->load->model('estate');
        $x = $this->estate->search_user($x1);
        $user = $x[0]->username;
        $this->estate->send_message_admin($user, $message);
    }

    public function change_pass() {
        $id = $this->session->userdata('id');
        $this->load->model('admin');
        $data['rows'] = $this->admin->real_estate_admin($id);
        $this->load->model('estate');
        $x = $this->estate->search_user($id);
        if ($x != null) {
            $user = $x[0]->username;
            $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
        } else {
            $data['new_msg_count'] = 0;
        }
        $data['title'] = 'تغییر پسورد';
        $data['page'] = 6;
        $this->load->view('estate/estate.php', $data);
    }

    public function pass() {
        $id = $this->session->userdata('id');
        $pass = sha1($_POST['q1']);
        $this->load->model('estate');
        $this->estate->pass($id, $pass);
        echo 'رمز عبور با موفقیت تغییر یافت';
    }

    public function edit_home() {
        $id = $_POST["id"];
        $q1 = $_POST["q1"];
        $q2 = $_POST["q2"];
        $q3 = $_POST["q3"];
        $q4 = $_POST["q4"];
        $q5 = $_POST["q5"];
        $q6 = $_POST["q6"];
        $q7 = $_POST["q7"];
        $q8 = $_POST["q8"];
        $q9 = $_POST["q9"];
        $q10 = $_POST["q10"];
        $q11 = $_POST["q11"];
        $this->load->model('estate');
        $this->estate->edit_home($id, $q1, $q2, $q3, $q4, $q5, $q6, $q7, $q8, $q9, $q10, $q11);
        echo 'تغییرات با موفقیت اعمال گردید.';
    }

    public function upload1() {
        $id = $_POST['id'];
        $var = $_FILES['img1'];
        $config['upload_path'] = 'assets/upload';
        $config['file_name'] = $_FILES['img1']['name'];
        $config['overwrite'] = 'TRUE';
        $config["allowed_types"] = 'jpg|jpeg|png|gif';
        $config["max_size"] = '1024';
        $config["max_width"] = '800';
        $config["max_height"] = '800';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('img1')) {
            $this->data['error'] = $this->upload->display_errors();
            print_r($this->data['error']);
            echo '<a href="' . base_url('panel') . '">برگشت</a>';
        } else {
            $data = $this->upload->data();
            $this->load->model('estate');
            $this->estate->upload1($data['file_name'], $id);
            $x = $this->estate->uploadshow1($id);
            foreach ($x as $key => $value) {
                $result[] = $value->img1;
            }
            print_r($result[0]);
        }
    }

    public function upload2() {
        $id = $_POST['id'];
        $var = $_FILES['img2'];
        $config['upload_path'] = 'assets/upload';
        $config['file_name'] = $_FILES['img2']['name'];
        $config['overwrite'] = 'TRUE';
        $config["allowed_types"] = 'jpg|jpeg|png|gif';
        $config["max_size"] = '1024';
        $config["max_width"] = '800';
        $config["max_height"] = '800';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('img2')) {
            $this->data['error'] = $this->upload->display_errors();
            print_r($this->data['error']);
            echo '<a href="' . base_url('panel') . '">برگشت</a>';
        } else {
            $data = $this->upload->data();
            $this->load->model('estate');
            $this->estate->upload2($data['file_name'], $id);
            $x = $this->estate->uploadshow1($id);
            foreach ($x as $key => $value) {
                $result[] = $value->img2;
            }
            print_r($result[0]);
        }
    }

    public function upload3() {
        $id = $_POST['id'];
        $var = $_FILES['img3'];
        $config['upload_path'] = 'assets/upload';
        $config['file_name'] = $_FILES['img3']['name'];
        $config['overwrite'] = 'TRUE';
        $config["allowed_types"] = 'jpg|jpeg|png|gif';
        $config["max_size"] = '1024';
        $config["max_width"] = '800';
        $config["max_height"] = '800';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('img3')) {
            $this->data['error'] = $this->upload->display_errors();
            print_r($this->data['error']);
            echo '<a href="' . base_url('panel') . '">برگشت</a>';
        } else {
            $data = $this->upload->data();
            $this->load->model('estate');
            $this->estate->upload3($data['file_name'], $id);
            $x = $this->estate->uploadshow1($id);
            foreach ($x as $key => $value) {
                $result[] = $value->img3;
            }
            print_r($result[0]);
        }
    }

    public function remove() {
        $id = $_POST['q1'];
        $this->load->model('estate');
        $this->estate->remove($id);
        echo 'حذف با موفقیت انجام شد';
    }

    public function search_home_sale() {
        $id = $this->session->userdata('id');
        $q = $_POST["q"];
        $p = $_POST["p"];
        $this->load->model('estate');
        if ($p == 'قيمت') {
            $arr_user = $this->estate->home_sale_search_price_sale($id);
        } elseif ($p == 'آدرس') {
            $arr_user = $this->estate->home_sale_search_address_home($id);
        } elseif ($p == 'اتاق خواب') {
            $arr_user = $this->estate->home_sale_search_bedroom($id);
        } elseif ($p == 'متراژ') {
            $arr_user = $this->estate->home_sale_search_area($id);
        }
        $result = array();
        foreach ($arr_user as $key => $value) {
            if ($p == 'قيمت') {
                $result[] = $value->price;
            } elseif ($p == 'آدرس') {
                $result[] = $value->address_home;
            } elseif ($p == 'اتاق خواب') {
                $result[] = $value->bedroom;
            } elseif ($p == 'متراژ') {
                $result[] = $value->area;
            }
        }
        $hint = "";
        if (strlen($q) > 0) {
            for ($i = 0; $i < count($result); $i++) {
                if (strtolower($q) == strtolower(substr($result[$i], 0, strlen($q)))) {
                    if ($hint === "") {
                        $hint = $result[$i];
                    } else {
                        $hint = $hint . " , " . $result[$i];
                    }
                }
            }
        }
        if ($hint == "") {
            $response = "موردی یافت نشد";
        } else {
            $response = $hint;
        }
        echo $response;
    }

    public function search_home_sale_show() {
        $q = $_POST["q"];
        $p = $_POST["p"];
        $id = $this->session->userdata('id');
        $this->load->model('estate');
        if ($p == 'قيمت') {
            $arr_user = $this->estate->home_sale_search_price_show($q, $id);
        } elseif ($p == 'آدرس') {
            $arr_user = $this->estate->home_sale_search_address_home_show($q, $id);
        } elseif ($p == 'اتاق خواب') {
            $arr_user = $this->estate->home_sale_search_bedroom_show($q, $id);
        } elseif ($p == 'متراژ') {
            $arr_user = $this->estate->home_sale_search_area_show($q, $id);
        }
        $result = array();
        $result1 = array();
        $result2 = array();
        $result3 = array();
        $result4 = array();
        $result5 = array();
        $result6 = array();
        $result7 = array();
        $result8 = array();
        $result9 = array();
        $result10 = array();
        $result11 = array();
        $result12 = array();
        $result13 = array();
        $result14 = array();
        foreach ($arr_user[0] as $key => $value) {
            $result[] = $value->id_home;
            $result2[] = $value->register_date;
            $result3[] = $value->type_rent;
            $result4[] = $value->tell_home;
            $result5[] = $value->phone_home;
            $result6[] = $value->address_home;
            $result7[] = $value->price;
            $result8[] = $value->bedroom;
            $result9[] = $value->type1;
            $result10[] = $value->area;
            $result11[] = $value->description;
            $result12[] = $value->type_parking;
            $result13[] = $value->type_storehouse;
            $result14[] = $value->build;
        }
        echo '<table id="printTable" class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>تاریخ ثبت</th>
                        <th>وضعیت</th>
                        <th>شماره تماس</th>
                        <th>شماره همراه</th>
                        <th>آدرس</th>
                        <th>قیمت</th>
                        <th>اتاق خواب</th>
                        <th>اسانسور</th>
                        <th>متراژ</th>
                        <th>پارکينگ</th>
                        <th>انبار</th>
                        <th>سال ساخت</th>
                        <th>توضیحات</th>
                        <th>عکس</th>
                        <th>تنظيمات</th>
                    </tr>';
        for ($i = 0; $i < count($result); $i++) {
            echo '<tr class="table_real_estate">
                                <td>' . $result2[$i] . '</td>
                                <td>
                                    <div class="btn-group"> 
                                         <select class="status_estate" >
                                            <option style="display: none;">' . $result3[$i] . '</option>
                                        </select>
                                    </div>
                                </td>
                                <td>' . $result4[$i] . '</td>
                                <td>' . $result5[$i] . '</td>
                                <td>' . $result6[$i] . '</td>
                                <td>' . $result7[$i] . '</td>
                                <td>' . $result8[$i] . '</td>
                                <td>' . $result9[$i] . '</td>
                                <td>' . $result10[$i] . '</td>
                                <td>' . $result12[$i] . '</td>
                                <td>' . $result13[$i] . '</td>
                                <td>' . $result14[$i] . '</td>
                                <td>' . $result11[$i] . '</td>
                                <td style="cursor: pointer"><span data-toggle="modal" data-target="#myModalimg' . $result[$i] . '">گالري عکس</span>
                                </td>
                                <td>
                                    <i class="fa fa-pencil-square-o edit" data-toggle="modal" data-target="#myModaledit' . $result[$i] . '"></i>
                                    <i class="fa fa-times remove" data-toggle="modal" data-target="#myModalremove' . $result[$i] . '"></i>
                                </td>
                            </tr>';
        }
        echo '</table>';
    }

    public function status_home() {
        $val = $_POST['q'];
        $id = $_POST['p'];
        $this->load->model('estate');
        $this->estate->update_home($val, $id);
        $arr = $this->estate->update_home_show($id);
        $result = array();
        foreach ($arr as $key => $value) {
            $result[] = $value->type_sale;
        }
        echo $result[0];
    }

    //////// rent ///////
    public function search_home_rent() {
        $id = $this->session->userdata('id');
        $q = $_POST["q"];
        $p = $_POST["p"];
        $this->load->model('estate');
        if ($p == 'قيمت') {
            $arr_user = $this->estate->home_rent_search_price_sale($id);
        } elseif ($p == 'آدرس') {
            $arr_user = $this->estate->home_rent_search_address_home($id);
        } elseif ($p == 'اتاق خواب') {
            $arr_user = $this->estate->home_rent_search_bedroom($id);
        } elseif ($p == 'متراژ') {
            $arr_user = $this->estate->home_rent_search_area($id);
        }
        $result = array();
        foreach ($arr_user as $key => $value) {
            if ($p == 'قيمت') {
                $result[] = $value->price;
            } elseif ($p == 'آدرس') {
                $result[] = $value->address_home;
            } elseif ($p == 'اتاق خواب') {
                $result[] = $value->bedroom;
            } elseif ($p == 'متراژ') {
                $result[] = $value->area;
            }
        }
        $hint = "";
        if (strlen($q) > 0) {
            for ($i = 0; $i < count($result); $i++) {
                if (strtolower($q) == strtolower(substr($result[$i], 0, strlen($q)))) {
                    if ($hint === "") {
                        $hint = $result[$i];
                    } else {
                        $hint = $hint . " , " . $result[$i];
                    }
                }
            }
        }
        if ($hint == "") {
            $response = "موردی یافت نشد";
        } else {
            $response = $hint;
        }
        echo $response;
    }

    public function search_home_rent_show() {
        $q = $_POST["q"];
        $p = $_POST["p"];
        $id = $this->session->userdata('id');
        $this->load->model('estate');
        if ($p == 'قيمت') {
            $arr_user = $this->estate->home_rent_search_price_show($q, $id);
        } elseif ($p == 'آدرس') {
            $arr_user = $this->estate->home_rent_search_address_home_show($q, $id);
        } elseif ($p == 'اتاق خواب') {
            $arr_user = $this->estate->home_rent_search_bedroom_show($q, $id);
        } elseif ($p == 'متراژ') {
            $arr_user = $this->estate->home_rent_search_area_show($q, $id);
        }
        $result = array();
        $result1 = array();
        $result2 = array();
        $result3 = array();
        $result4 = array();
        $result5 = array();
        $result6 = array();
        $result7 = array();
        $result8 = array();
        $result9 = array();
        $result10 = array();
        $result11 = array();
        $result12 = array();
        $result13 = array();
        $result14 = array();
        foreach ($arr_user[0] as $key => $value) {
            $result[] = $value->id_home;
            $result2[] = $value->register_date;
            $result3[] = $value->type_rent;
            $result4[] = $value->tell_home;
            $result5[] = $value->phone_home;
            $result6[] = $value->address_home;
            $result7[] = $value->price;
            $result8[] = $value->bedroom;
            $result9[] = $value->type1;
            $result10[] = $value->area;
            $result11[] = $value->description;
            $result12[] = $value->type_parking;
            $result13[] = $value->type_storehouse;
            $result14[] = $value->build;
        }
        echo '<table id="printTable" class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>تاریخ ثبت</th>
                        <th>وضعیت</th>
                        <th>شماره تماس</th>
                        <th>شماره همراه</th>
                        <th>آدرس</th>
                        <th>قیمت</th>
                        <th>اتاق خواب</th>
                        <th>اسانسور</th>
                        <th>متراژ</th>
                        <th>پارکينگ</th>
                        <th>انبار</th>
                        <th>سال ساخت</th>
                        <th>توضیحات</th>
                        <th>عکس</th>
                        <th>تنظيمات</th>
                    </tr>';
        for ($i = 0; $i < count($result); $i++) {
            echo '<tr class="table_real_estate">
                                <td>' . $result2[$i] . '</td>
                                <td>
                                    <div class="btn-group"> 
                                         <select class="status_estate" >
                                            <option style="display: none;">' . $result3[$i] . '</option>
                                        </select>
                                    </div>
                                </td>
                                <td>' . $result4[$i] . '</td>
                                <td>' . $result5[$i] . '</td>
                                <td>' . $result6[$i] . '</td>
                                <td>' . $result7[$i] . '</td>
                                <td>' . $result8[$i] . '</td>
                                <td>' . $result9[$i] . '</td>
                                <td>' . $result10[$i] . '</td>
                                <td>' . $result12[$i] . '</td>
                                <td>' . $result13[$i] . '</td>
                                <td>' . $result14[$i] . '</td>
                                <td>' . $result11[$i] . '</td>
                                <td style="cursor: pointer"><span data-toggle="modal" data-target="#myModalimg' . $result[$i] . '">گالري عکس</span>
                                </td>
                                <td>
                                    <i class="fa fa-pencil-square-o edit" data-toggle="modal" data-target="#myModaledit' . $result[$i] . '"></i>
                                    <i class="fa fa-times remove" data-toggle="modal" data-target="#myModalremove' . $result[$i] . '"></i>
                                </td>
                            </tr>';
        }
        echo '</table>';
    }

    //////mortgage/////
    public function search_home_mortgage() {
        $id = $this->session->userdata('id');
        $q = $_POST["q"];
        $p = $_POST["p"];
        $this->load->model('estate');
        if ($p == 'قيمت') {
            $arr_user = $this->estate->home_mortgage_search_price_sale($id);
        } elseif ($p == 'آدرس') {
            $arr_user = $this->estate->home_mortgage_search_address_home($id);
        } elseif ($p == 'اتاق خواب') {
            $arr_user = $this->estate->home_mortgage_search_bedroom($id);
        } elseif ($p == 'متراژ') {
            $arr_user = $this->estate->home_mortgage_search_area($id);
        }
        $result = array();
        foreach ($arr_user as $key => $value) {
            if ($p == 'قيمت') {
                $result[] = $value->price;
            } elseif ($p == 'آدرس') {
                $result[] = $value->address_home;
            } elseif ($p == 'اتاق خواب') {
                $result[] = $value->bedroom;
            } elseif ($p == 'متراژ') {
                $result[] = $value->area;
            }
        }
        $hint = "";
        if (strlen($q) > 0) {
            for ($i = 0; $i < count($result); $i++) {
                if (strtolower($q) == strtolower(substr($result[$i], 0, strlen($q)))) {
                    if ($hint === "") {
                        $hint = $result[$i];
                    } else {
                        $hint = $hint . " , " . $result[$i];
                    }
                }
            }
        }
        if ($hint == "") {
            $response = "موردی یافت نشد";
        } else {
            $response = $hint;
        }
        echo $response;
    }

    public function search_home_mortgage_show() {
        $q = $_POST["q"];
        $p = $_POST["p"];
        $id = $this->session->userdata('id');
        $this->load->model('estate');
        if ($p == 'قيمت') {
            $arr_user = $this->estate->home_mortgage_search_price_show($q, $id);
        } elseif ($p == 'آدرس') {
            $arr_user = $this->estate->home_mortgage_search_address_home_show($q, $id);
        } elseif ($p == 'اتاق خواب') {
            $arr_user = $this->estate->home_mortgage_search_bedroom_show($q, $id);
        } elseif ($p == 'متراژ') {
            $arr_user = $this->estate->home_mortgage_search_area_show($q, $id);
        }
        $result = array();
        $result1 = array();
        $result2 = array();
        $result3 = array();
        $result4 = array();
        $result5 = array();
        $result6 = array();
        $result7 = array();
        $result8 = array();
        $result9 = array();
        $result10 = array();
        $result11 = array();
        $result12 = array();
        $result13 = array();
        $result14 = array();
        foreach ($arr_user[0] as $key => $value) {
            $result[] = $value->id_home;
            $result2[] = $value->register_date;
            $result3[] = $value->type_mortgage;
            $result4[] = $value->tell_home;
            $result5[] = $value->phone_home;
            $result6[] = $value->address_home;
            $result7[] = $value->price;
            $result8[] = $value->bedroom;
            $result9[] = $value->type1;
            $result10[] = $value->area;
            $result11[] = $value->description;
            $result12[] = $value->type_parking;
            $result13[] = $value->type_storehouse;
            $result14[] = $value->build;
        }
        echo '<table id="printTable" class="table table-hover">
                    <tr class="table_real_estate_title">
                        <th>تاریخ ثبت</th>
                        <th>وضعیت</th>
                        <th>شماره تماس</th>
                        <th>شماره همراه</th>
                        <th>آدرس</th>
                        <th>قیمت</th>
                        <th>اتاق خواب</th>
                        <th>اسانسور</th>
                        <th>متراژ</th>
                        <th>پارکينگ</th>
                        <th>انبار</th>
                        <th>سال ساخت</th>
                        <th>توضیحات</th>
                        <th>عکس</th>
                        <th>تنظيمات</th>
                    </tr>';
        for ($i = 0; $i < count($result); $i++) {
            echo '<tr class="table_real_estate">
                                <td>' . $result2[$i] . '</td>
                                <td>
                                    <div class="btn-group"> 
                                         <select class="status_estate" >
                                            <option style="display: none;">' . $result3[$i] . '</option>
                                        </select>
                                    </div>
                                </td>
                                <td>' . $result4[$i] . '</td>
                                <td>' . $result5[$i] . '</td>
                                <td>' . $result6[$i] . '</td>
                                <td>' . $result7[$i] . '</td>
                                <td>' . $result8[$i] . '</td>
                                <td>' . $result9[$i] . '</td>
                                <td>' . $result10[$i] . '</td>
                                <td>' . $result12[$i] . '</td>
                                <td>' . $result13[$i] . '</td>
                                <td>' . $result14[$i] . '</td>
                                <td>' . $result11[$i] . '</td>
                                <td style="cursor: pointer"><span data-toggle="modal" data-target="#myModalimg' . $result[$i] . '">گالري عکس</span>
                                </td>
                                <td>
                                    <i class="fa fa-pencil-square-o edit" data-toggle="modal" data-target="#myModaledit' . $result[$i] . '"></i>
                                    <i class="fa fa-times remove" data-toggle="modal" data-target="#myModalremove' . $result[$i] . '"></i>
                                </td>
                            </tr>';
        }
        echo '</table>';
    }

    public function printpage_sale() {
        $id = $this->session->userdata('id');
        $this->load->model('estate');
        $data['rows'] = $this->estate->home_sale_print($id);
        $data['title'] = 'پنل | پرینت';
        $this->load->view('estate/part/print_sale_home.php', $data);
    }

    public function printpage_mortgage() {
        $id = $this->session->userdata('id');
        $this->load->model('estate');
        $data['rows'] = $this->estate->home_mortgage_print($id);
        $data['title'] = 'پنل | پرینت';
        $this->load->view('estate/part/print_mortgage_home.php', $data);
    }

    public function printpage_rent() {
        $id = $this->session->userdata('id');
        $this->load->model('estate');
        $data['rows'] = $this->estate->home_rent_print($id);
        $data['title'] = 'پنل | پرینت';
        $this->load->view('estate/part/print_rent_home.php', $data);
    }

    public function add_home() {
        $id = $this->session->userdata('id');
        $lon = $_POST['lon'];
        $lat = $_POST['lat'];
        $price = $_POST['price'];
        $area = $_POST['area'];
        $elevator = $_POST['elevator'];
        $bedroom = $_POST['bedroom'];
        $tell = $_POST['tell'];
        $phone = $_POST['phone'];
        $description = $_POST['description'];
        $address = $_POST['address1'];
        $storehouse = $_POST['storehouse'];
        $parking = $_POST['parking'];
        $build = $_POST['build'];
//        if($_FILES['img11']){
        $this->load->library('upload');
        $number_of_files_uploaded = count($_FILES['img11']['name']);
        for ($i = 0; $i < $number_of_files_uploaded; $i++) :
            if ($_FILES['img11']['size'][$i] != 0) {
                $_FILES['userfile']['name'] = $_FILES['img11']['name'][$i];
                $_FILES['userfile']['type'] = $_FILES['img11']['type'][$i];
                $_FILES['userfile']['tmp_name'] = $_FILES['img11']['tmp_name'][$i];
                $_FILES['userfile']['error'] = $_FILES['img11']['error'][$i];
                $_FILES['userfile']['size'] = $_FILES['img11']['size'][$i];
                $config = array(
                    'allowed_types' => 'jpg|jpeg|png|gif',
                    'max_size' => 3000,
                    'overwrite' => FALSE,
                    'upload_path' => 'assets/upload'
                );
                $this->upload->initialize($config);
                if (!$this->upload->do_upload()) :
                    $error = array('error' => $this->upload->display_errors());
                    $this->load->view('upload_form', $error);
                else :
                    $final_files_data[] = $this->upload->data();
                endif;
            }else {
                $final_files_data[$i]['file_name'] = null;
            }
        endfor;
        $this->load->model('estate');
        $this->estate->add_home($lon, $lat, $price, $area, $elevator, $bedroom, $tell, $phone, $description, $address, $storehouse, $parking, $build, $id, $final_files_data[0]['file_name'], $final_files_data[1]['file_name'], $final_files_data[2]['file_name']);
    }

    public function add_home_rent() {
        $id = $this->session->userdata('id');
        $lon = $_POST['lon'];
        $lat = $_POST['lat'];
        $price = $_POST['price'];
        $area = $_POST['area'];
        $elevator = $_POST['elevator'];
        $bedroom = $_POST['bedroom'];
        $tell = $_POST['tell'];
        $phone = $_POST['phone'];
        $description = $_POST['description'];
        $address = $_POST['address'];
        $storehouse = $_POST['storehouse'];
        $parking = $_POST['parking'];
        $build = $_POST['build'];
        $this->load->library('upload');
        $number_of_files_uploaded = count($_FILES['img11']['name']);
        for ($i = 0; $i < $number_of_files_uploaded; $i++) :
            if ($_FILES['img11']['size'][$i] != 0) {
                $_FILES['userfile']['name'] = $_FILES['img11']['name'][$i];
                $_FILES['userfile']['type'] = $_FILES['img11']['type'][$i];
                $_FILES['userfile']['tmp_name'] = $_FILES['img11']['tmp_name'][$i];
                $_FILES['userfile']['error'] = $_FILES['img11']['error'][$i];
                $_FILES['userfile']['size'] = $_FILES['img11']['size'][$i];
                $config = array(
                    'allowed_types' => 'jpg|jpeg|png|gif',
                    'max_size' => 3000,
                    'overwrite' => FALSE,
                    'upload_path' => 'assets/upload'
                );
                $this->upload->initialize($config);
                if (!$this->upload->do_upload()) :
                    $error = array('error' => $this->upload->display_errors());
                    $this->load->view('upload_form', $error);
                else :
                    $final_files_data[] = $this->upload->data();
                endif;
            }else {
                $final_files_data[$i]['file_name'] = null;
            }
        endfor;
        $this->load->model('estate');
        $this->estate->add_home_rent($lon, $lat, $price, $area, $elevator, $bedroom, $tell, $phone, $description, $address, $storehouse, $parking, $build, $id, $final_files_data[0]['file_name'], $final_files_data[1]['file_name'], $final_files_data[2]['file_name']);
    }

    public function add_home_mortgage() {
        $id = $this->session->userdata('id');
        $lon = $_POST['lon'];
        $lat = $_POST['lat'];
        $price = $_POST['price'];
        $area = $_POST['area'];
        $elevator = $_POST['elevator'];
        $bedroom = $_POST['bedroom'];
        $tell = $_POST['tell'];
        $phone = $_POST['phone'];
        $description = $_POST['description'];
        $address = $_POST['address'];
        $storehouse = $_POST['storehouse'];
        $parking = $_POST['parking'];
        $build = $_POST['build'];
        $this->load->library('upload');
        $number_of_files_uploaded = count($_FILES['img11']['name']);
        for ($i = 0; $i < $number_of_files_uploaded; $i++) :
            if ($_FILES['img11']['size'][$i] != 0) {
                $_FILES['userfile']['name'] = $_FILES['img11']['name'][$i];
                $_FILES['userfile']['type'] = $_FILES['img11']['type'][$i];
                $_FILES['userfile']['tmp_name'] = $_FILES['img11']['tmp_name'][$i];
                $_FILES['userfile']['error'] = $_FILES['img11']['error'][$i];
                $_FILES['userfile']['size'] = $_FILES['img11']['size'][$i];
                $config = array(
                    'allowed_types' => 'jpg|jpeg|png|gif',
                    'max_size' => 3000,
                    'overwrite' => FALSE,
                    'upload_path' => 'assets/upload'
                );
                $this->upload->initialize($config);
                if (!$this->upload->do_upload()) :
                    $error = array('error' => $this->upload->display_errors());
                    $this->load->view('upload_form', $error);
                else :
                    $final_files_data[] = $this->upload->data();
                endif;
            }else {
                $final_files_data[$i]['file_name'] = null;
            }
        endfor;
        $this->load->model('estate');
        $this->estate->add_home_mortgage($lon, $lat, $price, $area, $elevator, $bedroom, $tell, $phone, $description, $address, $storehouse, $parking, $build, $id, $final_files_data[0]['file_name'], $final_files_data[1]['file_name'], $final_files_data[2]['file_name']);
    }

    public function senddata_search() {
        $id = $this->session->userdata('id');
        $price_down = $_GET['q1'];
        $price_up = $_GET['q2'];
        $bedroom = $_GET['q3'];
        $build = $_GET['q4'];
        $type = $_GET['q6'];
        $parking = $_GET['q7'];
        $elevator = $_GET['q8'];
        $storehouse = $_GET['q9'];
        $this->load->model('estate');
        $data['rows'] = $this->estate->getdata_search($id, $price_down, $price_up, $bedroom, $build, $type, $parking, $elevator, $storehouse);
        $this->load->view('home/getdata.php', $data);
    }

    public function edit() {
        $id = $this->session->userdata('id');
        $this->load->model('estate');
        $data['rows'] = $this->estate->edit($id);
        $x = $this->estate->search_user($id);
        if ($x != null) {
            $user = $x[0]->username;
            $data['new_msg_count'] = $this->db->get_where('message', array('seen_user =' => '0', 'username_estate =' => $user))->num_rows();
        } else {
            $data['new_msg_count'] = 0;
        }
        $data['title'] = 'پنل | ویرایش';
        $data['page'] = 10;
        $this->load->view('estate/estate.php', $data);
    }

    public function edit_member() {
        $id = $this->session->userdata('id');
        $name = $_POST['name'];
        $manager = $_POST['manager'];
        $tell = $_POST['tell'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        $this->load->model('estate');
        $this->estate->edit_member($id,$name, $manager, $tell, $phone, $address);
        echo 'ویرایش با موفقیت انجام شد';
    }

}
